﻿using System.Windows;
using KeyboardRescue.App.Interop;
using KeyboardRescue.App.Services;
using KeyboardRescue.App.UI;
using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Settings;
using MessageBox = System.Windows.MessageBox;
using Point = System.Windows.Point;

namespace KeyboardRescue.App;

/// <summary>
/// Composition root and lifetime owner. There is no main window: the app
/// lives in the tray, observes typing through a global hook, and shows the
/// suggestion popup on demand.
///
/// Wiring, in order:
/// single-instance mutex → settings → tray → monitor → coordinator →
/// popup ↔ coordinator, plus first-run onboarding on first launch.
/// </summary>
public partial class App : System.Windows.Application
{
    private const string MutexName = "Local\\KeyboardRescue.SingleInstance";

    private Mutex? _singleInstanceMutex;
    private SettingsStore _settingsStore = null!;
    private StartupService _startupService = null!;
    private TrayService _tray = null!;
    private KeyboardMonitor _monitor = null!;
    private AnalysisCoordinator _coordinator = null!;
    private SuggestionPopup? _popup;
    private AppSettings _settings = AppSettings.Default;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // Second launch: bring up settings instead of running two hooks.
        _singleInstanceMutex = new Mutex(true, MutexName, out bool createdNew);
        if (!createdNew)
        {
            // Another instance owns the hook; just quit quietly. (A full
            // implementation would signal the first instance to open its
            // settings window via a named pipe; kept simple on purpose.)
            Shutdown();
            return;
        }

        _settingsStore = new SettingsStore();
        _settings = _settingsStore.Load();
        _startupService = new StartupService();

        // First run: brief onboarding, then persist the choice.
        if (!_settings.FirstRunCompleted)
        {
            _settings = FirstRunWindow.Run(_settings);
            _settingsStore.Save(_settings);
        }
        _startupService.SetEnabled(_settings.LaunchAtStartup);

        var layoutBridge = new LayoutBridge();

        _coordinator = new AnalysisCoordinator(_settings, layoutBridge);
        _coordinator.SuggestionReady += OnSuggestionReady;
        _coordinator.SuggestionDismissed += OnSuggestionDismissed;

        _monitor = new KeyboardMonitor(
            shouldConsumeEnter: () => _popup?.IsVisible == true,
            shouldConsumeEscape: () => _popup?.IsVisible == true,
            isAcceptShortcut: IsAcceptShortcut);
        _monitor.KeyPressed += OnKey;

        if (!_monitor.Start())
        {
            MessageBox.Show(
                "Keyboard Rescue could not install its keyboard hook, so it cannot detect layout mistakes. " +
                "The app will keep running in the tray; try restarting it.",
                "Keyboard Rescue",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }

        _tray = new TrayService();
        _tray.SetEnabled(_settings.Enabled);
        _tray.ToggleEnabledRequested += OnToggleEnabled;
        _tray.PauseRequested += OnPause;
        _tray.SettingsRequested += OnOpenSettings;
        _tray.AboutRequested += OnAbout;
        _tray.QuitRequested += OnQuit;
    }

    private void OnKey(KeyEvent evt)
    {
        bool popupVisible = _popup?.IsVisible == true;

        if (popupVisible)
        {
            // The hook swallows Enter/Escape and the accept hotkey while the
            // popup is up, so the focused app never sees those. Every other
            // key (including plain Ctrl/Alt shortcuts) reaches the
            // coordinator below, which dismisses the stale suggestion.
            PopupKeyAction action = PopupKeyRouting.Route(evt.Observation);
            if (action == PopupKeyAction.Accept)
            {
                _coordinator.Accept();
                return;
            }
            if (action == PopupKeyAction.Dismiss)
            {
                _coordinator.Dismiss();
                return;
            }
        }

        // Any other key while visible flows to the coordinator, which
        // dismisses the stale suggestion and updates the buffer.
        _coordinator.OnKey(evt);
    }

    private void OnSuggestionReady(SuggestionAvailable available)
    {
        _popup ??= new SuggestionPopup(
            onAccept: () => _coordinator.Accept(),
            onDismiss: () => _coordinator.Dismiss());

        IntPtr target = NativeMethods.GetForegroundWindow();
        Point anchor = new PopupPositioningService().ResolveAnchor(target);
        _popup.ShowFor(available.Suggestion, anchor, _settings.AutoHideMilliseconds);

        if (_settings.PlaySound)
            System.Media.SystemSounds.Asterisk.Play();
    }

    private void OnSuggestionDismissed()
    {
        _popup?.HidePopup();
    }

    /// <summary>Matches the configured hotkey ("Ctrl+Shift+Space" by
    /// default) against the pressed key. Shift must be held; Ctrl was
    /// already verified by the caller.</summary>
    private bool IsAcceptShortcut(uint virtualKey, bool alt)
    {
        if (alt) return false; // Alt combinations belong to menus, not us

        string key = _settings.GlobalShortcut;
        if (string.IsNullOrEmpty(key)) return false;

        // Minimal parser: "Ctrl+Shift+X" / "Ctrl+Alt+X" etc.
        string[] parts = key.Split('+', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0) return false;

        string finalKey = parts[^1];
        bool needCtrl = parts.Any(p => p.Equals("Ctrl", StringComparison.OrdinalIgnoreCase));
        bool needShift = parts.Any(p => p.Equals("Shift", StringComparison.OrdinalIgnoreCase));
        bool needAlt = parts.Any(p => p.Equals("Alt", StringComparison.OrdinalIgnoreCase));

        bool shift = (NativeMethods.GetAsyncKeyState(0x10) & 0x8000) != 0;
        bool ctrl = (NativeMethods.GetAsyncKeyState(0x11) & 0x8000) != 0;
        bool altState = (NativeMethods.GetAsyncKeyState(0x12) & 0x8000) != 0;

        if (needCtrl != ctrl || needShift != shift || needAlt != altState) return false;

        return finalKey.Length switch
        {
            1 => virtualKey == char.ToUpperInvariant(finalKey[0]),
            _ => finalKey.ToUpperInvariant() switch
            {
                "SPACE" => virtualKey == 0x20,
                "ENTER" or "RETURN" => virtualKey == 0x0D,
                _ => false,
            },
        };
    }

    private void OnToggleEnabled()
    {
        _settings = _settings with { Enabled = _tray.IsEnabled };
        _settingsStore.Save(_settings);
        _coordinator.UpdateSettings(_settings);
    }

    private void OnPause()
    {
        _tray.Pause(TimeSpan.FromMinutes(10));
        _coordinator.Dismiss();
    }

    private void OnOpenSettings()
    {
        var window = new SettingsWindow(_settings)
        {
            Owner = null, // no main window to own it
        };
        if (window.ShowDialog() != true) return;

        _settings = window.Result;
        _settingsStore.Save(_settings);
        _startupService.SetEnabled(_settings.LaunchAtStartup);
        _tray.SetEnabled(_settings.Enabled);
        _coordinator.UpdateSettings(_settings);
    }

    private void OnAbout()
    {
        MessageBox.Show(
            "Keyboard Rescue\n\n" +
            "Detects Hebrew text typed on the English layout (and vice versa) " +
            "and offers a one-click fix.\n\n" +
            "All detection runs locally. Nothing you type is uploaded, logged " +
            "or saved. Password fields are never touched.\n\n" +
            "Enter replaces · Esc dismisses.",
            "About Keyboard Rescue",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void OnQuit()
    {
        _monitor.Dispose();
        _tray.Dispose();
        _coordinator.Dispose();
        Shutdown();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _singleInstanceMutex?.ReleaseMutex();
        _singleInstanceMutex?.Dispose();
        base.OnExit(e);
    }
}
