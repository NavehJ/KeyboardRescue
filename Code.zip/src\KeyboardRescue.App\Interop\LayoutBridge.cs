using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.App.Interop;

/// <summary>
/// The layout currently driving the focused window, paired with the layout
/// the user probably meant. Resolved by fingerprinting the OS's own
/// translation tables (ToUnicodeEx against the live HKL) and matching them
/// against our verified dumps - never by hardcoded handle values, which
/// differ per machine and per keyboard.
///
/// Unsupported layouts (Dvorak, Colemak, AZERTY, ...) simply resolve to
/// null: the monitor stays idle. Detection must never guess. Layouts
/// that differ from a verified one only by dead keys (US
/// International: identical to US QWERTY except the quote key is a
/// dead key) are supported - a dead key occupies the same physical
/// position, so conversions are unchanged.
/// </summary>
public sealed class LayoutBridge
{
    // VKs chosen to discriminate all three supported layouts: A/F separate
    // QWERTY from Hebrew, and I/Q/W/,/./OEM_2/OEM_7 separate Hebrew
    // Standard from Hebrew 2018 (the seven positions that differ).
    private static readonly uint[] ProbeVirtualKeys =
    [
        0x41, // A
        0x46, // F
        0x49, // I
        0x51, // Q
        0x57, // W
        0xBC, // OEM_COMMA
        0xBE, // OEM_PERIOD
        0xBF, // OEM_2
        0xDE, // OEM_7
    ];

    /// <summary>Translator used for fingerprinting; injectable for tests.
    /// Returns the character the OS produces for the VK on the given HKL,
    /// or null when the OS produces nothing (no translation / dead key).</summary>
    internal delegate char? OUnicodeTranslator(uint virtualKey, IntPtr hkl);

    private readonly Dictionary<IntPtr, LayoutPair?> _cache = new();
    private readonly OUnicodeTranslator _translate;

    public LayoutBridge() : this(TranslateWithOs) { }

    internal LayoutBridge(OUnicodeTranslator translator) => _translate = translator;

    /// <summary>Typed layout, the layout to convert into, and the direction
    /// of the only correction we offer for this pair.</summary>
    public sealed record LayoutPair(
        IKeyboardLayout TypedLayout,
        IKeyboardLayout TargetLayout,
        CorrectionDirection Direction)
    {
        /// <summary>Whichever side of the pair is Hebrew - the engine needs
        /// the exact Hebrew variant (Standard vs 2018) the user runs.</summary>
        public IKeyboardLayout HebrewLayout =>
            TypedLayout.Id == KeyboardLayoutCatalog.UsQwertyId ? TargetLayout : TypedLayout;
    }

    /// <summary>Resolves for the current foreground window. Returns null
    /// when the layout is unsupported, when there is no foreground window,
    /// or when the OS cannot translate (fail safe: stay idle).</summary>
    public LayoutPair? ResolveForForegroundWindow()
    {
        IntPtr foreground = NativeMethods.GetForegroundWindow();
        if (foreground == IntPtr.Zero) return null;

        uint threadId = NativeMethods.GetWindowThreadProcessId(foreground, out _);
        return Resolve(NativeMethods.GetKeyboardLayout(threadId));
    }

    public LayoutPair? Resolve(IntPtr hkl)
    {
        if (hkl == IntPtr.Zero) return null;
        lock (_cache)
        {
            if (_cache.TryGetValue(hkl, out LayoutPair? cached)) return cached;
            LayoutPair? resolved = ResolveUncached(hkl);
            _cache[hkl] = resolved;
            return resolved;
        }
    }

    internal LayoutPair? ResolveFromHklForTests(IntPtr hkl) => ResolveUncached(hkl);

    private LayoutPair? ResolveUncached(IntPtr hkl)
    {
        // Cheap sanity filter first: the low word of an HKL is the language
        // identifier. English (0x0409) can only be US QWERTY here; Hebrew
        // (0x040D) is either Standard or 2018. Anything else is not a
        // layout we have verified, so we stay idle.
        int languageId = NativeMethods.LoWord(hkl);
        if (languageId == 0x0409)
            return FingerprintMatches(KeyboardLayoutCatalog.UsQwerty, hkl)
                ? new LayoutPair(
                    KeyboardLayoutCatalog.UsQwerty,
                    KeyboardLayoutCatalog.HebrewStandard,
                    CorrectionDirection.ToHebrew)
                : null;

        if (languageId == 0x040D)
        {
            if (FingerprintMatches(KeyboardLayoutCatalog.HebrewStandard, hkl))
                return new LayoutPair(
                    KeyboardLayoutCatalog.HebrewStandard,
                    KeyboardLayoutCatalog.UsQwerty,
                    CorrectionDirection.ToEnglish);

            if (FingerprintMatches(KeyboardLayoutCatalog.Hebrew2018, hkl))
                return new LayoutPair(
                    KeyboardLayoutCatalog.Hebrew2018,
                    KeyboardLayoutCatalog.UsQwerty,
                    CorrectionDirection.ToEnglish);
        }

        return null;
    }

    /// <summary>
    /// Every probe key must translate exactly as our verified dump says.
    /// A single mismatch means this HKL is some layout we have not
    /// verified (Dvorak, a remapper tool, ...) and must be refused.
    /// The one tolerance: a probe where the OS produces *nothing*
    /// (a dead key, e.g. the quote key on "US International") still
    /// matches - a dead key occupies the same physical position, so
    /// every character the layout can produce sits where our dump
    /// says it does. Producing a *different* character is still a
    /// hard mismatch.
    /// </summary>
    private bool FingerprintMatches(IKeyboardLayout candidate, IntPtr hkl)
    {
        // A pending dead key on this layout (the user typed a
        // compose key shortly before this run) would surface on
        // the first probe as a composed character, falsely failing
        // the fingerprint - and the refusal would then be cached
        // for the HKL. One throwaway translation consumes any
        // pending compose state; the result is irrelevant.
        _translate(0x20, hkl);

        foreach (uint vk in ProbeVirtualKeys)
        {
            char expected = candidate.TryGetCharacter(new KeyPosition(vk, Shift: false), out char c)
                ? c
                : '\0';
            char? actual = _translate(vk, hkl);
            if (actual is null) continue; // dead key: same position
            if (actual.Value != expected) return false;
        }
        return true;
    }

    private static char? TranslateWithOs(uint virtualKey, IntPtr hkl)
    {
        uint scanCode = NativeMethods.MapVirtualKeyExW(
            virtualKey, NativeMethods.MapvkVkToVsc, hkl);
        if (scanCode == 0) return null;

        // Zeroed key state = base (unshifted, no Ctrl/Alt) level, which is
        // all the fingerprint needs.
        var keyState = new byte[256];
        var buffer = new System.Text.StringBuilder(8);
        int result = NativeMethods.ToUnicodeEx(
            virtualKey, scanCode, keyState, buffer, buffer.Capacity, 0, hkl);

        if (result <= 0 || buffer.Length == 0) return null; // nothing / dead key
        return buffer[0];
    }
}
