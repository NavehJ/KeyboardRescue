using System.Windows.Threading;
using KeyboardRescue.App.Interop;
using KeyboardRescue.Core.Context;
using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;
using KeyboardRescue.Core.Settings;

namespace KeyboardRescue.App.Services;

/// <summary>Everything the UI needs to show a suggestion.</summary>
public sealed record SuggestionAvailable(
    Suggestion Suggestion,
    string OriginalText,
    string CandidateText);

/// <summary>
/// Orchestrates the detect → suggest → confirm loop on the UI thread:
/// <list type="number">
/// <item>Keystroke events from <see cref="KeyboardMonitor"/> are fed into a
/// <see cref="TypingContextBuffer"/>; boundaries and resets are applied per
/// key class and whenever the focused window changes.</item>
/// <item>A debounce timer (default 450 ms, tunable 300–600) restarts on
/// every keystroke, so analysis only runs once the user pauses.</item>
/// <item>Analysis runs on a background thread over an immutable snapshot;
/// the result is discarded if the buffer version or the foreground window
/// changed meanwhile.</item>
/// <item>The user decides: <see cref="Accept"/> revalidates the buffer and
/// hands the plan to <see cref="TextReplacementService"/>; any other key or
/// click dismisses.</item>
/// </list>
/// Everything is memory-only; nothing here is logged or persisted.
/// </summary>
public sealed class AnalysisCoordinator : IDisposable
{
    private readonly TypingContextBuffer _buffer = new();
    private readonly LayoutBridge _layoutBridge;
    private readonly SecureInputDetector _secureInput = new();
    private readonly TextReplacementService _replacer = new();
    private readonly DispatcherTimer _debounceTimer;
    private readonly object _analysisGate = new();
    private readonly Func<IntPtr> _getForeground;

    private AppSettings _settings;
    private IntPtr _targetWindow;
    private IntPtr _lastForeground;
    private Suggestion? _activeSuggestion;
    private int _activeVersion;
    private bool _analysisRunning;

    /// <summary>A suggestion is ready to show. Raised on the UI thread.</summary>
    public event Action<SuggestionAvailable>? SuggestionReady;

    /// <summary>The active suggestion is gone (accepted, dismissed by the
    /// user, or invalidated by continued typing). The popup hides itself.</summary>
    public event Action? SuggestionDismissed;

    public Suggestion? ActiveSuggestion => _activeSuggestion;

    /// <summary>Creates the coordinator. <paramref name="getForeground"/>
    /// is injectable for tests; production always asks the OS.</summary>
    public AnalysisCoordinator(AppSettings settings, LayoutBridge layoutBridge,
        Func<IntPtr>? getForeground = null)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _layoutBridge = layoutBridge ?? throw new ArgumentNullException(nameof(layoutBridge));
        _getForeground = getForeground ?? NativeMethods.GetForegroundWindow;

        _debounceTimer = new DispatcherTimer(DispatcherPriority.Background)
        {
            Interval = TimeSpan.FromMilliseconds(settings.DebounceMilliseconds),
        };
        _debounceTimer.Tick += OnDebounceElapsed;
    }

    public void UpdateSettings(AppSettings settings)
    {
        _settings = settings ?? throw new ArgumentNullException(nameof(settings));
        _debounceTimer.Interval = TimeSpan.FromMilliseconds(settings.DebounceMilliseconds);
        Dismiss();
    }

    /// <summary>Entry point from the keyboard hook. Must stay fast: it only
    /// updates the buffer and pokes a timer.</summary>
    public void OnKey(KeyEvent evt)
    {
        if (!_settings.Enabled)
        {
            _debounceTimer.Stop();
            return;
        }

        // A focus change means the buffer describes a different window than
        // the one the caret is in now: drop it (and any suggestion aimed at
        // the old target) before this keystroke is recorded, or a later
        // accept would backspace the wrong window's text.
        SyncForeground(_getForeground());

        // A visible suggestion dies the moment the user keeps typing: it
        // would target stale text otherwise.
        if (_activeSuggestion is not null && evt.Observation != KeyObservation.Enter)
            Dismiss();

        switch (evt.Observation)
        {
            case KeyObservation.Character:
                _buffer.AppendChar(evt.Character);
                RestartDebounce();
                break;

            case KeyObservation.Backspace:
                _buffer.Backspace();
                RestartDebounce();
                break;

            case KeyObservation.Enter:
            case KeyObservation.Tab:
                _buffer.BreakSegment();
                _debounceTimer.Stop();
                break;

            case KeyObservation.CaretMoved:
            case KeyObservation.Shortcut:
                // Arrows and shortcuts make our linear buffer untrustworthy.
                _buffer.Reset();
                _debounceTimer.Stop();
                break;

            case KeyObservation.Escape:
                _debounceTimer.Stop();
                break;
        }
    }

    /// <summary>User accepted the visible suggestion (Enter while visible,
    /// global hotkey, or popup click). Returns false when nothing applied.</summary>
    public bool Accept()
    {
        Suggestion? suggestion = _activeSuggestion;
        _activeSuggestion = null;
        if (suggestion is null) return false;

        IntPtr target = _targetWindow;

        // Revalidate against the *current* buffer before touching the app.
        if (!_buffer.TryPlanReplacement(suggestion, _activeVersion, out ReplacementPlan? plan))
        {
            _buffer.Reset();
            SuggestionDismissed?.Invoke();
            return false;
        }

        ReplacementOutcome outcome = _replacer.Apply(plan, target);
        if (outcome == ReplacementOutcome.Applied)
        {
            if (_buffer.CommitReplacement(plan))
            {
                // The corrected text is settled: continue as a fresh
                // segment. Without this boundary the accepted candidate
                // stays inside the open segment and drags later analysis
                // with it - the streamed flow ("keep typing after a
                // correction") then either re-suggests settled text or
                // stops firing on the new mistyped words.
                _buffer.BreakSegment();
            }
            else
            {
                // Extremely unlikely race (a key landed mid-SendInput):
                // recover by starting fresh rather than tracking wrong text.
                _buffer.Reset();
            }
        }
        else
        {
            // Stale or blocked: never leave a half-tracked buffer around.
            _buffer.Reset();
        }

        SuggestionDismissed?.Invoke();
        return outcome == ReplacementOutcome.Applied;
    }

    /// <summary>Whether the user enabled suggestions for a result's
    /// direction. A mixed result is only offered when both directions
    /// are enabled.</summary>
    private bool ResultDirectionEnabled(CorrectionDirection direction) => direction switch
    {
        CorrectionDirection.ToHebrew => _settings.EnableHebrewSuggestions,
        CorrectionDirection.ToEnglish => _settings.EnableEnglishSuggestions,
        CorrectionDirection.Mixed => _settings.EnableHebrewSuggestions && _settings.EnableEnglishSuggestions,
        _ => false,
    };

    /// <summary>Dismiss the visible suggestion without replacing.</summary>
    public void Dismiss()
    {
        bool had = _activeSuggestion is not null;
        _activeSuggestion = null;
        if (had) SuggestionDismissed?.Invoke();
    }

    /// <summary>
    /// Returns true when the focused window changed since the last observed
    /// key (or analysis): the buffer and any live suggestion then describe a
    /// different window's text and are dropped. The first observation only
    /// records the baseline.
    /// </summary>
    private bool SyncForeground(IntPtr now)
    {
        if (_lastForeground != IntPtr.Zero && _lastForeground != now)
        {
            _buffer.Reset();
            Dismiss();
            _lastForeground = now;
            return true;
        }

        _lastForeground = now;
        return false;
    }

    /// <summary>Test seam: the buffer's current state (see
    /// <c>LayoutBridge.ResolveFromHklForTests</c> for precedent).</summary>
    internal ContextSnapshot SnapshotForTests => _buffer.Snapshot();

    private void RestartDebounce()
    {
        _debounceTimer.Stop();
        _debounceTimer.Start();
    }

    private void OnDebounceElapsed(object? sender, EventArgs e)
    {
        _debounceTimer.Stop();
        BeginAnalysis();
    }

    private void BeginAnalysis()
    {
        if (_activeSuggestion is not null) return;

        // One analysis at a time; the next keystroke restarts the timer.
        lock (_analysisGate)
        {
            if (_analysisRunning) return;
            _analysisRunning = true;
        }

        ContextSnapshot snapshot = _buffer.Snapshot();
        IntPtr target = NativeMethods.GetForegroundWindow();

        // The debounce can fire after a mouse-driven window switch before
        // any keystroke in the new window: pairing the old buffer with the
        // new foreground would show a suggestion whose accept backspaces the
        // wrong window's text. Drop the buffer and bail instead.
        if (SyncForeground(target))
        {
            _analysisRunning = false;
            return;
        }

        LayoutBridge.LayoutPair? pair = _layoutBridge.ResolveForForegroundWindow();
        if (pair is null || snapshot.Segment.Length == 0)
        {
            _analysisRunning = false;
            return;
        }

        // Direction gating from user settings.
        CorrectionDirection wanted = pair.Direction;
        if ((wanted == CorrectionDirection.ToHebrew && !_settings.EnableHebrewSuggestions) ||
            (wanted == CorrectionDirection.ToEnglish && !_settings.EnableEnglishSuggestions))
        {
            _analysisRunning = false;
            return;
        }

        // Secure-input check runs here (UIA and SendMessage need the UI
        // thread and are bounded by short timeouts).
        SecureInputState secure = _secureInput.Probe();
        if (secure == SecureInputState.Secure ||
            (secure == SecureInputState.Unknown && !_settings.AllowUnknownSecureState))
        {
            _analysisRunning = false;
            return;
        }

        DetectionOptions options = DetectionOptions.ForSensitivity(_settings.Sensitivity);
        IKeyboardLayout hebrewLayout = pair.HebrewLayout;

        int version = snapshot.Version;
        _targetWindow = target;

        // Heavy lifting off the UI thread over immutable locals; the result
        // is marshaled back and revalidated there.
        _ = System.Threading.Tasks.Task.Run(() =>
        {
            Suggestion? result = null;
            try
            {
                // A fresh engine per run is cheap: the heavy language data
                // and layout tables are static and shared.
                var engine = new DetectionEngine(options, hebrewLayout: hebrewLayout);
                result = engine.Analyze(new AnalysisRequest(
                    Segment: snapshot.Segment,
                    PrecedingText: snapshot.PrecedingText));
            }
            catch (Exception)
            {
                // Detection must never crash the host; a failed analysis is
                // simply no suggestion.
                result = null;
            }
            finally
            {
                lock (_analysisGate) _analysisRunning = false;
            }

            // Direction settings gate the RESULT, not the layout pair: a
            // mixed segment may hold corrections in both directions.
            if (result is not null && !ResultDirectionEnabled(result.Direction))
                result = null;

            if (result is null) return;

            _ = System.Windows.Application.Current?.Dispatcher.BeginInvoke(new Action(() =>
            {
                // Everything may have moved on while we analyzed.
                if (_buffer.Version != version ||
                    NativeMethods.GetForegroundWindow() != target ||
                    _activeSuggestion is not null)
                    return;

                _activeSuggestion = result;
                _activeVersion = version;
                SuggestionReady?.Invoke(new SuggestionAvailable(
                    result, result.OriginalText, result.CandidateText));
            }));
        });
    }

    public void Dispose() => _debounceTimer.Stop();
}
