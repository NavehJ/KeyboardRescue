using System.Diagnostics;
using KeyboardRescue.App.Interop;

namespace KeyboardRescue.App.Services;

/// <summary>What the monitor observed for one key event.</summary>
public enum KeyObservation
{
    /// <summary>Any printable character; <c>Text</c> carries it.</summary>
    Character,

    Backspace,
    Enter,
    Tab,
    Escape,
    /// <summary>Arrow / Home / End / PageUp / PageDown / Delete: the caret
    /// moved somewhere we cannot track.</summary>
    CaretMoved,
    /// <summary>Ctrl/Alt/Win-modified key: shortcut territory, not text
    /// (includes layout-switch gestures such as Alt+Shift or Win+Space).</summary>
    Shortcut,
    /// <summary>The configured accept hotkey (e.g. Ctrl+Shift+Space) - and
    /// only that key. Deliberately distinct from <see cref="Shortcut"/>: the
    /// app must never treat an arbitrary shortcut as an acceptance, because
    /// the hook only swallows the hotkey itself while the popup is visible.</summary>
    AcceptShortcut,
}

public readonly record struct KeyEvent(KeyObservation Observation, char Character)
{
    public static KeyEvent OfChar(char c) => new(KeyObservation.Character, c);
    public static KeyEvent Of(KeyObservation kind) => new(kind, '\0');
}

/// <summary>
/// A WH_KEYBOARD_LL hook that observes keystrokes of the whole session and
/// raises <see cref="KeyPressed"/> on the hook thread. Design constraints:
/// <list type="bullet">
/// <item>The callback must return in microseconds - it does no allocation
/// beyond struct copies, no I/O, no analysis.</item>
/// <item>Injected input (our own replacements, other automation) is
/// ignored entirely via LLKHF_INJECTED, so the app never chases its own
/// tail.</item>
/// <item>Ctrl/Alt/Win combinations are reported as <see cref="KeyObservation.Shortcut"/>
/// and never as text: shortcuts are not typing. The configured accept hotkey
/// alone is reported as <see cref="KeyObservation.AcceptShortcut"/>.</item>
/// <item>Return-value consumption is delegated: when the popup is visible
/// and asks to consume Enter/Escape, the hook swallows that key so the
/// focused app never sees it.</item>
/// </list>
/// </summary>
public sealed class KeyboardMonitor : IDisposable
{
    private readonly NativeMethods.LowLevelProc _callback;
    private readonly Func<bool> _shouldConsumeEnter;
    private readonly Func<bool> _shouldConsumeEscape;
    private readonly Func<uint, bool, bool> _isAcceptShortcut;
    private IntPtr _hook = IntPtr.Zero;

    /// <summary>Raised inside the hook callback. Must be fast; subscribers
    /// hand off to their own queues.</summary>
    public event Action<KeyEvent>? KeyPressed;

    /// <summary>True when the hook is installed.</summary>
    public bool IsRunning => _hook != IntPtr.Zero;

    public KeyboardMonitor(
        Func<bool> shouldConsumeEnter,
        Func<bool> shouldConsumeEscape,
        Func<uint, bool, bool> isAcceptShortcut)
    {
        _shouldConsumeEnter = shouldConsumeEnter ?? throw new ArgumentNullException(nameof(shouldConsumeEnter));
        _shouldConsumeEscape = shouldConsumeEscape ?? throw new ArgumentNullException(nameof(shouldConsumeEscape));
        _isAcceptShortcut = isAcceptShortcut ?? throw new ArgumentNullException(nameof(isAcceptShortcut));
        _callback = HookCallback;
    }

    /// <summary>Installs the hook. Returns false when Windows refuses
    /// (rare; e.g. UIPI against elevated targets still allows WH_KEYBOARD_LL
    /// but some hardened setups block it) - the app then runs without
    /// detection rather than failing.</summary>
    public bool Start()
    {
        if (_hook != IntPtr.Zero) return true;

        // WH_KEYBOARD_LL needs the module handle of the *current* process.
        IntPtr module = NativeMethods.GetModuleHandleW(IntPtr.Zero);
        _hook = NativeMethods.SetWindowsHookExW(
            NativeMethods.WhKeyboardLl, _callback, module, 0);

        return _hook != IntPtr.Zero && _hook != NativeMethods.InvalidHook;
    }

    public void Stop()
    {
        if (_hook == IntPtr.Zero) return;
        NativeMethods.UnhookWindowsHookEx(_hook);
        _hook = IntPtr.Zero;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            var data = System.Runtime.InteropServices.Marshal.PtrToStructure<
                NativeMethods.KbdLlHookStruct>(lParam);

            bool isKeyDown =
                (long)wParam == NativeMethods.WmKeyDown ||
                (long)wParam == NativeMethods.WmSysKeyDown;

            if (isKeyDown &&
                // Never react to synthetic input, including our own
                // SendInput: this is what keeps replacement text from
                // re-triggering analysis.
                (data.Flags & NativeMethods.LlkfInjected) == 0 &&
                ClassifyAndDispatch(data, out bool consume))
            {
                if (consume) return 1; // swallow before the focused app sees it
            }
        }

        return NativeMethods.CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    /// <summary>Classifies one key-down and notifies. Returns true when the
    /// event was relevant enough to raise <see cref="KeyPressed"/>.</summary>
    private bool ClassifyAndDispatch(NativeMethods.KbdLlHookStruct data, out bool consume)
    {
        consume = false;
        uint vk = data.VkCode;

        bool ctrl = IsDown(0x11);
        bool alt = IsDown(0x12);
        bool win = IsDown(0x5B) || IsDown(0x5C); // VK_LWIN / VK_RWIN

        // The configured accept hotkey (default Ctrl+Shift+Space) works even
        // when no suggestion is visible - but is only swallowed while the
        // popup actually is, so other apps keep their own bindings. It gets
        // its own observation so the app can tell it apart from any other
        // shortcut. A held Win key disqualifies: Win+Ctrl+Shift+X is some
        // other gesture, not ours.
        if (ctrl && !win && _isAcceptShortcut(vk, alt))
        {
            KeyPressed?.Invoke(KeyEvent.Of(KeyObservation.AcceptShortcut));
            consume = _shouldConsumeEnter();
            return true;
        }

        KeyEvent? evt = Classify(vk, ctrl, alt, win);

        if (evt is null)
        {
            char? c = KeyToChar(data);
            if (c is not null) evt = KeyEvent.OfChar(c.Value);
        }

        if (evt is null) return false;

        // Popup is open: Enter accepts, Escape dismisses - and only the
        // popup's owner may swallow a key, only while it is visible.
        if (evt.Value.Observation == KeyObservation.Enter && _shouldConsumeEnter())
            consume = true;
        if (evt.Value.Observation == KeyObservation.Escape && _shouldConsumeEscape())
            consume = true;

        KeyPressed?.Invoke(evt.Value);
        return true;
    }

    /// <summary>
    /// Pure classification of one key-down given the live modifier state.
    /// Modified keys are shortcuts (never text), the navigation table reports
    /// caret-moving keys, and null means "may produce a character" - the
    /// caller then translates it through the foreground layout.
    /// The Win key counts as a modifier: combos like Win+Space (the default
    /// layout switch) or Win+letter are consumed by the shell and never reach
    /// the focused control, so recording them as text would desync the buffer
    /// from the control and over-delete real characters on the next
    /// replacement.
    /// </summary>
    internal static KeyEvent? Classify(uint vk, bool ctrl, bool alt, bool win)
    {
        if (ctrl || alt || win) return KeyEvent.Of(KeyObservation.Shortcut);

        return vk switch
        {
            0x0D => KeyEvent.Of(KeyObservation.Enter),       // VK_RETURN
            0x09 => KeyEvent.Of(KeyObservation.Tab),         // VK_TAB
            0x1B => KeyEvent.Of(KeyObservation.Escape),      // VK_ESCAPE
            0x08 => KeyEvent.Of(KeyObservation.Backspace),   // VK_BACK
            0x25 or 0x26 or 0x27 or 0x28 =>                  // arrows
                KeyEvent.Of(KeyObservation.CaretMoved),
            0x21 or 0x22 or 0x23 or 0x24 or 0x2D =>          // pgup/pgdn/end/home/ins
                KeyEvent.Of(KeyObservation.CaretMoved),
            _ => null,
        };
    }

    /// <summary>Live modifier state from the OS. Reading it per event (two
    /// cheap calls) beats tracking key-down/up pairs ourselves: it stays
    /// correct across focus changes, auto-repeat and injected input.</summary>
    private static bool IsDown(int virtualKey) =>
        (NativeMethods.GetAsyncKeyState(virtualKey) & 0x8000) != 0;

    /// <summary>True when Caps Lock is toggled (a toggle, not a hold).</summary>
    private static bool IsCapsLockOn() =>
        (NativeMethods.GetKeyState(0x14) & 0x0001) != 0;

    /// <summary>
    /// Translates the VK through the *focused window's* layout so the
    /// character we analyze is the character that landed in the document.
    /// Returns null for anything non-textual.
    /// </summary>
    private char? KeyToChar(NativeMethods.KbdLlHookStruct data)
    {
        IntPtr foreground = NativeMethods.GetForegroundWindow();
        if (foreground == IntPtr.Zero) return null;

        uint threadId = NativeMethods.GetWindowThreadProcessId(foreground, out _);
        IntPtr hkl = NativeMethods.GetKeyboardLayout(threadId);
        if (hkl == IntPtr.Zero) return null;

        uint scanCode = data.ScanCode != 0
            ? data.ScanCode
            : NativeMethods.MapVirtualKeyExW(data.VkCode, NativeMethods.MapvkVkToVsc, hkl);
        if (scanCode == 0) return null;

        var keyState = new byte[256];
        ApplyModifierState(keyState);

        var buffer = new System.Text.StringBuilder(8);
        int result = NativeMethods.ToUnicodeEx(
            data.VkCode, scanCode, keyState, buffer, buffer.Capacity, 0, hkl);

        // -1 means dead key: wait for the next key to complete it. We do not
        // track dead keys across events (Hebrew/US have none) - the buffer
        // simply misses that one composed character, which the user can fix
        // by continuing to type (the segment boundary catches up).
        if (result <= 0 || buffer.Length == 0) return null;

        char c = buffer[0];
        return char.IsControl(c) ? null : c;
    }

    /// <summary>Builds the ToUnicodeEx key-state array from live OS state so
    /// shifted and Caps-Locked characters translate exactly as the user
    /// typed them ("A" stays "A", which the replacement revalidation
    /// requires).</summary>
    private static void ApplyModifierState(byte[] keyState)
    {
        const byte pressed = 0x80;
        if (IsDown(0x10)) { keyState[0x10] = pressed; keyState[0xA0] = pressed; keyState[0xA1] = pressed; }
        if (IsDown(0x11)) { keyState[0x11] = pressed; keyState[0xA2] = pressed; keyState[0xA3] = pressed; }
        if (IsDown(0x12)) { keyState[0x12] = pressed; keyState[0xA4] = pressed; keyState[0xA5] = pressed; }
        if (IsCapsLockOn()) keyState[0x14] = 0x01;
    }

    public void Dispose() => Stop();
}
