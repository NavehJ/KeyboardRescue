using KeyboardRescue.App.Interop;

namespace KeyboardRescue.App.Services;

/// <summary>Whether the focused control may be a secure input field.</summary>
public enum SecureInputState
{
    /// <summary>We could not determine it (no UIA provider, access denied,
    /// unusual control). The fail-safe action is to treat it as secure and
    /// stay silent, unless the user opted in.</summary>
    Unknown,

    /// <summary>The focused control declares itself secure (password box,
    /// masked edit). Never analyze, never send.</summary>
    Secure,

    /// <summary>The focused control is a normal text field.</summary>
    Normal,
}

/// <summary>
/// Decides whether it is safe to analyze the focused control at all.
/// Two independent probes, both fail-safe:
/// <list type="bullet">
/// <item>The UI Automation <c>IsPassword</c> property of the focused
/// element - covers WPF PasswordBox, WinForms MaskedTextBox, browsers'
/// password inputs and most modern controls.</item>
/// <item>The Win32 <c>EM_GETPASSWORDCHAR</c> message for classic Edit /
/// RichEdit controls (UIA often cannot reach into those).</item>
/// </list>
/// Any error, timeout or access-denied result maps to
/// <see cref="SecureInputState.Unknown"/> - the state we refuse to act on.
/// </summary>
public sealed class SecureInputDetector
{
    private static readonly TimeSpan ProbeTimeout = TimeSpan.FromMilliseconds(50);

    /// <summary>Class names that are masked edit controls by construction;
    /// checked before the message probe to avoid messaging arbitrary
    /// windows.</summary>
    private static readonly string[] MaskedEditClasses =
    [
        "Edit",
        "RichEdit20W",
        "RichEdit50W",
        "RICHEDIT50W",
    ];

    public SecureInputState Probe()
    {
        IntPtr foreground = NativeMethods.GetForegroundWindow();
        if (foreground == IntPtr.Zero) return SecureInputState.Unknown;

        uint threadId = NativeMethods.GetWindowThreadProcessId(foreground, out _);

        // Probe 1: UI Automation, covers modern controls including browsers.
        bool uiaReached = false;
        try
        {
            var element = System.Windows.Automation.AutomationElement.FromHandle(foreground);
            if (element is not null)
            {
                uiaReached = true;

                if (element.Current.IsPassword)
                    return SecureInputState.Secure;

                // Walk to the focused descendant when the provider exposes
                // it: the password flag usually sits on the inner input, not
                // the top-level window (e.g. a browser tab).
                var focused = element.FindFirst(
                    System.Windows.Automation.TreeScope.Descendants,
                    new System.Windows.Automation.PropertyCondition(
                        System.Windows.Automation.AutomationElement.HasKeyboardFocusProperty,
                        true));
                if (focused is not null && focused.Current.IsPassword)
                    return SecureInputState.Secure;
            }
        }
        catch (Exception)
        {
            // UIA unavailable or refused: fall through to the Win32 probe.
        }

        // Probe 2: EM_GETPASSWORDCHAR against the focused child control.
        var gui = new NativeMethods.GuiThreadInfo { CbSize = System.Runtime.InteropServices.Marshal.SizeOf<NativeMethods.GuiThreadInfo>() };
        if (NativeMethods.GetGUIThreadInfo(threadId, ref gui) && gui.HwndFocus != IntPtr.Zero)
        {
            if (IsMaskedEdit(gui.HwndFocus))
                return SecureInputState.Secure;

            // EM_GETPASSWORDCHAR on a non-edit control: Windows returns 0
            // and the message is harmless. A non-zero result means masking.
            if (NativeMethods.SendMessageTimeoutW(
                    gui.HwndFocus,
                    NativeMethods.EmGetPasswordChar,
                    IntPtr.Zero, IntPtr.Zero,
                    NativeMethods.SmtoAbortIfHung,
                    (uint)ProbeTimeout.TotalMilliseconds,
                    out IntPtr result) != IntPtr.Zero &&
                result != IntPtr.Zero)
            {
                return SecureInputState.Secure;
            }
        }

        // Neither probe found masking. Report Normal only if UIA actually
        // answered; otherwise the state is genuinely unknown and the caller
        // must fail safe.
        return uiaReached ? SecureInputState.Normal : SecureInputState.Unknown;
    }

    private static bool IsMaskedEdit(IntPtr hwnd)
    {
        var className = new System.Text.StringBuilder(64);
        if (NativeMethods.GetClassNameW(hwnd, className, className.Capacity) == 0)
            return false;

        foreach (string candidate in MaskedEditClasses)
        {
            if (string.Equals(className.ToString(), candidate, StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }
}
