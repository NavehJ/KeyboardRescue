using System.IO;
using System.Text.Json;
using KeyboardRescue.Core.Settings;

namespace KeyboardRescue.App.Services;

/// <summary>
/// Loads and saves <see cref="AppSettings"/> as JSON in the user's own
/// profile (%APPDATA%\KeyboardRescue\settings.json). Rules:
/// <list type="bullet">
/// <item>A missing, unreadable or corrupt file always yields
/// <see cref="AppSettings.Default"/> (sanitized) - never an exception, never
/// a broken start.</item>
/// <item>Values from disk are sanitized before use: hand-edited or corrupt
/// JSON cannot produce out-of-range timings.</item>
/// <item>Only this file is ever written; no logs, no typed text, nothing
/// else touches the disk.</item>
/// </list>
/// </summary>
public sealed class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    private readonly string _filePath;

    public SettingsStore() : this(DefaultPath()) { }

    /// <summary>Path-injectable for tests.</summary>
    public SettingsStore(string filePath) =>
        _filePath = filePath ?? throw new ArgumentNullException(nameof(filePath));

    public static string DefaultPath() => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "KeyboardRescue",
        "settings.json");

    public string FilePath => _filePath;

    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(_filePath)) return AppSettings.Default;

            string json = File.ReadAllText(_filePath);
            AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(json, JsonOptions);
            return (settings ?? AppSettings.Default).Sanitized();
        }
        catch (Exception)
        {
            // Corrupt file, permission issue, encoding problem: run with
            // defaults rather than failing to start.
            return AppSettings.Default;
        }
    }

    public void Save(AppSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);

        string? directory = Path.GetDirectoryName(_filePath);
        if (!string.IsNullOrEmpty(directory))
            Directory.CreateDirectory(directory);

        AppSettings clean = settings.Sanitized();
        File.WriteAllText(_filePath, JsonSerializer.Serialize(clean, JsonOptions));
    }
}
