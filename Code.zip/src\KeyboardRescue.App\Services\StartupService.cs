using Microsoft.Win32;

namespace KeyboardRescue.App.Services;

/// <summary>
/// "Launch at startup" via the per-user Run key. Deliberately HKCU only:
/// nothing is written for other users, and uninstalling the preference is a
/// single key delete. No scheduled tasks, no services, no UAC prompts.
/// </summary>
public sealed class StartupService
{
    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "KeyboardRescue";

    public bool IsEnabled()
    {
        try
        {
            using RegistryKey? key = Registry.CurrentUser.OpenSubKey(RunKeyPath);
            return key?.GetValue(ValueName) is string;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public void SetEnabled(bool enabled)
    {
        try
        {
            using RegistryKey key = Registry.CurrentUser.CreateSubKey(RunKeyPath);
            if (enabled)
            {
                // Quoted path: exe paths contain spaces.
                string exePath = Environment.ProcessPath
                    ?? throw new InvalidOperationException("No process path available.");
                key.SetValue(ValueName, $"\"{exePath}\"");
            }
            else
            {
                key.DeleteValue(ValueName, throwOnMissingValue: false);
            }
        }
        catch (Exception)
        {
            // A denied registry write must not crash the app; the settings
            // UI reflects the actual state on next open.
        }
    }
}
