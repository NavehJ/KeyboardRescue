using KeyboardRescue.App.Interop;
using KeyboardRescue.Core.Context;

namespace KeyboardRescue.App.Services;

/// <summary>Outcome of attempting to apply a replacement.</summary>
public enum ReplacementOutcome
{
    /// <summary>The synthetic input was sent and accepted by Windows.</summary>
    Applied,

    /// <summary>The buffer no longer matched - nothing was sent.</summary>
    Stale,

    /// <summary>SendInput failed (typically UIPI: the target runs at a
    /// higher integrity level). Nothing was delivered.</summary>
    Blocked,
}

/// <summary>
/// Applies a <see cref="ReplacementPlan"/> to the focused application using
/// a single <c>SendInput</c> batch: N backspaces (removing the mistyped
/// text) followed by Unicode keystrokes for the corrected text. The
/// clipboard is never touched. Because the batch is atomic per Windows'
/// input queue, the target application sees either the whole replacement or
/// nothing.
///
/// Safety properties:
/// <list type="bullet">
/// <item>Before sending, the plan is revalidated against the buffer
/// (<see cref="TypingContextBuffer.TryPlanReplacement"/>) and the
/// foreground window must still be the one that was focused when the
/// suggestion was created.</item>
/// <item>SendInput returning 0 (blocked, e.g. elevated target) is reported
/// as <see cref="ReplacementOutcome.Blocked"/> - no partial edits.</item>
/// <item>The injected keystrokes carry LLKHF_INJECTED, so our own hook
/// ignores them: no feedback loop, no re-analysis of replacement text.</item>
/// </list>
/// </summary>
public sealed class TextReplacementService
{
    /// <summary>Cap on backspaces per batch. The plan never exceeds the
    /// buffer segment (MaxSegmentLength = 300), so this only trips if a
    /// caller hands us something insane.</summary>
    private const int MaxBackspaces = 400;

    public ReplacementOutcome Apply(ReplacementPlan plan, IntPtr expectedForegroundWindow)
    {
        ArgumentNullException.ThrowIfNull(plan);

        if (plan.BackspaceCount < 0 || plan.BackspaceCount > MaxBackspaces)
            return ReplacementOutcome.Stale;

        // The focused window must be the same one the analysis targeted.
        // If the user switched apps while the popup was open, do nothing.
        if (NativeMethods.GetForegroundWindow() != expectedForegroundWindow)
            return ReplacementOutcome.Stale;

        var inputs = new NativeMethods.Input[
            2 * plan.BackspaceCount + plan.TextToInsert.Length];
        int written = 0;

        for (int i = 0; i < plan.BackspaceCount; i++)
        {
            inputs[written++] = Key(0x08, keyUp: false); // VK_BACK down
            inputs[written++] = Key(0x08, keyUp: true);  // VK_BACK up
        }

        foreach (char c in plan.TextToInsert)
        {
            inputs[written++] = UnicodeChar(c);
        }

        uint sent = NativeMethods.SendInput(
            (uint)inputs.Length, inputs,
            System.Runtime.InteropServices.Marshal.SizeOf<NativeMethods.Input>());

        if (sent == (uint)inputs.Length) return ReplacementOutcome.Applied;

        // Partial or refused delivery: nothing safe we can do. The caller
        // resets the buffer so we never plan against a half-applied edit.
        return ReplacementOutcome.Blocked;
    }

    private static NativeMethods.Input Key(ushort vk, bool keyUp) => new()
    {
        Type = NativeMethods.InputKeyboard,
        U = new NativeMethods.InputUnion
        {
            Ki = new NativeMethods.KeyBDInput
            {
                Vk = vk,
                Scan = 0,
                Flags = keyUp ? NativeMethods.KeyEventkeyup : 0,
                Time = 0,
                ExtraInfo = IntPtr.Zero,
            },
        },
    };

    /// <summary>A KEYEVENTF_UNICODE keystroke: the target application
    /// receives the character itself regardless of its active layout, which
    /// is exactly what we want when inserting Hebrew into whatever app has
    /// focus.</summary>
    private static NativeMethods.Input UnicodeChar(char c) => new()
    {
        Type = NativeMethods.InputKeyboard,
        U = new NativeMethods.InputUnion
        {
            Ki = new NativeMethods.KeyBDInput
            {
                Vk = 0,
                Scan = c,
                Flags = NativeMethods.KeyEventUnicode,
                Time = 0,
                ExtraInfo = IntPtr.Zero,
            },
        },
    };
}
