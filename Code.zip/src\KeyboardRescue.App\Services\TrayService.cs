using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KeyboardRescue.App.Services;

/// <summary>
/// The system tray presence. The icon is drawn at runtime (a small "kr"
/// glyph in a rounded square) so the app ships no binary assets and the
/// icon can switch between enabled/paused states.
///
/// Menu (plain and boring on purpose):
/// Enabled · Pause 10 minutes · Settings · About · Quit.
/// </summary>
public sealed class TrayService : IDisposable
{
    private readonly ToolStripMenuItem _enabledItem;
    private readonly ToolStripMenuItem _pauseItem;
    private readonly NotifyIcon _icon;
    private readonly System.Windows.Threading.DispatcherTimer _pauseTimer;
    private DateTime _pausedUntilUtc = DateTime.MinValue;

    public event Action? ToggleEnabledRequested;
    public event Action? PauseRequested;
    public event Action? SettingsRequested;
    public event Action? AboutRequested;
    public event Action? QuitRequested;

    public bool IsEnabled { get; private set; } = true;

    public TrayService()
    {
        _enabledItem = new ToolStripMenuItem("Enabled")
        {
            Checked = true,
            CheckOnClick = true,
        };
        _enabledItem.CheckedChanged += (_, _) =>
        {
            IsEnabled = _enabledItem.Checked;
            UpdateIcon();
            ToggleEnabledRequested?.Invoke();
        };

        _pauseItem = new ToolStripMenuItem("Pause 10 minutes");
        _pauseItem.Click += (_, _) => PauseRequested?.Invoke();

        var menu = new ContextMenuStrip();
        menu.Items.Add(_enabledItem);
        menu.Items.Add(_pauseItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Settings…", null, (_, _) => SettingsRequested?.Invoke());
        menu.Items.Add("About", null, (_, _) => AboutRequested?.Invoke());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Quit", null, (_, _) => QuitRequested?.Invoke());

        _icon = new NotifyIcon
        {
            Icon = DrawIcon(enabled: true),
            Visible = true,
            Text = "Keyboard Rescue",
            ContextMenuStrip = menu,
        };

        _pauseTimer = new System.Windows.Threading.DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1),
        };
        _pauseTimer.Tick += (_, _) => UpdatePauseState();
    }

    /// <summary>Sets Enabled state programmatically (e.g. from settings UI).</summary>
    public void SetEnabled(bool enabled)
    {
        IsEnabled = enabled;
        _enabledItem.Checked = enabled;
    }

    public void Pause(TimeSpan duration)
    {
        _pausedUntilUtc = DateTime.UtcNow + duration;
        _pauseTimer.Start();
        UpdatePauseState();
    }

    private void UpdatePauseState()
    {
        bool paused = DateTime.UtcNow < _pausedUntilUtc;
        _pauseItem.Text = paused
            ? $"Paused ({(int)(_pausedUntilUtc - DateTime.UtcNow).TotalMinutes + 1} min left)"
            : "Pause 10 minutes";

        if (!paused && _pauseTimer.IsEnabled)
            _pauseTimer.Stop();

        UpdateIcon();
    }

    private void UpdateIcon()
    {
        Icon? old = _icon.Icon;
        _icon.Icon = DrawIcon(IsEnabled && DateTime.UtcNow >= _pausedUntilUtc);
        old?.Dispose();
    }

    /// <summary>
    /// Draws the tray icon: a rounded square with "kr", greyed out while
    /// disabled or paused. Rendered at 16px for the tray plus a 32px mask
    /// version so it stays crisp under different DPI settings.
    /// </summary>
    private static Icon DrawIcon(bool enabled)
    {
        using var bitmap = new Bitmap(32, 32);
        using (Graphics g = Graphics.FromImage(bitmap))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Color fill = enabled
                ? Color.FromArgb(58, 110, 165)   // calm blue: active
                : Color.FromArgb(150, 150, 150); // grey: off/paused

            using (var brush = new SolidBrush(fill))
                g.FillRectangle(brush, 2, 2, 28, 28);

            using (var font = new Font("Segoe UI", 13, FontStyle.Bold, GraphicsUnit.Pixel))
            using (var textBrush = new SolidBrush(Color.White))
            {
                var size = g.MeasureString("kr", font);
                g.DrawString("kr", font, textBrush,
                    (32 - size.Width) / 2f, (32 - size.Height) / 2f);
            }
        }

        IntPtr hIcon = bitmap.GetHicon();
        try
        {
            // Clone so the managed Icon owns its own handle (GetHicon's
            // handle must be destroyed separately).
            using var tmp = Icon.FromHandle(hIcon);
            return (Icon)tmp.Clone();
        }
        finally
        {
            DestroyIcon(hIcon);
        }
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr handle);

    public void Dispose()
    {
        _icon.Visible = false;
        _icon.Dispose();
        _pauseTimer.Stop();
        _pauseItem.Dispose();
        _enabledItem.Dispose();
    }
}
