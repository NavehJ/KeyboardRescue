using System.Windows;
using KeyboardRescue.Core.Settings;

namespace KeyboardRescue.App.UI;

/// <summary>
/// Minimal first-run onboarding: what it does, that it only suggests, and
/// the privacy stance in one line. Two clicks and it never appears again.
/// </summary>
public partial class FirstRunWindow : Window
{
    public bool StartWithWindows { get; private set; } = true;

    public FirstRunWindow()
    {
        InitializeComponent();
        StartupBox.Checked += (_, _) => StartWithWindows = true;
        StartupBox.Unchecked += (_, _) => StartWithWindows = false;
    }

    private void OnStart(object sender, RoutedEventArgs e)
    {
        StartWithWindows = StartupBox.IsChecked == true;
        DialogResult = true;
    }

    /// <summary>Shows onboarding and returns the resulting settings deltas
    /// (marking first run complete plus the startup choice).</summary>
    public static AppSettings Run(AppSettings current)
    {
        var window = new FirstRunWindow();
        if (window.ShowDialog() != true)
        {
            // Closing the onboarding still counts as done - we never nag.
            return current with { FirstRunCompleted = true };
        }

        return current with
        {
            FirstRunCompleted = true,
            LaunchAtStartup = window.StartWithWindows,
        };
    }
}
