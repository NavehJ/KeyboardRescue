using KeyboardRescue.App.Services;

namespace KeyboardRescue.App.UI;

/// <summary>What the popup does with a key observed while it is visible.</summary>
public enum PopupKeyAction
{
    /// <summary>Accept the visible suggestion (Enter or the accept hotkey).</summary>
    Accept,

    /// <summary>Hide the suggestion without replacing (Escape).</summary>
    Dismiss,

    /// <summary>Not ours: pass the key to the coordinator, which dismisses
    /// the stale suggestion and records the keystroke normally.</summary>
    PassThrough,
}

/// <summary>
/// Decides how a visible popup treats an observed key. Kept separate from
/// <see cref="App"/> so the contract is directly testable - the previous
/// implementation accepted on *every* <see cref="KeyObservation.Shortcut"/>,
/// so pressing any Ctrl/Alt key while the popup was up (layout switches
/// like Alt+Shift/Ctrl+Shift, Ctrl+C, Alt+Tab, ...) silently triggered a
/// text replacement. Only the dedicated accept hotkey may do that.
/// </summary>
public static class PopupKeyRouting
{
    public static PopupKeyAction Route(KeyObservation observation) => observation switch
    {
        KeyObservation.Enter or KeyObservation.AcceptShortcut => PopupKeyAction.Accept,
        KeyObservation.Escape => PopupKeyAction.Dismiss,
        _ => PopupKeyAction.PassThrough,
    };
}
