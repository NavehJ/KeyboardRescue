using System.Windows;
using System.Windows.Interop;
using KeyboardRescue.App.Interop;
using Point = System.Windows.Point;
using Size = System.Windows.Size;

namespace KeyboardRescue.App.UI;

/// <summary>
/// Chooses where to place the suggestion popup, from most to least
/// accurate, and always clamps the result onto the visible monitor:
/// <list type="number">
/// <item>The caret rectangle reported by <c>GetGUIThreadInfo</c> for the
/// focused window - the ideal spot.</item>
/// <item>The focused window's bottom-left corner (with padding) - good enough
/// when the app hides its caret from UIA/Win32 (terminals, browsers'
/// canvas editors).</item>
/// <item>The foreground window's bottom-left corner - when focus queries fail.</item>
/// <item>The mouse cursor position - last resort when all window queries fail.</item>
/// </list>
/// The popup is placed below the anchor when there is room, otherwise above
/// it; the final rect is always fully inside the working area of the monitor
/// containing the anchor, so it can never hang off-screen.
/// </summary>
public sealed class PopupPositioningService
{
    /// <summary>Gap between the caret line and the popup, in DIPs. Small on
    /// purpose: close enough to read as "attached", far enough not to hide
    /// the next line of text.</summary>
    private const double AnchorGap = 12;

    public Point ResolveAnchor(IntPtr foregroundWindow)
    {
        // 1. Caret rect of the focused thread, in screen coordinates.
        uint threadId = NativeMethods.GetWindowThreadProcessId(foregroundWindow, out _);
        var gui = new NativeMethods.GuiThreadInfo
        {
            CbSize = System.Runtime.InteropServices.Marshal.SizeOf<NativeMethods.GuiThreadInfo>(),
        };

        bool gotGuiInfo = NativeMethods.GetGUIThreadInfo(threadId, ref gui);

        // Caret available and valid?
        if (gotGuiInfo && gui.HwndCaret != IntPtr.Zero)
        {
            // rcCaret is in the caret window's client coordinates.
            var origin = ClientToScreen(gui.HwndCaret, gui.RcCaret.Left, gui.RcCaret.Top);
            return origin;
        }

        // 2. Focused window's bottom-left corner (with left padding).
        // Only use HwndFocus if we successfully got GUI info and it's non-zero.
        if (gotGuiInfo && gui.HwndFocus != IntPtr.Zero &&
            TryGetWindowRect(gui.HwndFocus, out NativeMethods.Rect rect))
        {
            return new Point(rect.Left + 16, rect.Bottom);
        }

        // 3. Foreground window rect.
        if (foregroundWindow != IntPtr.Zero &&
            TryGetWindowRect(foregroundWindow, out NativeMethods.Rect rect2))
        {
            return new Point(rect2.Left + 16, rect2.Bottom);
        }

        // 4. Mouse cursor.
        return GetCursorPosition();
    }

    /// <summary>Places <paramref name="popup"/> near <paramref name="anchor"/>
    /// using its actual rendered size, clamped to the monitor work area.</summary>
    public void Place(Window popup, Point anchor)
    {
        popup.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        double width = popup.DesiredSize.Width;
        double height = popup.DesiredSize.Height;

        Rect workArea = GetWorkAreaFor(anchor);
        double x = anchor.X;
        double y = anchor.Y + AnchorGap;

        // Flip above the anchor when there is not enough room below.
        if (y + height > workArea.Bottom && anchor.Y - height - AnchorGap >= workArea.Top)
            y = anchor.Y - height - AnchorGap;

        // Keep horizontal position clamped to work area.
        x = Math.Clamp(x, workArea.Left, Math.Max(workArea.Left, workArea.Right - width));
        y = Math.Clamp(y, workArea.Top, Math.Max(workArea.Top, workArea.Bottom - height));

        popup.Left = x;
        popup.Top = y;
    }

    private static Point ClientToScreen(IntPtr hwnd, int clientX, int clientY)
    {
        var point = new NativeMethods.Point { X = clientX, Y = clientY };
        return NativeMethods.ClientToScreen(hwnd, ref point)
            ? new Point(point.X, point.Y)
            : new Point(clientX, clientY);
    }

    private static bool TryGetWindowRect(IntPtr hwnd, out NativeMethods.Rect rect)
    {
        rect = default;
        return hwnd != IntPtr.Zero && NativeMethods.GetWindowRect(hwnd, out rect);
    }

    private static Point GetCursorPosition()
    {
        NativeMethods.GetCursorPos(out NativeMethods.Point point);
        return new Point(point.X, point.Y);
    }

    private static Rect GetWorkAreaFor(Point anchor)
    {
        IntPtr monitor = NativeMethods.MonitorFromPoint(
            new NativeMethods.Point { X = (int)anchor.X, Y = (int)anchor.Y },
            2 /* MONITOR_DEFAULTTONEAREST */);
        if (monitor == IntPtr.Zero) return SystemParameters.WorkArea;

        var info = new NativeMethods.MonitorInfo
        {
            CbSize = System.Runtime.InteropServices.Marshal.SizeOf<NativeMethods.MonitorInfo>(),
        };
        if (!NativeMethods.GetMonitorInfoW(monitor, ref info)) return SystemParameters.WorkArea;

        return new Rect(
            info.RcWork.Left, info.RcWork.Top,
            info.RcWork.Right - info.RcWork.Left,
            info.RcWork.Bottom - info.RcWork.Top);
    }
}
