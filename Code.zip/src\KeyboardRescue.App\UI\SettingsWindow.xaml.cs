using System.Windows;
using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Settings;

namespace KeyboardRescue.App.UI;

/// <summary>
/// The settings dialog. Plain controls, no surprises: every checkbox maps
/// one-to-one to an <see cref="AppSettings"/> property. Cancel leaves the
/// running configuration untouched.
/// </summary>
public partial class SettingsWindow : Window
{
    private readonly AppSettings _original;

    /// <summary>The saved settings, or the original when cancelled.</summary>
    public AppSettings Result { get; private set; }

    public SettingsWindow(AppSettings current)
    {
        InitializeComponent();
        _original = current ?? throw new ArgumentNullException(nameof(current));
        Result = current;

        EnabledBox.IsChecked = current.Enabled;
        HebrewBox.IsChecked = current.EnableHebrewSuggestions;
        EnglishBox.IsChecked = current.EnableEnglishSuggestions;
        SoundBox.IsChecked = current.PlaySound;
        StartupBox.IsChecked = current.LaunchAtStartup;
        UnknownSecureBox.IsChecked = current.AllowUnknownSecureState;
        ShortcutBox.Text = current.GlobalShortcut;
        DebounceSlider.Value = current.DebounceMilliseconds;

        SensitivityCombo.ItemsSource = new[] { "Low", "Medium", "High" };
        SensitivityCombo.SelectedIndex = current.Sensitivity switch
        {
            Sensitivity.Low => 0,
            Sensitivity.High => 2,
            _ => 1,
        };

        DebounceSlider.ValueChanged += (_, _) => UpdateDebounceLabel();
        UpdateDebounceLabel();
    }

    private void UpdateDebounceLabel() =>
        DebounceLabel.Text = $"{(int)DebounceSlider.Value} ms";

    private void OnSave(object sender, RoutedEventArgs e)
    {
        Result = _original with
        {
            Enabled = EnabledBox.IsChecked == true,
            EnableHebrewSuggestions = HebrewBox.IsChecked == true,
            EnableEnglishSuggestions = EnglishBox.IsChecked == true,
            PlaySound = SoundBox.IsChecked == true,
            LaunchAtStartup = StartupBox.IsChecked == true,
            AllowUnknownSecureState = UnknownSecureBox.IsChecked == true,
            GlobalShortcut = ShortcutBox.Text,
            Sensitivity = SensitivityCombo.SelectedIndex switch
            {
                0 => Sensitivity.Low,
                2 => Sensitivity.High,
                _ => Sensitivity.Medium,
            },
            DebounceMilliseconds = (int)DebounceSlider.Value,
        };
        DialogResult = true;
    }

    private void OnCancel(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }
}
