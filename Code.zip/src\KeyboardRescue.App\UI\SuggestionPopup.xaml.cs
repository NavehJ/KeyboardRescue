using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using KeyboardRescue.Core.Detection;
using Color = System.Windows.Media.Color;
using FlowDirection = System.Windows.FlowDirection;
using Point = System.Windows.Point;
using Size = System.Windows.Size;

namespace KeyboardRescue.App.UI;

/// <summary>
/// The suggestion popup. Design constraints, all deliberate:
/// <list type="bullet">
/// <item><c>WS_EX_NOACTIVATE</c>: showing the popup never steals focus from
/// the application the user is typing in. Enter/Esc reach it through the
/// keyboard hook, not through focus.</item>
/// <item>RTL-aware: a Hebrew candidate renders right-to-left, an English
/// one left-to-right, matching the text being offered.</item>
/// <item>Auto-hides after the configured timeout so a missed popup never
/// lingers over the user's work.</item>
/// <item>Compact and semi-transparent: it should read as a hint, not a
/// dialog.</item>
/// </list>
/// </summary>
public partial class SuggestionPopup : Window
{
    private const int GwlexStyle = -20;
    private const int WsExNoactivate = 0x08000000;
    private const int WsExToolwindow = 0x00000080;

    private readonly System.Windows.Threading.DispatcherTimer _autoHideTimer;
    private readonly Action? _onAccept;
    private readonly Action? _onDismiss;

    public SuggestionPopup(Action? onAccept, Action? onDismiss)
    {
        _onAccept = onAccept;
        _onDismiss = onDismiss;
        InitializeComponent();

        _autoHideTimer = new System.Windows.Threading.DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(7000),
        };
        _autoHideTimer.Tick += (_, _) => RequestDismiss();

        SourceInitialized += (_, _) => ApplyNoActivateStyle();
        IsVisibleChanged += (_, _) =>
        {
            if (IsVisible) _autoHideTimer.Start();
            else _autoHideTimer.Stop();
        };
    }

    private static FlowDirection DominantScriptDirection(string text)
    {
        int hebrew = 0, latin = 0;
        foreach (char c in text)
        {
            if (c is >= '\u05D0' and <= '\u05EA') hebrew++;
            else if (c is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z')) latin++;
        }
        return hebrew > latin ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;
    }

    /// <summary>Shows the popup for <paramref name="suggestion"/> at the
    /// resolved anchor point.</summary>
    public void ShowFor(Suggestion suggestion, Point anchor, int autoHideMs)
    {
        CandidateText.Text = suggestion.CandidateText;
        TitleText.Text = suggestion.Direction switch
        {
            CorrectionDirection.ToHebrew => "This should be Hebrew",
            CorrectionDirection.ToEnglish => "This should be English",
            _ => "Mixed layout mistakes",
        };

        // Direction-aware layout: the candidate block flows the way the
        // candidate text reads. A mixed candidate follows its dominant
        // script so the popup stays readable either way.
        FlowDirection candidateDirection = suggestion.Direction == CorrectionDirection.ToHebrew
            ? FlowDirection.RightToLeft
            : suggestion.Direction == CorrectionDirection.ToEnglish
                ? FlowDirection.LeftToRight
                : DominantScriptDirection(suggestion.CandidateText);
        CandidateText.FlowDirection = candidateDirection;
        RootPanel.FlowDirection = FlowDirection.LeftToRight; // hints stay LTR-neutral

        TitleText.Foreground = suggestion.Strength == SuggestionStrength.Strong
            ? new SolidColorBrush(Color.FromRgb(0x2E, 0x7D, 0x32))
            : new SolidColorBrush(Color.FromRgb(0x55, 0x55, 0x55));

        if (autoHideMs > 0) _autoHideTimer.Interval = TimeSpan.FromMilliseconds(autoHideMs);

        // Force layout so positioning uses the real size.
        Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
        Arrange(new Rect(DesiredSize));
        UpdateLayout();

        new PopupPositioningService().Place(this, anchor);
        Show();
    }

    public void HidePopup()
    {
        _autoHideTimer.Stop();
        Hide();
    }

    private void RequestDismiss() => _onDismiss?.Invoke();

    private void OnPopupClicked(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        // Clicking the popup is treated as acceptance: the user pointed at
        // the correction they want.
        _onAccept?.Invoke();
    }

    private void OnClosed(object? sender, EventArgs e) => _autoHideTimer.Stop();

    private void ApplyNoActivateStyle()
    {
        IntPtr hwnd = new WindowInteropHelper(this).Handle;
        int exStyle = GetWindowLong(hwnd, GwlexStyle);
        SetWindowLong(hwnd, GwlexStyle, exStyle | WsExNoactivate | WsExToolwindow);
    }

    [DllImport("user32.dll")]
    private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
}
