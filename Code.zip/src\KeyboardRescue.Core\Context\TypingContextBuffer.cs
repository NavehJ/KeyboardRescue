using System.Text;
using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Context;

/// <summary>
/// An atomic view of the buffer, safe to hand to a background analysis task.
/// </summary>
public sealed record ContextSnapshot(string Text, string Segment, string PrecedingText, int Version);

/// <summary>
/// A validated edit to apply to the application's text via synthetic input.
/// <see cref="BackspaceCount"/> characters are deleted before the caret and
/// <see cref="TextToInsert"/> is typed in their place.
/// </summary>
public sealed record ReplacementPlan(
    int Version,
    int BackspaceCount,
    string TextToInsert,
    int BufferStart,
    int ReplacedLength);

/// <summary>
/// Tracks the text the user has typed since the last boundary so the
/// detection engine has something to analyze. Bounded, thread-safe and
/// side-effect free: it never touches the real caret, clipboard or OS.
///
/// Semantics:
/// <list type="bullet">
/// <item>The buffer mirrors a single caret-position view of one focused
/// control. It is rebuilt only from keystrokes the hook observes, so it can
/// drift; every replacement is therefore revalidated against the buffer
/// before any synthetic input is sent.</item>
/// <item>A "segment" is the text since the last boundary (Enter, Tab, caret
/// jump, mouse click, focus change...). Only the segment is analyzed;
/// everything before it is retained as a bounded context window for the
/// language prior.</item>
/// <item>Backspace deletes from the end of the buffer; if the user deletes
/// across the segment boundary the boundary slides with it, so the segment
/// never contains a hole.</item>
/// </list>
/// </summary>
public sealed class TypingContextBuffer
{
    /// <summary>Kept small on purpose: enough for a paragraph of context,
    /// bounded memory and bounded analysis work per keystroke.</summary>
    public const int DefaultCapacity = 400;

    /// <summary>How much pre-segment context is handed to the scorer as the
    /// language prior window.</summary>
    public const int DefaultPrecedingWindow = 120;

    private readonly object _gate = new();
    private readonly StringBuilder _text = new();
    private int _segmentStart;
    private int _version;

    public TypingContextBuffer(
        int capacity = DefaultCapacity,
        int precedingWindow = DefaultPrecedingWindow)
    {
        if (capacity < 1) throw new ArgumentOutOfRangeException(nameof(capacity));
        if (precedingWindow < 0) throw new ArgumentOutOfRangeException(nameof(precedingWindow));
        Capacity = capacity;
        PrecedingWindow = precedingWindow;
    }

    public int Capacity { get; }
    public int PrecedingWindow { get; }

    /// <summary>Increments on every mutation; used to detect stale analyses.</summary>
    public int Version { get { lock (_gate) return _version; } }

    public ContextSnapshot Snapshot()
    {
        lock (_gate)
        {
            return new ContextSnapshot(
                _text.ToString(),
                _text.ToString(_segmentStart, _text.Length - _segmentStart),
                _text.ToString(Math.Max(0, _segmentStart - PrecedingWindow),
                    Math.Min(PrecedingWindow, _segmentStart)),
                _version);
        }
    }

    /// <summary>Records one typed character at the caret.</summary>
    public void AppendChar(char c)
    {
        lock (_gate)
        {
            _text.Append(c);
            TrimToFront();
            _version++;
        }
    }

    /// <summary>Records a run of typed characters (autocorrect, IME commits,
    /// synthetic unicode input from our own replacement).</summary>
    public void AppendText(string text)
    {
        ArgumentNullException.ThrowIfNull(text);
        lock (_gate)
        {
            _text.Append(text);
            TrimToFront();
            _version++;
        }
    }

    /// <summary>Records <paramref name="count"/> backspaces. The segment
    /// shrinks; deleting past the boundary slides the boundary with it.</summary>
    public void Backspace(int count = 1)
    {
        if (count < 0) throw new ArgumentOutOfRangeException(nameof(count));
        lock (_gate)
        {
            int newLength = Math.Max(0, _text.Length - count);
            if (newLength == _text.Length) return;
            _text.Length = newLength;
            if (_segmentStart > newLength) _segmentStart = newLength;
            _version++;
        }
    }

    /// <summary>The caret moved somewhere we can no longer reason about
    /// (Enter, Tab, arrow keys, mouse, focus change). The current segment
    /// becomes context; typing resumes analyzable from an empty segment.</summary>
    public void BreakSegment()
    {
        lock (_gate)
        {
            _segmentStart = _text.Length;
            _version++;
        }
    }

    /// <summary>Everything we thought we knew is wrong (paste, programmatic
    /// text change, layout switch). Drop the entire window.</summary>
    public void Reset()
    {
        lock (_gate)
        {
            _text.Clear();
            _segmentStart = 0;
            _version++;
        }
    }

    /// <summary>
    /// Validates that <paramref name="suggestion"/> still matches the tail of
    /// the buffer as of <paramref name="observedVersion"/>, and turns it into
    /// a concrete edit plan. Returns false - and plans nothing - whenever the
    /// buffer moved since the analysis ran, so the caller must send nothing.
    /// </summary>
    public bool TryPlanReplacement(Suggestion suggestion, int observedVersion, out ReplacementPlan plan)
    {
        ArgumentNullException.ThrowIfNull(suggestion);
        lock (_gate)
        {
            plan = null!;
            if (observedVersion != _version) return false;

            int start = _segmentStart + suggestion.ReplacementStartOffset;
            int end = start + suggestion.ReplacementLength;
            if (suggestion.ReplacementStartOffset < 0 ||
                suggestion.ReplacementLength != suggestion.OriginalText.Length ||
                start < _segmentStart || end > _text.Length)
                return false;

            // The edit is applied by backspacing to the caret, so the range
            // must end exactly where the user last typed. Anything after it
            // (or a caret we lost track of) means: do not touch the app.
            if (end != _text.Length) return false;

            if (string.CompareOrdinal(
                    _text.ToString(start, suggestion.ReplacementLength),
                    suggestion.OriginalText) != 0)
                return false;

            // Deletion is performed as one backspace per UTF-16 code unit,
            // which is exactly what the hook recorded being typed. That is
            // correct for every BMP character (all Hebrew, Latin and
            // punctuation). A supplementary character, however, is ONE
            // grapheme but TWO UTF-16 units, and grapheme-aware applications
            // delete it with a SINGLE backspace - so a code-unit count would
            // over-delete and corrupt neighbouring text. Refuse instead of
            // guessing: fail safe, never replace what we cannot count
            // reliably.
            if (ContainsSupplementaryCharacter(suggestion.OriginalText))
                return false;

            plan = new ReplacementPlan(
                Version: _version,
                BackspaceCount: suggestion.ReplacementLength,
                TextToInsert: suggestion.CandidateText,
                BufferStart: start,
                ReplacedLength: suggestion.ReplacementLength);
            return true;
        }
    }

    /// <summary>
    /// Applies a previously planned edit to the buffer after the synthetic
    /// input has been sent, keeping the mirror in sync with the application.
    /// Returns false if the buffer changed in the meantime (caller should
    /// <see cref="Reset"/>); the injected keystrokes themselves are filtered
    /// out by the hook and never reach this buffer twice.
    /// </summary>
    public bool CommitReplacement(ReplacementPlan plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        lock (_gate)
        {
            if (plan.Version != _version) return false;
            if (plan.BufferStart < 0 || plan.BufferStart + plan.ReplacedLength > _text.Length)
                return false;

            _text.Remove(plan.BufferStart, plan.ReplacedLength);
            _text.Append(plan.TextToInsert);
            _version++;
            return true;
        }
    }

    /// <summary>
    /// True when the text contains any supplementary character (a code point
    /// outside the Basic Multilingual Plane, encoded as a UTF-16 surrogate
    /// pair). Such characters cannot be deleted reliably with per-code-unit
    /// backspaces, so replacement is refused for ranges containing them.
    /// </summary>
    private static bool ContainsSupplementaryCharacter(string text)
    {
        foreach (char c in text)
        {
            if (char.IsHighSurrogate(c) || char.IsLowSurrogate(c))
                return true;
        }
        return false;
    }

    private void TrimToFront()
    {
        int overflow = _text.Length - Capacity;
        if (overflow <= 0) return;
        _text.Remove(0, overflow);
        _segmentStart = Math.Max(0, _segmentStart - overflow);
    }
}
