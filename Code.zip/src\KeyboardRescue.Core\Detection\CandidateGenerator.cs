using System.Text;
using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.Core.Detection;

public sealed record GeneratedCandidate(
    string Text,
    int FlippedWords,
    int ConvertibleWords,
    IReadOnlyList<WordDecision> Decisions);

/// <summary>
/// One word's verdict. <see cref="Direction"/> is the direction implied by
/// the word's own script - Latin words can only be wrong-layout Hebrew
/// (ToHebrew), Hebrew words only wrong-layout English (ToEnglish) - so a
/// segment may hold both directions at once. <see cref="Replaced"/> words
/// appear as <see cref="Converted"/> in the candidate text.
/// <para>
/// The span [<see cref="Start"/>, +<see cref="Length"/>) is the chosen
/// reading: the word alone, or the word plus attached punctuation that is
/// a *letter position* in the other layout (Hebrew 'w' key produces the
/// apostrophe, the comma key produces tav, the period key final tsadi,
/// the semicolon key final pe) - the wrong-layout form of "how" is "ים'"
/// and of "שכנות" is "afbu,". <see cref="WordRealism"/> is the word's own
/// realism in its own language (the bar the conversion must clear, so
/// valid words are never dragged down by punctuation); <see cref="SourceRealism"/>
/// is the chosen source text's realism (single-word evidence).
/// </para>
/// </summary>
public sealed record WordDecision(
    int Start,
    int Length,
    string Original,
    string Converted,
    bool Replaced,
    CorrectionDirection Direction,
    double WordRealism,
    double SourceRealism,
    double ConvertedRealism)
{
    /// <summary>Where the word itself starts (the span may start before it
    /// when a leading letter-position punctuation is attached).</summary>
    public int WordStart { get; init; }
}

/// <summary>
/// Builds the corrected candidate for a segment:
/// <list type="bullet">
/// <item>every word is judged in the direction of its own script, so mixed
/// segments (correct English next to wrong-layout Hebrew, or vice versa)
/// convert only their mistyped words;</item>
/// <item>a word is replaced only when the converted form beats its own
/// realism by a margin - a word that is already plausible in its own
/// language is never flipped;</item>
/// <item>a word the scorer could not approve but that looks like gibberish
/// is re-read positionally when it sits next to a converted word - unless
/// it is valid text, which is always preserved (propagated iteratively so
/// chains like "t,v" next to a converted word resolve fully);</item>
/// <item>short valid words with plausible target readings (e.g. "to" / "אם")
/// flip only inside a segment-coherent run: one direction, at least 3 long
/// flipped words, whole-segment conversion clearly beating the original,
/// and adjacency to a flipped word;</item>
/// <item>punctuation/symbols are remapped positionally only between two
/// replaced words of the same direction.</item>
/// </list>
/// </summary>
public sealed class CandidateGenerator
{
    private readonly KeyboardLayoutMapper _mapper = new();

    /// <summary>The correction's direction for UI purposes: the single
    /// direction when all replaced words agree, <see cref="CorrectionDirection.Mixed"/>
    /// when the segment converts both ways at once.</summary>
    public static CorrectionDirection DominantDirection(IReadOnlyList<WordDecision> decisions)
    {
        bool anyHebrewFlips = false, anyEnglishFlips = false;
        foreach (var d in decisions)
        {
            if (!d.Replaced) continue;
            if (d.Direction == CorrectionDirection.ToHebrew) anyHebrewFlips = true;
            else anyEnglishFlips = true;
        }
        return anyHebrewFlips && anyEnglishFlips
            ? CorrectionDirection.Mixed
            : anyHebrewFlips ? CorrectionDirection.ToHebrew : CorrectionDirection.ToEnglish;
    }

    public GeneratedCandidate Generate(string segment, LanguageData data,
        DetectionOptions options, IKeyboardLayout hebrewLayout)
    {
        ArgumentNullException.ThrowIfNull(segment);
        ArgumentNullException.ThrowIfNull(data);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(hebrewLayout);

        var tokens = TextTokenizer.Tokenize(segment);
        var units = BuildUnits(segment, tokens, hebrewLayout);

        // --- pass 1: decide every word in the direction of its own script.
        var decisions = new List<WordDecision>(units.Count);
        foreach (var unit in units)
        {
            var script = TextScript.Of(unit.Word);
            if (script is TextScript.Kind.Mixed or TextScript.Kind.None)
                continue; // not judgeable: keep verbatim

            bool toHebrew = script == TextScript.Kind.Latin;
            var direction = toHebrew ? CorrectionDirection.ToHebrew : CorrectionDirection.ToEnglish;
            IKeyboardLayout sourceLayout = toHebrew ? KeyboardLayoutCatalog.UsQwerty : hebrewLayout;
            IKeyboardLayout targetLayout = toHebrew ? hebrewLayout : KeyboardLayoutCatalog.UsQwerty;
            WordFrequencyList sourceWords = toHebrew ? data.EnglishWords : data.HebrewWords;
            WordFrequencyList targetWords = toHebrew ? data.HebrewWords : data.EnglishWords;
            CharacterNgramModel sourceModel = toHebrew ? data.EnglishModel : data.HebrewModel;
            CharacterNgramModel targetModel = toHebrew ? data.HebrewModel : data.EnglishModel;

            // Own-language realism is judged on the word text alone: that
            // is the bar the conversion must clear, so a valid word can
            // never be dragged down (or lifted) by punctuation attached
            // to it.
            double wordRealism = WordScorer.Realism(unit.Word, sourceWords, sourceModel, data.Allowlist);

            string wordConverted = ConvertSymbol(unit.Word, direction, hebrewLayout);
            double wordConvertedRealism = WordScorer.Realism(
                wordConverted, targetWords, targetModel, data.Allowlist);

            // Two readings of the same keys - the word alone, or the word
            // plus attached letter-position punctuation ("akuo," as
            // "שלום" + comma vs "cug," as the whole of "בועת"). The
            // better conversion wins, so punctuation joins the word only
            // when it belongs there.
            string unitConverted = unit.HasPunctuation
                ? ConvertSymbol(unit.Text, direction, hebrewLayout)
                : wordConverted;
            double unitConvertedRealism = unit.HasPunctuation
                ? WordScorer.Realism(unitConverted, targetWords, targetModel, data.Allowlist)
                : wordConvertedRealism;

            bool useUnit = unit.HasPunctuation
                && unitConvertedRealism > wordConvertedRealism;

            string sourceText = useUnit ? unit.Text : unit.Word;
            string converted = useUnit ? unitConverted : wordConverted;
            double convertedRealism = useUnit ? unitConvertedRealism : wordConvertedRealism;
            double sourceRealism = WordScorer.Realism(
                sourceText, sourceWords, sourceModel, data.Allowlist);

            // Comparative by design: the converted form must clearly beat
            // the word's own realism AND clear the absolute (low) floor.
            bool replaced = convertedRealism >= options.FlipQualityThreshold
                && convertedRealism > wordRealism + options.FlipMargin;

            decisions.Add(new WordDecision(
                useUnit ? unit.Start : unit.WordStart,
                useUnit ? unit.Length : unit.WordLength,
                sourceText, converted, replaced, direction,
                wordRealism, sourceRealism, convertedRealism)
            {
                WordStart = unit.WordStart,
            });
        }

        // --- pass 2: re-read gibberish units inside a run of replaced units.
        // Runs iteratively until stable so chains like "t,v rumv" propagate:
        // v flips because it sits next to rumv, then t flips because it sits
        // next to v, then the comma between two replaced words remaps.
        // Only units that look like gibberish in their own language are
        // re-read here; valid text is preserved (see pass 3 for short-word
        // context handling).
        bool changed = true;
        int guard = 0;
        while (changed && guard++ < decisions.Count + 1)
        {
            changed = false;
            for (int i = 0; i < decisions.Count; i++)
            {
                if (decisions[i].Replaced) continue;
                if (decisions[i].WordRealism >= options.ReReadMaxOriginalRealism) continue;

                bool prevReplaced = i > 0 && decisions[i - 1].Replaced;
                bool nextReplaced = i < decisions.Count - 1 && decisions[i + 1].Replaced;
                if (!prevReplaced && !nextReplaced) continue;

                decisions[i] = decisions[i] with { Replaced = true };
                changed = true;
            }
        }

        // --- pass 3: segment-coherent short-word handling.
        // A short valid word (e.g. "to" -> "אם") can never flip on its own
        // comparative margin because both readings are dictionary words.
        // But when the complete segment is clearly wrong-layout text in one
        // direction, short words with plausible target readings are re-read.
        // This evaluates the complete-segment candidate alongside token-level
        // evidence, gated by strict thresholds so valid text never flips:
        //  - at least 3 long words already flipped in the same direction;
        //  - the whole-segment conversion scores clearly above the original;
        //  - the short word itself has a plausible target realism.
        TryFlipShortWordsInCoherentSegment(segment, decisions, data, options, hebrewLayout);

        // --- assemble ------------------------------------------------------
        var byWordStart = new Dictionary<int, WordDecision>();
        foreach (var d in decisions) byWordStart[d.WordStart] = d;

        // Punctuation covered by a replaced unit is emitted with it and
        // must not be emitted (or remapped) a second time.
        var absorbed = new HashSet<int>();
        foreach (var d in decisions)
        {
            if (!d.Replaced) continue;
            foreach (var t in tokens)
            {
                if (t.Kind == TextTokenKind.Word) continue;
                if (t.Start >= d.Start && t.Start + t.Length <= d.Start + d.Length)
                    absorbed.Add(t.Start);
            }
        }

        var sb = new StringBuilder(segment.Length + 8);
        foreach (var token in tokens)
        {
            if (absorbed.Contains(token.Start)) continue;

            if (token.Kind == TextTokenKind.Word)
            {
                sb.Append(byWordStart.TryGetValue(token.Start, out var d) && d.Replaced
                    ? d.Converted
                    : TextTokenizer.Slice(segment, token));
            }
            else if (token.Kind is TextTokenKind.Punctuation or TextTokenKind.Symbol or TextTokenKind.Number)
            {
                sb.Append(TryRemapSymbol(tokens, token, byWordStart, segment, hebrewLayout, out string remapped)
                    ? remapped
                    : TextTokenizer.Slice(segment, token));
            }
            else
            {
                sb.Append(TextTokenizer.Slice(segment, token));
            }
        }

        int replacedCount = 0;
        foreach (var d in decisions) if (d.Replaced) replacedCount++;

        return new GeneratedCandidate(sb.ToString(), replacedCount, decisions.Count, decisions);
    }

    /// <summary>A word plus immediately adjacent punctuation that is a
    /// letter position in the other layout. <see cref="WordStarting"/> /
    /// <see cref="WordLength"/> isolate the word inside
    /// [<see cref="Start"/>, +<see cref="Length"/>).</summary>
    private readonly record struct WordUnit(
        int Start, int Length, int WordStarting, int WordLength, string Word, string Text)
    {
        public int WordStart => WordStarting;
        public bool HasPunctuation => Length != WordLength;
    }

    /// <summary>
    /// Groups each word with punctuation immediately attached to it when
    /// that punctuation's key position produces a letter in the other
    /// layout. The punctuation must also sit at a segment boundary on its
    /// own far side (segment edge or whitespace) so punctuation wedged
    /// between two words is never claimed twice.
    /// </summary>
    private List<WordUnit> BuildUnits(string segment, List<TextToken> tokens, IKeyboardLayout hebrewLayout)
    {
        var units = new List<WordUnit>(8);
        for (int i = 0; i < tokens.Count; i++)
        {
            if (tokens[i].Kind != TextTokenKind.Word) continue;

            int wordStart = tokens[i].Start;
            int wordLength = tokens[i].Length;
            int start = wordStart;
            int end = wordStart + wordLength;
            string word = TextTokenizer.Slice(segment, tokens[i]);
            var direction = DirectionForWord(word);

            // Leading punctuation, with whitespace or the segment edge
            // before it.
            if (direction is not null
                && i >= 1 && tokens[i - 1].Kind == TextTokenKind.Punctuation
                && (i == 1 || tokens[i - 2].Kind == TextTokenKind.Whitespace)
                && tokens[i - 1].Start + tokens[i - 1].Length == start
                && IsLetterPosition(TextTokenizer.Slice(segment, tokens[i - 1]), direction.Value, hebrewLayout))
            {
                start = tokens[i - 1].Start;
            }

            // Trailing punctuation, with whitespace or the segment edge
            // after it.
            if (direction is not null
                && i + 1 < tokens.Count
                && tokens[i + 1].Kind == TextTokenKind.Punctuation
                && (i + 2 == tokens.Count || tokens[i + 2].Kind == TextTokenKind.Whitespace)
                && end == tokens[i + 1].Start
                && IsLetterPosition(TextTokenizer.Slice(segment, tokens[i + 1]), direction.Value, hebrewLayout))
            {
                end = tokens[i + 1].Start + tokens[i + 1].Length;
            }

            units.Add(new WordUnit(start, end - start, wordStart, wordLength, word,
                segment.Substring(start, end - start)));
        }
        return units;
    }

    private static CorrectionDirection? DirectionForWord(string word) =>
        TextScript.Of(word) switch
        {
            TextScript.Kind.Latin => CorrectionDirection.ToHebrew,
            TextScript.Kind.Hebrew => CorrectionDirection.ToEnglish,
            _ => null,
        };

    /// <summary>
    /// True when the punctuation character's key position produces a
    /// letter in the target layout - i.e. it is a letter position in the
    /// wrong-layout sense, not punctuation that means what it says.
    /// </summary>
    private bool IsLetterPosition(string piece, CorrectionDirection direction, IKeyboardLayout hebrewLayout)
    {
        if (piece.Length != 1) return false;
        string converted = ConvertSymbol(piece, direction, hebrewLayout);
        if (converted.Length != 1) return false;
        char c = converted[0];
        return direction == CorrectionDirection.ToHebrew
            ? TextScript.IsHebrewLetter(c)
            : TextScript.IsLatinLetter(c);
    }

    private string ConvertSymbol(string piece, CorrectionDirection direction, IKeyboardLayout hebrewLayout) =>
        _mapper.Convert(piece,
            direction == CorrectionDirection.ToHebrew ? KeyboardLayoutCatalog.UsQwerty : hebrewLayout,
            direction == CorrectionDirection.ToHebrew ? hebrewLayout : KeyboardLayoutCatalog.UsQwerty);

    /// <summary>
    /// Remaps a punctuation/symbol/number token positionally when the
    /// words immediately before and after it are replaced (or missing at
    /// the segment edge) and agree on direction - a '/' between two
    /// converted Latin words is the Hebrew sentence dot; a '.' between two
    /// converted Hebrew words is the QWERTY slash. A replaced word next to
    /// a kept word means the symbol is intentional and stays.
    /// </summary>
    private bool TryRemapSymbol(List<TextToken> tokens, TextToken token,
        Dictionary<int, WordDecision> byWordStart, string segment,
        IKeyboardLayout hebrewLayout, out string remapped)
    {
        remapped = string.Empty;

        WordDecision? prev = null, next = null;
        for (int i = 0; i < tokens.Count; i++)
        {
            if (tokens[i].Kind != TextTokenKind.Word) continue;
            if (tokens[i].Start + tokens[i].Length <= token.Start)
            {
                byWordStart.TryGetValue(tokens[i].Start, out prev);
            }
            else if (tokens[i].Start >= token.Start + token.Length && next is null)
            {
                byWordStart.TryGetValue(tokens[i].Start, out next);
                break;
            }
        }

        bool prevOk = prev is null || prev.Replaced;
        bool nextOk = next is null || next.Replaced;
        if (!prevOk || !nextOk) return false;

        var direction = prev?.Direction ?? next?.Direction;
        if (direction is null) return false;
        if (prev is not null && next is not null && prev.Direction != next.Direction)
            return false; // ambiguous: English comma next to Hebrew dot

        string piece = TextTokenizer.Slice(segment, token);
        remapped = ConvertSymbol(piece, direction.Value, hebrewLayout);
        return remapped != piece;
    }

    /// <summary>
    /// Complete-segment evaluation for short ambiguous words. Token-level
    /// comparison alone can never flip "to" -&gt; "אם" because both are valid
    /// dictionary words. When the whole segment is clearly wrong-layout text,
    /// short words with plausible target readings flip too. Strict gates:
    /// dominant single direction, at least 3 long flipped words, whole-segment
    /// conversion clearly beating the original, adjacency to a flipped word.
    /// </summary>
    private void TryFlipShortWordsInCoherentSegment(
        string segment,
        List<WordDecision> decisions,
        LanguageData data,
        DetectionOptions options,
        IKeyboardLayout hebrewLayout)
    {
        if (decisions.Count < 4) return;

        var dominant = DominantDirection(decisions);
        if (dominant == CorrectionDirection.Mixed) return;

        // Count long flipped words in the dominant direction. "Long" means
        // the word letters (excluding attached punctuation) are >= 3, so
        // "kgau," counts as long but "to" and "t" do not.
        int longFlipped = 0;
        foreach (var d in decisions)
        {
            if (!d.Replaced || d.Direction != dominant) continue;
            int wordLen = WordLetterLength(d);
            if (wordLen >= 3 && d.ConvertedRealism >= options.FlipQualityThreshold)
                longFlipped++;
        }
        if (longFlipped < 3) return;

        // Complete-segment candidate: convert the whole segment positionally
        // in the dominant direction and score both readings as whole text.
        // This is the segment-level evidence that token-level margins lack.
        double originalMean = MeanWordRealism(segment, dominant, sourceSide: true, data);
        string wholeConverted = ConvertSymbol(segment, dominant, hebrewLayout);
        double convertedMean = MeanWordRealism(wholeConverted, dominant, sourceSide: false, data);

        // Both gates must hold: the conversion must be plausible Hebrew/English
        // on its own, and clearly better than the original reading.
        if (convertedMean < 0.40) return;
        if (convertedMean <= originalMean + 0.10) return;

        // Iterate until stable so head-of-segment chains propagate: "to"
        // flips only after "t" flips, and "t" may flip in this same pass.
        bool changed = true;
        int guard = 0;
        while (changed && guard++ < decisions.Count + 1)
        {
            changed = false;
            for (int i = 0; i < decisions.Count; i++)
            {
                var d = decisions[i];
                if (d.Replaced || d.Direction != dominant) continue;
                if (WordLetterLength(d) > 2) continue;
                if (d.ConvertedRealism < 0.40) continue;

                bool prevReplaced = i > 0 && decisions[i - 1].Replaced
                    && decisions[i - 1].Direction == dominant;
                bool nextReplaced = i < decisions.Count - 1 && decisions[i + 1].Replaced
                    && decisions[i + 1].Direction == dominant;
                if (!prevReplaced && !nextReplaced) continue;

                decisions[i] = d with { Replaced = true };
                changed = true;
            }
        }
    }

    private static int WordLetterLength(WordDecision d)
    {
        // Original is either the bare word or word+attached punctuation.
        // Count letters only, so "kgau," counts as 4 (long) and "to" as 2.
        int n = 0;
        foreach (char c in d.Original)
            if (char.IsLetter(c)) n++;
        return n;
    }

    private static double MeanWordRealism(
        string text, CorrectionDirection direction, bool sourceSide, LanguageData data)
    {
        bool toHebrew = direction == CorrectionDirection.ToHebrew;
        // sourceSide=true scores the original words in their own script;
        // sourceSide=false scores the converted text in the target language.
        // Words of the opposite script are skipped (not evidence for this
        // direction).
        var tokens = TextTokenizer.Tokenize(text);
        double sum = 0;
        int count = 0;
        foreach (var t in tokens)
        {
            if (t.Kind != TextTokenKind.Word) continue;
            string word = TextTokenizer.Slice(text, t);
            var script = TextScript.Of(word);
            if (sourceSide)
            {
                if (toHebrew && script != TextScript.Kind.Latin) continue;
                if (!toHebrew && script != TextScript.Kind.Hebrew) continue;
                var model = toHebrew ? data.EnglishModel : data.HebrewModel;
                var list = toHebrew ? data.EnglishWords : data.HebrewWords;
                sum += WordScorer.Realism(word, list, model, data.Allowlist);
                count++;
            }
            else
            {
                if (toHebrew && script != TextScript.Kind.Hebrew) continue;
                if (!toHebrew && script != TextScript.Kind.Latin) continue;
                var model = toHebrew ? data.HebrewModel : data.EnglishModel;
                var list = toHebrew ? data.HebrewWords : data.EnglishWords;
                sum += WordScorer.Realism(word, list, model, data.Allowlist);
                count++;
            }
        }
        return count == 0 ? 0.0 : sum / count;
    }
}
