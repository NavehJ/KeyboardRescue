using System.Globalization;
using System.Text;

namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Character trigram model over " word " sequences taken from the local
/// frequency list. Judges whether a string looks like a language even when
/// its words are not dictionary hits (misspellings, morphology, names).
///
/// Interpolated trigram → bigram → unigram with a fixed backoff mass, so
/// probability is never zero. Scores are self-calibrating: normalization
/// anchors are the 10th/90th percentile of the model's own training words,
/// which avoids hand-tuned constants while staying deterministic.
/// </summary>
public sealed class CharacterNgramModel
{
    /// <summary>Backoff mass β interpolated into every denominator.</summary>
    private const double BackoffMass = 3.0;

    /// <summary>Lower clamp for per-character log-probabilities (log of ~1e-11).</summary>
    private const double FloorLogProbability = -25.0;

    private readonly Dictionary<string, int> _tri;
    private readonly Dictionary<string, int> _bi;
    private readonly Dictionary<char, int> _uni;
    private readonly long _uniTotal;
    private readonly double _lowAnchor;
    private readonly double _highAnchor;

    private CharacterNgramModel(Dictionary<string, int> tri, Dictionary<string, int> bi,
        Dictionary<char, int> uni, long uniTotal, double lowAnchor, double highAnchor)
    {
        _tri = tri;
        _bi = bi;
        _uni = uni;
        _uniTotal = uniTotal;
        _lowAnchor = lowAnchor;
        _highAnchor = highAnchor;
    }

    public static CharacterNgramModel Build(IEnumerable<string> words)
    {
        ArgumentNullException.ThrowIfNull(words);

        var tri = new Dictionary<string, int>();
        var bi = new Dictionary<string, int>();
        var uni = new Dictionary<char, int>();
        var corpus = new List<string>();

        foreach (string raw in words)
        {
            string word = Normalize(raw);
            if (word.Length == 0) continue;
            corpus.Add(word);

            string padded = " " + word + " ";
            for (int i = 0; i < padded.Length; i++)
            {
                char c = padded[i];
                char b = i >= 1 ? padded[i - 1] : ' ';
                char a = i >= 2 ? padded[i - 2] : ' ';

                Increment(uni, c);
                Increment(bi, TwoKey(b, c));
                Increment(tri, ThreeKey(a, b, c));
            }
        }

        long uniTotal = 0;
        foreach (int n in uni.Values) uniTotal += n;
        if (uniTotal == 0) throw new InvalidOperationException("Empty training corpus.");

        var model = new CharacterNgramModel(tri, bi, uni, uniTotal, lowAnchor: 0, highAnchor: 1);

        // Calibrate normalization anchors from the finished model so the
        // scoring of unknown text is relative to real-word typicality.
        var trainingScores = corpus.Select(model.AverageLogProbability).ToList();
        trainingScores.Sort();
        double low = Percentile(trainingScores, 0.10);
        double high = Percentile(trainingScores, 0.90);

        return new CharacterNgramModel(tri, bi, uni, uniTotal, low, Math.Max(high, low + 1e-6));
    }

    private static void Increment<T>(Dictionary<T, int> counts, T key) where T : notnull =>
        counts[key] = counts.TryGetValue(key, out int n) ? n + 1 : 1;

    private static double Percentile(List<double> sorted, double p)
    {
        if (sorted.Count == 0) return 0;
        double index = p * (sorted.Count - 1);
        int lo = (int)Math.Floor(index);
        int hi = (int)Math.Ceiling(index);
        if (lo == hi) return sorted[lo];
        return sorted[lo] + (sorted[hi] - sorted[lo]) * (index - lo);
    }

    /// <summary>Lowercases and drops combining marks (Hebrew niqqud, accents).</summary>
    public static string Normalize(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (char c in text)
        {
            if (char.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark)
                continue;
            sb.Append(char.ToLowerInvariant(c));
        }
        return sb.ToString();
    }

    /// <summary>Average per-character log-probability of the text under this model.</summary>
    public double AverageLogProbability(string normalizedText)
    {
        ArgumentNullException.ThrowIfNull(normalizedText);
        if (normalizedText.Length == 0) return FloorLogProbability;

        string padded = " " + normalizedText + " ";
        double sum = 0;
        for (int i = 0; i < padded.Length; i++)
        {
            char c = padded[i];
            char b = i >= 1 ? padded[i - 1] : ' ';
            char a = i >= 2 ? padded[i - 2] : ' ';
            double p = P3(a, b, c);
            double log = Math.Log(Math.Max(p, 1e-12));
            sum += Math.Max(log, FloorLogProbability);
        }
        return sum / padded.Length;
    }

    /// <summary>Scores text in [0,1]: 1.0 ≈ as typical as ordinary training words.</summary>
    public double Score(string text)
    {
        double avg = AverageLogProbability(Normalize(text));
        double score = (avg - _lowAnchor) / (_highAnchor - _lowAnchor);
        return Math.Clamp(score, 0.0, 1.0);
    }

    private double P3(char a, char b, char c)
    {
        double backoff = P2(b, c);
        int nab = _bi.TryGetValue(TwoKey(a, b), out int n) ? n : 0;
        int n3 = _tri.TryGetValue(ThreeKey(a, b, c), out int m) ? m : 0;
        return (n3 + BackoffMass * backoff) / (nab + BackoffMass);
    }

    private double P2(char b, char c)
    {
        double backoff = P1(c);
        int nb = _uni.TryGetValue(b, out int n) ? n : 0;
        int n2 = _bi.TryGetValue(TwoKey(b, c), out int m) ? m : 0;
        return (n2 + BackoffMass * backoff) / (nb + BackoffMass);
    }

    private double P1(char c) =>
        _uni.TryGetValue(c, out int n) ? (double)n / _uniTotal : 1e-9;

    private static string TwoKey(char b, char c) =>
        string.Create(2, (b, c), static (span, v) => { span[0] = v.b; span[1] = v.c; });

    private static string ThreeKey(char a, char b, char c) =>
        string.Create(3, (a, b, c), static (span, v) => { span[0] = v.a; span[1] = v.b; span[2] = v.c; });
}
