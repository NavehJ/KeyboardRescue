using System.Text.RegularExpressions;

namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Heuristic classifier that recognizes URLs, emails, paths, code, hashes,
/// identifiers and numeric-only strings so the engine can suppress
/// corrections on them. Conservative: every pattern is checked only against
/// the segment itself; nothing is interpreted or executed.
/// </summary>
public static partial class ContentClassifier
{
    [GeneratedRegex(@"^https?://\S+$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex SchemeUrl();

    [GeneratedRegex(@"(^|\s)(www\.[^\s]+\.[a-z]{2,})(\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex WwwUrl();

    [GeneratedRegex(@"\b[a-z0-9-]+(\.[a-z0-9-]+)+(/|\?|#)\S*", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex DomainWithPath();

    [GeneratedRegex(@"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$", RegexOptions.CultureInvariant)]
    private static partial Regex Email();

    [GeneratedRegex(@"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$", RegexOptions.CultureInvariant)]
    private static partial Regex Uuid();

    [GeneratedRegex(@"^(0x)?[0-9a-fA-F]{16,}$", RegexOptions.CultureInvariant)]
    private static partial Regex HexBlob();

    [GeneratedRegex(@"^[A-Za-z0-9+/=]{24,}$", RegexOptions.CultureInvariant)]
    private static partial Regex Base64ish();

    [GeneratedRegex(@"^[A-Za-z][A-Za-z0-9]*(_[A-Za-z0-9]+)+$", RegexOptions.CultureInvariant)]
    private static partial Regex SnakeCaseIdentifier();

    [GeneratedRegex(@"^[A-Z][A-Z0-9]*(\.[A-Z0-9]+)+$", RegexOptions.CultureInvariant)]
    private static partial Regex DottedConstant();

    [GeneratedRegex(@"\b[a-z0-9]+[-_][a-z0-9]+([-_][a-z0-9-]*)?\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex HyphenSeparatedWords();

    [GeneratedRegex(@"\b[a-z]+\d+[a-z0-9]*\b|\b\d+[a-z]+\d*\b", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex DigitInsideWord();

    // Uppercase-only on purpose: SQL/code keywords are conventionally
    // uppercase, while lowercase "from"/"where" are ordinary English words
    // that must never block prose.
    [GeneratedRegex(@"\b(SELECT|INSERT|UPDATE|DELETE|JOIN|WHERE|FROM|CREATE|DROP|ALTER)\b",
        RegexOptions.CultureInvariant)]
    private static partial Regex SqlKeyword();

    [GeneratedRegex(@"(^|[\s'""(])([A-Za-z]+[._][A-Za-z]+\.[A-Za-z]{1,5})$", RegexOptions.CultureInvariant)]
    private static partial Regex FilePathWithExtension();

    [GeneratedRegex(@"^[~./\\]|[A-Za-z]:\\|^\.\.?/", RegexOptions.CultureInvariant)]
    private static partial Regex PathStart();

    public static ContentKind Classify(string segment)
    {
        string text = segment.Trim();
        if (text.Length == 0) return ContentKind.PlainText;

        bool hasLetter = false;
        bool hasDigit = false;
        foreach (char c in text)
        {
            if (char.IsLetter(c)) hasLetter = true;
            else if (char.IsDigit(c)) hasDigit = true;
        }
        if (!hasLetter && hasDigit) return ContentKind.Numeric;

        if (SchemeUrl().IsMatch(text) || WwwUrl().IsMatch(text) || DomainWithPath().IsMatch(text))
            return ContentKind.Url;
        if (Email().IsMatch(text))
            return ContentKind.Email;
        if (Uuid().IsMatch(text) || HexBlob().IsMatch(text) || Base64ish().IsMatch(text))
            return ContentKind.HashLike;
        if (LooksLikeCode(text) || SqlKeyword().IsMatch(text))
            return ContentKind.CodeLike;
        if (SnakeCaseIdentifier().IsMatch(text) || DottedConstant().IsMatch(text))
            return ContentKind.Identifier;
        if (PathStart().IsMatch(text) || FilePathWithExtension().IsMatch(text))
            return ContentKind.FilePath;
        if (HasDigitNearSeparator(text))
            return ContentKind.Identifier;
        if (DigitInsideWord().IsMatch(text))
            return ContentKind.MixedTechnical;

        return ContentKind.PlainText;
    }

    /// <summary>Separator-joined fragments carrying digits ("abc123-def456").</summary>
    private static bool HasDigitNearSeparator(string text)
    {
        var match = HyphenSeparatedWords().Match(text);
        while (match.Success)
        {
            foreach (char c in match.Value)
                if (char.IsDigit(c)) return true;
            match = match.NextMatch();
        }
        return false;
    }

    private static bool LooksLikeCode(string text)
    {
        // Only unambiguous code structures; ordinary prose punctuation such
        // as parentheses, quotes or a single semicolon must NOT trigger this.
        // Note: '<'/'>' appear here because wrong-layout prose essentially
        // never produces them while markup always does - conservative block.
        return text.Contains('{') || text.Contains('}')
            || text.Contains('<') || text.Contains('>')
            || text.Contains("=>", StringComparison.Ordinal)
            || text.Contains("&&", StringComparison.Ordinal)
            || text.Contains("||", StringComparison.Ordinal)
            || text.Contains("<?", StringComparison.Ordinal)
            || text.Contains(";=", StringComparison.Ordinal)
            || text.Contains("();", StringComparison.Ordinal)
            || text.Contains("{}", StringComparison.Ordinal)
            || text.StartsWith('$'); // shell variable / command substitution
    }
}
