namespace KeyboardRescue.Core.Detection;

/// <summary>
/// What kind of text the segment looks like. Anything other than
/// <see cref="PlainText"/> strongly (or completely) suppresses suggestions:
/// technical strings must never be "corrected".
/// </summary>
public enum ContentKind
{
    /// <summary>Ordinary prose in some natural language.</summary>
    PlainText,

    /// <summary>http(s)://..., www...., domain.tld/...</summary>
    Url,

    /// <summary>someone@example.com</summary>
    Email,

    /// <summary>file paths, drives, UNC shares.</summary>
    FilePath,

    /// <summary>source code, markup, JSON, shell constructs.</summary>
    CodeLike,

    /// <summary>API_KEY_123, snake_case / CONSTANT identifiers.</summary>
    Identifier,

    /// <summary>UUIDs, hex hashes, base64-looking blobs.</summary>
    HashLike,

    /// <summary>digits and numeric punctuation only.</summary>
    Numeric,

    /// <summary>
    /// Prose with technical fragments embedded (e.g. "mp3", "abc123") -
    /// penalized, but not fully blocked.
    /// </summary>
    MixedTechnical,
}
