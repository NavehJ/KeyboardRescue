using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Orchestrates one analysis run: guard → per-word direction → generate
/// candidate → score → threshold. Pure, deterministic and side-effect free;
/// the app layer decides when and how often to call it.
/// </summary>
public sealed class DetectionEngine
{
    private readonly DetectionOptions _options;
    private readonly LanguageData _data;
    private readonly IKeyboardLayout _hebrewLayout;
    private readonly CandidateGenerator _generator;
    private readonly ScoringEngine _scorer;

    public DetectionEngine(
        DetectionOptions? options = null,
        LanguageData? data = null,
        IKeyboardLayout? hebrewLayout = null)
    {
        _options = options ?? DetectionOptions.Default;
        _data = data ?? LanguageData.Default;
        _hebrewLayout = hebrewLayout ?? KeyboardLayoutCatalog.HebrewStandard;
        _generator = new CandidateGenerator();
        _scorer = new ScoringEngine(_options, _data);
    }

    /// <summary>
    /// Analyzes the given segment. Returns null whenever no correction is
    /// advisable - which is the overwhelmingly common outcome. Direction is
    /// decided per word (a segment may convert in both directions at once);
    /// <see cref="Suggestion.Direction"/> reports the dominant one.
    /// </summary>
    public Suggestion? Analyze(AnalysisRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        var (segment, startOffset) = Trim(request.Segment);
        if (segment.Length == 0 || segment.Length > _options.MaxSegmentLength)
            return null;

        int letters = CountLetters(segment);
        if (letters < _options.MinSegmentLetters)
            return null;

        ContentKind kind = ContentClassifier.Classify(segment);
        if (IsHardBlocked(kind))
            return null;

        GeneratedCandidate candidate = _generator.Generate(
            segment, _data, _options, _hebrewLayout);
        if (candidate.FlippedWords == 0 || candidate.Text == segment)
            return null;

        ScoreBreakdown scores = _scorer.Score(
            segment, candidate.Decisions, kind, request.PrecedingText);

        if (scores.OriginalTextScore >= _options.OriginalPlausibilityCeiling)
            return null;
        if (scores.ConvertedTextScore < _options.MinCandidatePlausibility)
            return null;
        if (scores.PatternScore < _options.MinPatternScore)
            return null;
        if (scores.Confidence < _options.SuggestThreshold)
            return null;

        // One converted word is thin evidence: that word's own text (the
        // reading the user actually typed) must have looked like
        // gibberish in its own language. Judged per word - not over the
        // segment mean - so "hello akuo" (one wrong-layout word next to
        // valid English) is still offered, while a single word that
        // merely looks unusual is not.
        if (candidate.FlippedWords == 1)
        {
            foreach (var decision in candidate.Decisions)
            {
                if (decision.Replaced &&
                    decision.SourceRealism > _options.OriginalSingleFlipPlausibility)
                    return null;
            }
        }

        var strength = scores.Confidence >= _options.StrongThreshold
            ? SuggestionStrength.Strong
            : SuggestionStrength.Suggested;

        return new Suggestion(
            OriginalText: segment,
            CandidateText: candidate.Text,
            Direction: CandidateGenerator.DominantDirection(candidate.Decisions),
            Confidence: scores.Confidence,
            Strength: strength,
            Scores: scores,
            ReplacementStartOffset: startOffset,
            ReplacementLength: segment.Length);
    }

    private static bool IsHardBlocked(ContentKind kind) => kind is
        ContentKind.Url or ContentKind.Email or ContentKind.HashLike or
        ContentKind.CodeLike or ContentKind.Identifier or ContentKind.FilePath or
        ContentKind.Numeric;

    private static (string Segment, int StartOffset) Trim(string text)
    {
        int start = 0;
        while (start < text.Length && char.IsWhiteSpace(text[start])) start++;
        int end = text.Length;
        while (end > start && char.IsWhiteSpace(text[end - 1])) end--;
        return (text[start..end], start);
    }

    private static int CountLetters(string text)
    {
        int n = 0;
        foreach (char c in text) if (char.IsLetter(c)) n++;
        return n;
    }
}
