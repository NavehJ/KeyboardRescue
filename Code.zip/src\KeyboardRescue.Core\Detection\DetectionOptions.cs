namespace KeyboardRescue.Core.Detection;

/// <summary>Which layout the text should be re-read through.</summary>
public enum CorrectionDirection
{
    /// <summary>Latin text was typed; it should be Hebrew (same keys).</summary>
    ToHebrew,

    /// <summary>Hebrew text was typed; it should be English (same keys).</summary>
    ToEnglish,

    /// <summary>Both: the segment mixes directions (e.g. a correct English
    /// sentence with a wrong-layout Hebrew word in it, or vice versa).</summary>
    Mixed,
}

/// <summary>How confident the engine is, for UI styling.</summary>
public enum SuggestionStrength
{
    Suggested,
    Strong,
}

/// <summary>Tunable detection thresholds. Every number here is adjustable - none is hard-coded elsewhere.</summary>
public sealed class DetectionOptions
{
    /// <summary>Confidence at or above which a suggestion is shown at all.</summary>
    public double SuggestThreshold { get; init; } = 0.80;

    /// <summary>Confidence at or above which the suggestion is shown as "strong".</summary>
    public double StrongThreshold { get; init; } = 0.95;

    /// <summary>Minimum letters in the analyzed segment before anything runs.</summary>
    public int MinSegmentLetters { get; init; } = 3;

    /// <summary>Segments longer than this are not analyzed (bounded work, bounded replace range).</summary>
    public int MaxSegmentLength { get; init; } = 300;

    /// <summary>
    /// If the original text already scores at or above this as correct text,
    /// never suggest: text that plausibly means what it says must be left alone.
    /// </summary>
    public double OriginalPlausibilityCeiling { get; init; } = 0.75;

    /// <summary>
    /// Candidate must reach this realism in the target language to be
    /// offered, averaged over the words that were actually converted.
    /// Calibrated below a dictionary hit (0.55) but above the
    /// per-word floor, so a conversion of well-formed-but-unlisted words
    /// ("שכנות", realism ~0.35) is offered while a conversion of shapes
    /// the language model dislikes is not.
    /// </summary>
    public double MinCandidatePlausibility { get; init; } = 0.25;

    /// <summary>
    /// A word is converted when the converted form is at least this
    /// realistic in the target language AND beats its own realism by
    /// <see cref="FlipMargin"/>. The absolute floor is deliberately low:
    /// its job is only to reject conversions where both the original and
    /// the converted form are nonsense - the margin, not the floor, is
    /// what protects valid words from being flipped.
    /// </summary>
    public double FlipQualityThreshold { get; init; } = 0.15;

    /// <summary>
    /// How much better the converted form must be than the original for a
    /// word to count as mistyped-layout. Comparative by design: a word that
    /// is already plausible in its own language is never flipped, no matter
    /// how good the conversion looks.
    /// </summary>
    public double FlipMargin { get; init; } = 0.05;

    /// <summary>
    /// An unflipped word inside a run of converted words is re-read
    /// positionally only when its own realism is below this - it must look
    /// like gibberish. A word at or above it is valid text (valid but
    /// unlisted) and is preserved verbatim.
    /// </summary>
    public double ReReadMaxOriginalRealism { get; init; } = 0.40;

    /// <summary>
    /// Punctuation/symbols are remapped positionally only when at least this
    /// fraction of convertible words flipped - in mostly-unchanged segments
    /// punctuation usually means what it says.
    /// </summary>
    public double FlipRatioForPunctuation { get; init; } = 0.60;

    /// <summary>
    /// When exactly one word was converted, that word's own realism must
    /// be below this: a single word that itself looks like valid text is
    /// not enough evidence on its own. Judged per word, not over the
    /// whole segment, so "hello akuo" (one gibberish word next to valid
    /// text) is still offered.
    /// </summary>
    public double OriginalSingleFlipPlausibility { get; init; } = 0.40;

    /// <summary>Minimum share of letters among non-space characters.</summary>
    public double MinPatternScore { get; init; } = 0.50;

    /// <summary>How strongly surrounding context shifts the language prior (0 = ignore context).</summary>
    public double ContextPriorStrength { get; init; } = 0.25;

    public double ContextPriorMin { get; init; } = 0.25;
    public double ContextPriorMax { get; init; } = 0.75;

    // Evidence damping for short inputs: confidence = bayes * evidence, with
    // evidence = EvidenceBase + EvidenceSlope * min(1, letters / saturation).
    // A single short word carries less evidence than a full sentence, so it
    // can never reach "strong" no matter how clean its scores are.
    public double EvidenceBase { get; init; } = 0.85;
    public double EvidenceSlope { get; init; } = 0.15;
    public int EvidenceSaturationLetters { get; init; } = 8;

    public static DetectionOptions Default { get; } = new();

    public static DetectionOptions ForSensitivity(Sensitivity sensitivity) => sensitivity switch
    {
        // Fewer suggestions, higher bar.
        Sensitivity.Low => new DetectionOptions { SuggestThreshold = 0.90, StrongThreshold = 0.98 },
        Sensitivity.High => new DetectionOptions { SuggestThreshold = 0.70, StrongThreshold = 0.90 },
        _ => Default,
    };
}

public enum Sensitivity
{
    Low,
    Medium,
    High,
}
