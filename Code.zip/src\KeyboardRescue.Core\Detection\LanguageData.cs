using System.Reflection;

namespace KeyboardRescue.Core.Detection;

/// <summary>
/// All local language data used for scoring: word frequency lists, character
/// n-gram models and the brand allowlist. Loaded once from embedded
/// resources - no network, no user text, no telemetry.
/// </summary>
public sealed class LanguageData
{
    private static readonly Lazy<LanguageData> Shared = new(Load);

    public static LanguageData Default => Shared.Value;

    public WordFrequencyList EnglishWords { get; }
    public WordFrequencyList HebrewWords { get; }
    public CharacterNgramModel EnglishModel { get; }
    public CharacterNgramModel HebrewModel { get; }

    /// <summary>Terms that must never be converted (brands, product names).</summary>
    public IReadOnlySet<string> Allowlist { get; }

    private LanguageData(WordFrequencyList englishWords, WordFrequencyList hebrewWords,
        CharacterNgramModel englishModel, CharacterNgramModel hebrewModel, IReadOnlySet<string> allowlist)
    {
        EnglishWords = englishWords;
        HebrewWords = hebrewWords;
        EnglishModel = englishModel;
        HebrewModel = hebrewModel;
        Allowlist = allowlist;
    }

    public static LanguageData Load()
    {
        string enFreq = ReadResource("en-freq.txt");
        string heFreq = ReadResource("he-freq.txt");
        string allowlist = ReadResource("allowlist.txt");

        var english = WordFrequencyList.Parse(enFreq);
        var hebrew = WordFrequencyList.Parse(heFreq);

        var englishModel = CharacterNgramModel.Build(english.Words);
        var hebrewModel = CharacterNgramModel.Build(hebrew.Words);

        var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string line in allowlist.Split('\n'))
        {
            string w = line.Trim();
            if (w.Length > 0) allowed.Add(w);
        }

        return new LanguageData(english, hebrew, englishModel, hebrewModel, allowed);
    }

    private static string ReadResource(string fileName)
    {
        string resourceName = $"{typeof(LanguageData).Assembly.GetName().Name}.Detection.Resources.{fileName}";
        using var stream = typeof(LanguageData).Assembly
            .GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException($"Missing embedded resource '{resourceName}'.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
