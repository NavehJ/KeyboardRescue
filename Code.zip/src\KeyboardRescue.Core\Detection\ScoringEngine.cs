namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Combines the per-word verdicts from <see cref="CandidateGenerator"/>
/// into a score breakdown and a confidence value. The comparison stays
/// comparative by design: a candidate is suggested only when it looks
/// substantially more like real text in the target languages than the
/// original does in its own.
/// </summary>
public sealed class ScoringEngine
{
    // Multipliers applied to confidence when the segment is technical
    // rather than prose. Hard kinds never reach the scoring engine (they
    // are blocked earlier); these soften only borderline cases.
    private const double PlainPenalty = 1.0;
    private const double MixedTechnicalPenalty = 0.40;

    private readonly DetectionOptions _options;
    private readonly LanguageData _data;

    public ScoringEngine(DetectionOptions options, LanguageData data)
    {
        _options = options;
        _data = data;
    }

    /// <summary>
    /// Scores one candidate. <paramref name="decisions"/> carries one entry
    /// per pure-script word: words judged as wrong-layout are flagged
    /// <see cref="WordDecision.Replaced"/> with their realism on both
    /// sides. Words that are intentional in their own script contribute
    /// to <see cref="ScoreBreakdown.OriginalTextScore"/> only.
    /// </summary>
    public ScoreBreakdown Score(string original, IReadOnlyList<WordDecision> decisions,
        ContentKind kind, string? precedingText)
    {
        ArgumentNullException.ThrowIfNull(original);
        ArgumentNullException.ThrowIfNull(decisions);

        // --- realism of the original in each word's own language ----------
        double originalSum = 0;
        foreach (var d in decisions) originalSum += d.SourceRealism;
        double originalTextScore = decisions.Count == 0 ? 0.0 : originalSum / decisions.Count;

        // --- realism of the converted words in their target language ------
        double convertedSum = 0;
        int replaced = 0;
        foreach (var d in decisions)
        {
            if (!d.Replaced) continue;
            replaced++;
            convertedSum += d.ConvertedRealism;
        }
        double convertedTextScore = replaced == 0 ? 0.0 : convertedSum / replaced;

        // --- dominant direction of the correction --------------------------
        var dominant = CandidateGenerator.DominantDirection(decisions);

        // --- dictionary / frequency / n-gram support for the candidate ------
        int hits = 0;
        double frequencySum = 0;
        foreach (var d in decisions)
        {
            if (!d.Replaced) continue;
            WordFrequencyList targetWords = d.Direction == CorrectionDirection.ToHebrew
                ? _data.HebrewWords : _data.EnglishWords;
            string n = CharacterNgramModel.Normalize(d.Converted);
            if (targetWords.Contains(n))
            {
                hits++;
                frequencySum += targetWords.NormalizedFrequency(n);
            }
        }
        double dictionaryScore = replaced == 0 ? 0 : (double)hits / replaced;
        double wordFrequencyScore = hits == 0 ? 0 : frequencySum / hits;
        CharacterNgramModel ngramModel = dominant == CorrectionDirection.ToEnglish
            ? _data.EnglishModel : _data.HebrewModel;
        double characterNgramScore = ngramModel.Score(original);

        // --- pattern & mixed-language structure -----------------------------
        int letters = 0, nonSpace = 0;
        foreach (char c in original)
        {
            if (char.IsWhiteSpace(c)) continue;
            nonSpace++;
            if (char.IsLetter(c)) letters++;
        }
        double patternScore = nonSpace == 0 ? 0 : (double)letters / nonSpace;
        double specialContentPenalty = kind switch
        {
            ContentKind.PlainText => PlainPenalty,
            ContentKind.MixedTechnical => MixedTechnicalPenalty,
            _ => 0.05,
        };

        double mixedLanguageScore = MixedIntentionality(decisions);

        // --- language prior from the surrounding context ---------------------
        double languageProbability = dominant == CorrectionDirection.Mixed
            ? 0.5
            : ContextPrior(precedingText, dominant);

        // --- combination ------------------------------------------------------
        // Bayesian comparison of hypotheses "the segment means the target
        // language(s)" vs "the original is correct as typed":
        //   support = prior(target)      * P(candidate | target) * P(original | not source)
        //   against = prior(source)      * P(original | source)  * P(candidate | not target)
        double support = languageProbability * convertedTextScore * (1.0 - originalTextScore);
        double against = (1.0 - languageProbability) * originalTextScore * (1.0 - convertedTextScore);
        double bayes = support + against <= 1e-12 ? 0 : support / (support + against);

        int totalLetters = CountLetters(original);
        double evidence = _options.EvidenceBase
            + _options.EvidenceSlope * Math.Min(1.0, totalLetters / (double)_options.EvidenceSaturationLetters);

        double confidence = Math.Clamp(bayes * evidence * specialContentPenalty, 0.0, 1.0);

        return new ScoreBreakdown(
            OriginalTextScore: Math.Clamp(originalTextScore, 0, 1),
            ConvertedTextScore: Math.Clamp(convertedTextScore, 0, 1),
            LanguageProbability: languageProbability,
            DictionaryScore: dictionaryScore,
            CharacterNgramScore: Math.Clamp(characterNgramScore, 0, 1),
            WordFrequencyScore: Math.Clamp(wordFrequencyScore, 0, 1),
            PatternScore: Math.Clamp(patternScore, 0, 1),
            MixedLanguageScore: mixedLanguageScore,
            SpecialContentPenalty: specialContentPenalty,
            Confidence: confidence);
    }

    /// <summary>
    /// Share of original words that are intentional in their own script -
    /// reports how much of the segment already looks deliberate.
    /// </summary>
    private double MixedIntentionality(IReadOnlyList<WordDecision> decisions)
    {
        if (decisions.Count == 0) return 0;
        int intentional = 0;
        foreach (var d in decisions)
            if (d.SourceRealism >= WordScorer.DictionaryFloor) intentional++;
        return (double)intentional / decisions.Count;
    }

    private double ContextPrior(string? precedingText, CorrectionDirection direction)
    {
        if (string.IsNullOrWhiteSpace(precedingText))
            return 0.5;

        WordFrequencyList sourceWords = direction == CorrectionDirection.ToHebrew
            ? _data.EnglishWords : _data.HebrewWords;
        WordFrequencyList targetWords = direction == CorrectionDirection.ToHebrew
            ? _data.HebrewWords : _data.EnglishWords;
        CharacterNgramModel sourceModel = direction == CorrectionDirection.ToHebrew
            ? _data.EnglishModel : _data.HebrewModel;
        CharacterNgramModel targetModel = direction == CorrectionDirection.ToHebrew
            ? _data.HebrewModel : _data.EnglishModel;
        var sourceScript = direction == CorrectionDirection.ToHebrew
            ? TextScript.Kind.Latin : TextScript.Kind.Hebrew;
        var targetScript = direction == CorrectionDirection.ToHebrew
            ? TextScript.Kind.Hebrew : TextScript.Kind.Latin;

        // Only the tail of the context matters (cheap and local).
        const int contextChars = 60;
        string context = precedingText.Length > contextChars
            ? precedingText[^contextChars..]
            : precedingText;

        var sourceScriptWords = WordsOfScript(context, sourceScript);
        var targetScriptWords = WordsOfScript(context, targetScript);
        if (sourceScriptWords.Count == 0 && targetScriptWords.Count == 0)
            return 0.5;

        double sourceRealism = MeanScore(sourceScriptWords, sourceWords, sourceModel);
        double targetRealism = MeanScore(targetScriptWords, targetWords, targetModel);

        double prior = 0.5 + _options.ContextPriorStrength * (targetRealism - sourceRealism);
        return Math.Clamp(prior, _options.ContextPriorMin, _options.ContextPriorMax);
    }

    private static double MeanScore(List<string> words, WordFrequencyList list, CharacterNgramModel model)
    {
        if (words.Count == 0) return 0.0;
        double sum = 0;
        foreach (string w in words) sum += WordScorer.Realism(w, list, model);
        return sum / words.Count;
    }

    private static List<string> WordsOfScript(string text, TextScript.Kind script)
    {
        var result = new List<string>(8);
        foreach (var token in TextTokenizer.Tokenize(text))
        {
            if (token.Kind != TextTokenKind.Word) continue;
            string word = TextTokenizer.Slice(text, token);
            if (TextScript.Of(word) == script) result.Add(word);
        }
        return result;
    }

    private static int CountLetters(string text)
    {
        int n = 0;
        foreach (char c in text) if (char.IsLetter(c)) n++;
        return n;
    }
}
