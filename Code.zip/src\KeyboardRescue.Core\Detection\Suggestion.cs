namespace KeyboardRescue.Core.Detection;

/// <summary>
/// All scoring components for one candidate, each in [0,1] except
/// <see cref="Confidence"/> which combines them. Exposed for diagnostics and
/// the settings UI; contains no user text.
/// </summary>
public sealed record ScoreBreakdown(
    double OriginalTextScore,
    double ConvertedTextScore,
    double LanguageProbability,
    double DictionaryScore,
    double CharacterNgramScore,
    double WordFrequencyScore,
    double PatternScore,
    double MixedLanguageScore,
    double SpecialContentPenalty,
    double Confidence);

/// <summary>Input to <see cref="DetectionEngine.Analyze"/>.</summary>
public sealed record AnalysisRequest(string Segment, string? PrecedingText = null);

/// <summary>
/// A correction offer. Never persisted, never logged - lives only in memory
/// while the popup is visible.
/// </summary>
public sealed record Suggestion(
    string OriginalText,
    string CandidateText,
    CorrectionDirection Direction,
    double Confidence,
    SuggestionStrength Strength,
    ScoreBreakdown Scores,
    int ReplacementStartOffset,
    int ReplacementLength);
