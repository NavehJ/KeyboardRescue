namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Tracks the currently offered suggestion and suppresses repeats of
/// dismissed segments so the popup never nags. State is process-memory
/// only: nothing is written to disk, and the dismissal list is bounded.
/// </summary>
public sealed class SuggestionManager
{
    /// <summary>Bounded set of recently dismissed original segments.</summary>
    private const int MaxRememberedDismissals = 50;

    private readonly HashSet<string> _dismissed = new(StringComparer.Ordinal);
    private readonly Queue<string> _dismissalOrder = new();

    public Suggestion? Current { get; private set; }

    /// <summary>
    /// Offers a new suggestion. Returns false when the same segment was
    /// dismissed before or when it equals the currently shown one.
    /// </summary>
    public bool Offer(Suggestion suggestion)
    {
        ArgumentNullException.ThrowIfNull(suggestion);

        if (_dismissed.Contains(suggestion.OriginalText))
            return false;
        if (Current is not null && Current.OriginalText == suggestion.OriginalText)
            return false;

        Current = suggestion;
        return true;
    }

    /// <summary>User dismissed the popup; remember this segment to avoid nagging.</summary>
    public void Dismiss()
    {
        if (Current is null) return;

        Remember(Current.OriginalText);
        Current = null;
    }

    /// <summary>User accepted; no suppression needed (text changes anyway).</summary>
    public void Accept() => Current = null;

    /// <summary>Clears everything (disable, pause, focus change, quit).</summary>
    public void Reset()
    {
        Current = null;
        _dismissed.Clear();
        _dismissalOrder.Clear();
    }

    private void Remember(string segment)
    {
        if (_dismissed.Add(segment))
            _dismissalOrder.Enqueue(segment);

        while (_dismissalOrder.Count > MaxRememberedDismissals)
        {
            _dismissed.Remove(_dismissalOrder.Dequeue());
        }
    }
}
