namespace KeyboardRescue.Core.Detection;

/// <summary>Script helpers shared by candidate generation and scoring.</summary>
public static class TextScript
{
    public enum Kind { Hebrew, Latin, Mixed, None }

    public static bool IsHebrewLetter(char c) => c is >= '\u05D0' and <= '\u05EA';

    public static bool IsLatinLetter(char c) =>
        c is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z');

    /// <summary>Dominant script of a word; Mixed when both scripts appear in one token.</summary>
    public static Kind Of(string word)
    {
        int hebrew = 0, latin = 0;
        foreach (char c in word)
        {
            if (IsHebrewLetter(c)) hebrew++;
            else if (IsLatinLetter(c)) latin++;
        }
        return (hebrew, latin) switch
        {
            (> 0, > 0) => Kind.Mixed,
            (> 0, _) => Kind.Hebrew,
            (_, > 0) => Kind.Latin,
            _ => Kind.None,
        };
    }

    public static bool Matches(string word, CorrectionDirection direction) =>
        Of(word) switch
        {
            Kind.Mixed or Kind.None => false,
            Kind.Hebrew => direction == CorrectionDirection.ToEnglish,
            Kind.Latin => direction == CorrectionDirection.ToHebrew,
            _ => false,
        };
}
