namespace KeyboardRescue.Core.Detection;

public enum TextTokenKind
{
    /// <summary>A run of letters (possibly with internal '-'/apostrophe/maqaf).</summary>
    Word,
    /// <summary>A run of digits.</summary>
    Number,
    Whitespace,
    /// <summary>ASCII and Unicode punctuation.</summary>
    Punctuation,
    /// <summary>Symbols (math signs, emoji base characters, ...).</summary>
    Symbol,
    /// <summary>Anything else, including surrogate-pair emoji.</summary>
    Other,
}

public readonly record struct TextToken(TextTokenKind Kind, int Start, int Length);

/// <summary>
/// Splits a segment into tokens with exact spans, so the engine can score
/// words, keep punctuation aligned and compute a precise replacement range.
/// </summary>
public static class TextTokenizer
{
    public static List<TextToken> Tokenize(string text)
    {
        var tokens = new List<TextToken>(16);
        int i = 0;
        while (i < text.Length)
        {
            char c = text[i];
            int start = i;

            if (char.IsLetter(c))
            {
                i++;
                while (i < text.Length && IsWordContinuation(text, i))
                    i++;
                tokens.Add(new TextToken(TextTokenKind.Word, start, i - start));
            }
            else if (char.IsDigit(c))
            {
                while (i < text.Length && char.IsDigit(text[i])) i++;
                tokens.Add(new TextToken(TextTokenKind.Number, start, i - start));
            }
            else if (char.IsWhiteSpace(c))
            {
                while (i < text.Length && char.IsWhiteSpace(text[i])) i++;
                tokens.Add(new TextToken(TextTokenKind.Whitespace, start, i - start));
            }
            else
            {
                i += char.IsSurrogate(c) && i + 1 < text.Length ? 2 : 1;
                bool punctuation = c is (>= '!' and <= '/') or (>= ':' and <= '@')
                    or (>= '[' and <= '`') or (>= '{' and <= '~') or '\u05F3' or '\u05F4';
                tokens.Add(new TextToken(
                    punctuation ? TextTokenKind.Punctuation :
                    char.IsSurrogate(c) ? TextTokenKind.Other : TextTokenKind.Symbol,
                    start, i - start));
            }
        }
        return tokens;
    }

    /// <summary>
    /// True when text[i] continues the word started before it: letters plus
    /// internal hyphen, apostrophe or Hebrew maqaf/geresh when surrounded by
    /// letters ("don't", "כל-כך", "ש״ו").
    /// </summary>
    private static bool IsWordContinuation(string text, int i)
    {
        char c = text[i];
        if (char.IsLetter(c)) return true;
        if (c is '-' or '\'' or '\u05BE' or '\u05F3' or '\u05F4')
        {
            return i + 1 < text.Length && char.IsLetter(text[i + 1]);
        }
        return false;
    }

    public static IEnumerable<TextToken> Words(IEnumerable<TextToken> tokens) =>
        tokens.Where(t => t.Kind == TextTokenKind.Word);

    public static string Slice(string text, TextToken token) =>
        text.Substring(token.Start, token.Length);
}
