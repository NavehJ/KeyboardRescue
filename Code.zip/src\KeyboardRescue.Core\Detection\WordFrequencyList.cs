using System.Globalization;

namespace KeyboardRescue.Core.Detection;

/// <summary>
/// A local word frequency list ("word count" per line, as shipped in
/// Detection/Resources). Loaded once, then queried in O(1). Frequencies are
/// used only as in-memory statistics - no user text is ever added.
/// </summary>
public sealed class WordFrequencyList
{
    private readonly Dictionary<string, int> _frequencies;

    public int Count => _frequencies.Count;
    public int MaxFrequency { get; }

    /// <summary>All words in the list (read-only view).</summary>
    public IEnumerable<string> Words => _frequencies.Keys;

    private WordFrequencyList(Dictionary<string, int> frequencies, int maxFrequency)
    {
        _frequencies = frequencies;
        MaxFrequency = maxFrequency;
    }

    public static WordFrequencyList Parse(string content)
    {
        ArgumentNullException.ThrowIfNull(content);
        var frequencies = new Dictionary<string, int>(StringComparer.Ordinal);
        int max = 0;

        foreach (string line in content.Split('\n'))
        {
            string trimmed = line.TrimEnd('\r');
            int split = trimmed.LastIndexOf(' ');
            if (split <= 0) continue;

            string word = trimmed[..split];
            if (!int.TryParse(trimmed[(split + 1)..], NumberStyles.Integer, CultureInfo.InvariantCulture, out int freq))
                continue;
            if (word.Length == 0) continue;

            // Keep the highest frequency if a word ever repeats.
            if (!frequencies.TryGetValue(word, out int existing) || freq > existing)
                frequencies[word] = freq;
            if (frequencies[word] > max) max = frequencies[word];
        }

        return new WordFrequencyList(frequencies, max);
    }

    public bool Contains(string word) => _frequencies.ContainsKey(word);

    public bool TryGetFrequency(string word, out int frequency) =>
        _frequencies.TryGetValue(word, out frequency);

    /// <summary>
    /// Log-normalized frequency in [0,1]: 1.0 for the most common word in
    /// the corpus, near 0 for the rarest. Log keeps the scale useful across
    /// the several orders of magnitude real corpora span.
    /// </summary>
    public double NormalizedFrequency(string word)
    {
        if (!_frequencies.TryGetValue(word, out int freq) || MaxFrequency <= 0)
            return 0.0;
        return Math.Log(1.0 + freq) / Math.Log(1.0 + MaxFrequency);
    }
}
