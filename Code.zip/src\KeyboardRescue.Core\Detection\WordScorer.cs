namespace KeyboardRescue.Core.Detection;

/// <summary>
/// Realism of a single word in a given language, in [0,1].
/// Calibration rules (locked by the canonical detection tests):
/// - dictionary word: floor of 0.55 scaled up to 1.0 by log frequency, so
///   any real word outranks plausible-looking gibberish, REGARDLESS OF LENGTH;
/// - allowlisted brand: fixed 0.90 (intentional English, never converted);
/// - unknown word: at most 0.35, from n-gram typicality alone;
/// - 1-2 character UNKNOWN strings are ambiguous by themselves: 0.
/// </summary>
public static class WordScorer
{
    public const double DictionaryFloor = 0.55;
    public const double AllowlistedScore = 0.90;
    public const double NonDictionaryCap = 0.35;
    public const int MinScoredLength = 3;

    public static double Realism(string word, WordFrequencyList words, CharacterNgramModel model,
        IReadOnlySet<string>? allowlist = null)
    {
        if (string.IsNullOrEmpty(word)) return 0.0;
        if (allowlist is not null && allowlist.Contains(word))
            return AllowlistedScore;

        string normalized = CharacterNgramModel.Normalize(word);
        if (normalized.Length == 0) return 0.0;

        // FIRST check if this is a dictionary word - if so, it scores well
        // regardless of length (a 2-letter word like "to" or "או" that is
        // in the dictionary should NOT score as 0.0).
        if (words.Contains(normalized))
            return DictionaryFloor + (1.0 - DictionaryFloor) * words.NormalizedFrequency(normalized);

        // Only unknown words need the length filter: 1-2 char gibberish is
        // too ambiguous to judge.
        if (normalized.Length < MinScoredLength) return 0.0;
        return NonDictionaryCap * model.Score(normalized);
    }
}
