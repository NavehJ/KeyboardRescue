namespace KeyboardRescue.Core.Layout;

/// <summary>
/// A keyboard layout: the bijection between physical key positions
/// (with Shift state) and the characters the layout produces there.
/// Adding a new layout (Russian, AZERTY, QWERTZ, ...) only requires new
/// table data implementing this interface - the detection engine and the
/// mapper work against the abstraction.
/// </summary>
public interface IKeyboardLayout
{
    /// <summary>Stable identifier, e.g. "us-qwerty", "he-standard".</summary>
    string Id { get; }

    /// <summary>Human-readable name for UI and diagnostics.</summary>
    string DisplayName { get; }

    /// <summary>
    /// Whether this layout's letters have upper/lower case (QWERTY: yes,
    /// Hebrew: no). Used by the mapper to normalize case when converting
    /// into a caseless layout.
    /// </summary>
    bool HasLetterCase { get; }

    /// <summary>
    /// Resolves which physical position produces <paramref name="character"/>
    /// on this layout. Returns false when the layout cannot produce it
    /// (emoji, pasted foreign text, ...).
    /// </summary>
    bool TryGetPosition(char character, out KeyPosition position);

    /// <summary>
    /// The character this layout produces at <paramref name="position"/>,
    /// or false when the position produces nothing on this layout.
    /// </summary>
    bool TryGetCharacter(KeyPosition position, out char character);
}
