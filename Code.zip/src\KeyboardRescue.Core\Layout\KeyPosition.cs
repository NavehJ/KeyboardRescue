namespace KeyboardRescue.Core.Layout;

/// <summary>
/// A physical key position on the keyboard together with its Shift state.
/// Virtual-key codes are used purely as stable, platform-neutral identifiers
/// for physical positions (the same codes Windows uses); no OS calls are made.
/// </summary>
public readonly record struct KeyPosition(uint VirtualKey, bool Shift);
