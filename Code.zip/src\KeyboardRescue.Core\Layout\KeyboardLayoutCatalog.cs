using System.Reflection;

namespace KeyboardRescue.Core.Layout;

/// <summary>
/// Built-in layouts. Tables are loaded once from the embedded, OS-verified
/// dumps (see tools/LayoutDump and docs/layouts.md for provenance).
/// </summary>
public static class KeyboardLayoutCatalog
{
    public const string UsQwertyId = "us-qwerty";
    public const string HebrewStandardId = "he-standard";
    public const string Hebrew2018Id = "he-2018";

    private static readonly Lazy<IReadOnlyDictionary<string, IKeyboardLayout>> Catalog = new(Load);

    public static IKeyboardLayout UsQwerty => Catalog.Value[UsQwertyId];

    /// <summary>Windows "Hebrew (Standard)" (kbdhebl3) and legacy "Hebrew" (kbdheb) - identical for base+Shift.</summary>
    public static IKeyboardLayout HebrewStandard => Catalog.Value[HebrewStandardId];

    /// <summary>Windows "Hebrew (Standard, 2018)" (kbdhebsi) - letters and punctuation repositioned.</summary>
    public static IKeyboardLayout Hebrew2018 => Catalog.Value[Hebrew2018Id];

    public static IReadOnlyList<IKeyboardLayout> All => Catalog.Value.Values.ToList();

    public static IKeyboardLayout? GetById(string id) =>
        Catalog.Value.TryGetValue(id, out var layout) ? layout : null;

    private static IReadOnlyDictionary<string, IKeyboardLayout> Load()
    {
        var us = KeyboardLayoutTable.FromDumpJson(
            FromResource("layout-US.json"), UsQwertyId, "US QWERTY", hasLetterCase: true);
        var heStandard = KeyboardLayoutTable.FromDumpJson(
            FromResource("layout-HebrewStandard.json"), HebrewStandardId, "Hebrew (Standard)", hasLetterCase: false);
        var he2018 = KeyboardLayoutTable.FromDumpJson(
            FromResource("layout-Hebrew2018.json"), Hebrew2018Id, "Hebrew (Standard, 2018)", hasLetterCase: false);

        return new Dictionary<string, IKeyboardLayout>
        {
            [us.Id] = us,
            [heStandard.Id] = heStandard,
            [he2018.Id] = he2018,
        };
    }

    private static string FromResource(string fileName)
    {
        string resourceName = $"{typeof(KeyboardLayoutCatalog).Assembly.GetName().Name}.Layout.Data.{fileName}";
        using var stream = typeof(KeyboardLayoutCatalog).Assembly
            .GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException($"Missing embedded layout data '{resourceName}'.");
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd();
    }
}
