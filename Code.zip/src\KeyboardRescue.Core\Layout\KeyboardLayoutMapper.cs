namespace KeyboardRescue.Core.Layout;

/// <summary>
/// Converts text between keyboard layouts by physical key position
/// ("the same keys, read through a different layout") - never by meaning.
/// This is a lossless, deterministic character remapping: the same input
/// always produces the same output.
///
/// Example (verified Windows tables): typed "akuo" on the QWERTY layout is
/// the physical sequence a-k-u-o; through the Hebrew layout the same keys
/// produce "שלום".
///
/// Characters the source layout cannot produce (emoji, pasted Hebrew inside
/// English text, combining marks, ...) pass through unchanged, which keeps
/// mixed-language text intact.
/// </summary>
public sealed class KeyboardLayoutMapper
{
    /// <summary>English (QWERTY) layout → Hebrew layout.</summary>
    public string ConvertEnglishLayoutToHebrew(string text, IKeyboardLayout? hebrewLayout = null) =>
        Convert(text, KeyboardLayoutCatalog.UsQwerty, hebrewLayout ?? KeyboardLayoutCatalog.HebrewStandard);

    /// <summary>Hebrew layout → English (QWERTY) layout.</summary>
    public string ConvertHebrewLayoutToEnglish(string text, IKeyboardLayout? hebrewLayout = null) =>
        Convert(text, hebrewLayout ?? KeyboardLayoutCatalog.HebrewStandard, KeyboardLayoutCatalog.UsQwerty);

    /// <summary>
    /// Reads every character of <paramref name="text"/> through
    /// <paramref name="sourceLayout"/> (physical position) and re-emits it
    /// through <paramref name="targetLayout"/>.
    /// </summary>
    public string Convert(string text, IKeyboardLayout sourceLayout, IKeyboardLayout targetLayout)
    {
        ArgumentNullException.ThrowIfNull(text);
        ArgumentNullException.ThrowIfNull(sourceLayout);
        ArgumentNullException.ThrowIfNull(targetLayout);
        if (text.Length == 0) return string.Empty;

        var result = new char[text.Length];
        int written = 0;

        foreach (char c in text)
        {
            result[written++] = ConvertCharacter(c, sourceLayout, targetLayout);
        }

        return new string(result, 0, written);
    }

    private static char ConvertCharacter(char c, IKeyboardLayout sourceLayout, IKeyboardLayout targetLayout)
    {
        // Case normalization when the target layout has no letter case:
        // Hebrew 'A' (Shift position) is a Latin artifact of Shift/CapsLock.
        // A user typing Hebrew never means a Latin capital there, so the
        // lowercase position is the correct one ("AKUO" -> "שלום", not "AKUO").
        if (!targetLayout.HasLetterCase && char.IsUpper(c))
        {
            char lower = char.ToLowerInvariant(c);
            if (sourceLayout.TryGetPosition(lower, out _))
                c = lower;
        }

        if (sourceLayout.TryGetPosition(c, out KeyPosition position) &&
            targetLayout.TryGetCharacter(position, out char mapped))
        {
            return mapped;
        }

        return c; // not part of the source layout's bijection: preserve as-is
    }
}
