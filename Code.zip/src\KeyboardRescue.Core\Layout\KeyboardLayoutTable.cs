using System.Globalization;
using System.Text.Json;

namespace KeyboardRescue.Core.Layout;

/// <summary>
/// An <see cref="IKeyboardLayout"/> built from a verified layout dump
/// (produced by tools/LayoutDump from the OS's own ToUnicodeEx tables).
/// Base and Shift character levels are used for conversion; AltGr level
/// data is retained in the dump for future use but not part of the
/// position bijection today.
/// </summary>
public sealed class KeyboardLayoutTable : IKeyboardLayout
{
    // Sentinels written by the dump tool for positions with no character.
    private const string NoCharacter = "<none>";
    private const string DeadKey = "<dead>";

    private readonly Dictionary<char, KeyPosition> _positionOf;
    private readonly Dictionary<KeyPosition, char> _characterAt;

    public string Id { get; }
    public string DisplayName { get; }
    public bool HasLetterCase { get; }

    private KeyboardLayoutTable(string id, string displayName, bool hasLetterCase,
        Dictionary<char, KeyPosition> positionOf, Dictionary<KeyPosition, char> characterAt)
    {
        Id = id;
        DisplayName = displayName;
        HasLetterCase = hasLetterCase;
        _positionOf = positionOf;
        _characterAt = characterAt;
    }

    /// <summary>
    /// Builds a table from a layout-dump JSON document.
    /// Determinism rule: rows are processed in ascending virtual-key order
    /// (then Shift after Base), so if a layout ever produced the same
    /// character from two positions, the lowest-position one wins.
    /// </summary>
    public static KeyboardLayoutTable FromDumpJson(string json, string id, string displayName, bool hasLetterCase)
    {
        ArgumentNullException.ThrowIfNull(json);

        using var doc = JsonDocument.Parse(json);
        var rows = doc.RootElement.GetProperty("rows");

        var positionOf = new Dictionary<char, KeyPosition>();
        var characterAt = new Dictionary<KeyPosition, char>();

        var parsed = new List<(uint Vk, char Base, char Shift, bool HasBase, bool HasShift)>();
        foreach (var row in rows.EnumerateArray())
        {
            string vkHex = row.GetProperty("vk").GetString()!;
            if (vkHex.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                vkHex = vkHex[2..];
            uint vk = uint.Parse(vkHex, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            bool hasBase = TryReadCharacter(row, "base_", out char baseChar);
            bool hasShift = TryReadCharacter(row, "shift", out char shiftChar);
            parsed.Add((vk, baseChar, shiftChar, hasBase, hasShift));
        }

        foreach (var row in parsed.OrderBy(r => r.Vk))
        {
            if (row.HasBase) AddMapping(row.Vk, shift: false, row.Base);
            if (row.HasShift) AddMapping(row.Vk, shift: true, row.Shift);
        }

        return new KeyboardLayoutTable(id, displayName, hasLetterCase, positionOf, characterAt);

        void AddMapping(uint vk, bool shift, char ch)
        {
            var position = new KeyPosition(vk, shift);
            characterAt[position] = ch;
            // First (lowest) position wins if a character is ever produced twice.
            positionOf.TryAdd(ch, position);
        }
    }

    private static bool TryReadCharacter(JsonElement row, string property, out char value)
    {
        value = default;
        string? raw = row.GetProperty(property).GetString();
        if (string.IsNullOrEmpty(raw) || raw is NoCharacter or DeadKey || raw.Length != 1)
            return false; // absent, dead key, or multi-character output: not part of the bijection
        value = raw[0];
        return true;
    }

    public bool TryGetPosition(char character, out KeyPosition position) =>
        _positionOf.TryGetValue(character, out position);

    public bool TryGetCharacter(KeyPosition position, out char character) =>
        _characterAt.TryGetValue(position, out character);
}
