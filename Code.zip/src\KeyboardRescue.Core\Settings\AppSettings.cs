using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Settings;

/// <summary>
/// User-visible behavior switches. Serialized to JSON by the app layer and
/// never written to disk automatically - the user's choices about sound,
/// shortcuts and startup live only in their own profile.
/// </summary>
public sealed record AppSettings
{
    /// <summary>Master switch. When false the hook stays installed but
    /// nothing is analyzed and nothing is ever sent.</summary>
    public bool Enabled { get; init; } = true;

    /// <summary>
    /// Reserved for a future opt-in auto-fix mode. Off by default and not
    /// wired to any UI: this app only ever *suggests*.
    /// </summary>
    public bool AutoFix { get; init; }

    public Sensitivity Sensitivity { get; init; } = Sensitivity.Medium;

    /// <summary>Offer to convert Latin-typed text into Hebrew.</summary>
    public bool EnableHebrewSuggestions { get; init; } = true;

    /// <summary>Offer to convert Hebrew-typed text into English.</summary>
    public bool EnableEnglishSuggestions { get; init; } = true;

    /// <summary>Play a subtle sound when a suggestion appears.</summary>
    public bool PlaySound { get; init; }

    /// <summary>Start with Windows (HKCU Run key, written on change).</summary>
    public bool LaunchAtStartup { get; init; } = true;

    /// <summary>Global hotkey that accepts the visible suggestion from
    /// anywhere. Empty string disables it. Must parse as
    /// "Ctrl+Alt+Shift+Win+Key" segments.</summary>
    public string GlobalShortcut { get; init; } = "Ctrl+Shift+Space";

    /// <summary>
    /// Quiet period after the last keystroke before analysis runs. Keystrokes
    /// arriving inside the window reset it, so mid-word analysis never runs.
    /// </summary>
    public int DebounceMilliseconds { get; init; } = 450;

    /// <summary>
    /// When the user pauses noticeably longer than this (in ms), the current
    /// segment is considered "finished" and is analyzed even if it stays
    /// under the regular debounce; this catches the common
    /// type-wrong-layout-pause-notice pattern.
    /// </summary>
    public int FastTriggerMilliseconds { get; init; } = 150;

    /// <summary>Auto-hide the popup after this many ms (0 = stay until
    /// dismissed).</summary>
    public int AutoHideMilliseconds { get; init; } = 7000;

    /// <summary>
    /// Whether to analyze text when the secure-input state of the focused
    /// control cannot be determined. Fail-safe default: no.
    /// </summary>
    public bool AllowUnknownSecureState { get; init; }

    /// <summary>First-run onboarding has been completed.</summary>
    public bool FirstRunCompleted { get; init; }

    public static AppSettings Default { get; } = new();

    /// <summary>Clamps out-of-range values from hand-edited or corrupt JSON
    /// so a bad file can never break the app.</summary>
    public AppSettings Sanitized()
    {
        return this with
        {
            DebounceMilliseconds = Clamp(DebounceMilliseconds, 300, 600),
            FastTriggerMilliseconds = Clamp(FastTriggerMilliseconds, 100, 300),
            AutoHideMilliseconds = AutoHideMilliseconds is < 0 or > 60_000
                ? Default.AutoHideMilliseconds
                : AutoHideMilliseconds,
            GlobalShortcut = NormalizeShortcut(GlobalShortcut),
        };
    }

    private static int Clamp(int value, int min, int max) =>
        Math.Clamp(value, min, max);

    private static string NormalizeShortcut(string? shortcut) =>
        string.IsNullOrWhiteSpace(shortcut) ? string.Empty : shortcut.Trim();
}
