using System.Runtime.InteropServices;
using KeyboardRescue.App.Interop;
using Xunit;

namespace KeyboardRescue.App.Tests.Interop;

/// <summary>
/// Regression tests for the SendInput INPUT layout. This is the exact bug
/// that silently disabled every replacement: the INPUT union must be sized
/// to its largest member (MOUSEINPUT), otherwise the struct is 32 bytes on
/// x64 instead of the required 40, and SendInput rejects the whole batch
/// (returning 0) without any error surfaced to the user. Verified against
/// the real Win32 struct size.
/// </summary>
public class InputStructLayoutTests
{
    [Fact]
    public void Input_IsFortyBytes_OnX64()
    {
        // The Win32 INPUT is: 4-byte type + 4-byte padding + a union sized
        // to the largest member (MOUSEINPUT = 32 bytes) = 40 bytes on x64.
        // A KEYBDINPUT-only union yields 32 and breaks SendInput.
        Assert.Equal(40, Marshal.SizeOf<NativeMethods.Input>());
    }

    [Fact]
    public void InputUnion_MatchesSizeofLargestMember()
    {
        // The union must be exactly as large as MOUSEINPUT (the biggest
        // member), not as small as KEYBDINPUT.
        int mouseSize = Marshal.SizeOf<NativeMethods.MouseInput>();
        int keybdSize = Marshal.SizeOf<NativeMethods.KeyBDInput>();
        Assert.True(mouseSize > keybdSize, "MOUSEINPUT must be the largest member");
        Assert.Equal(mouseSize, Marshal.SizeOf<NativeMethods.InputUnion>());
    }

    [Fact]
    public void KeyBDInput_KeepsNativeFieldLayout()
    {
        // KEYBDINPUT is 24 bytes on x64: 2+2+4+4 = 12, padded to 8-byte
        // alignment for the 8-byte ExtraInfo pointer, then +8 = 24.
        Assert.Equal(24, Marshal.SizeOf<NativeMethods.KeyBDInput>());
    }

    [Fact]
    public void KbdLlHookStruct_MatchesNativeExpectation()
    {
        // KBDLLHOOKSTRUCT is 4 uints + 8-byte pointer = 24 bytes on x64.
        // A wrong size here would misread every hook callback.
        Assert.Equal(24, Marshal.SizeOf<NativeMethods.KbdLlHookStruct>());
    }
}
