using KeyboardRescue.App.Interop;
using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;
using Xunit;

namespace KeyboardRescue.App.Tests.Interop;

/// <summary>
/// Regression tests for layout resolution - the one
/// direction-dependent gate in the suggestion path. The
/// asymmetry these guard: Hebrew-to-English resolves from the
/// live Hebrew HKL and always worked, while English-to-Hebrew
/// must fingerprint the live *English* HKL. "US International"
/// (a standard companion layout for Hebrew typists) is
/// position-identical to US QWERTY except that the quote key
/// (OEM_7) is a dead key - the OS produces *nothing* there.
/// The fingerprint used to treat that as a mismatch, refused
/// the HKL, and English-to-Hebrew never produced a suggestion
/// at all (the coordinator bails on a null pair before any
/// candidate is generated).
/// </summary>
public class LayoutBridgeFingerprintTests
{
    private const long UsQwertyHkl = 0x04090409;
    private const long HebrewHkl = 0x040D040D;

    /// <summary>"US International": US QWERTY positions, but
    /// the quote key is a dead key (the OS produces nothing).</summary>
    private static char? UsInternational(uint vk, IntPtr hkl) => vk switch
    {
        0x41 => 'a', 0x46 => 'f', 0x49 => 'i', 0x51 => 'q', 0x57 => 'w',
        0xBC => ',', 0xBE => '.', 0xBF => '/',
        0xDE => null, // dead key
        _ => null,
    };

    /// <summary>A layout that really differs: the A key
    /// produces a different character (not a dead key).</summary>
    private static char? DifferentLetter(uint vk, IntPtr hkl) =>
        vk == 0x41 ? 'á' : UsInternational(vk, hkl);

    /// <summary>A layout that really differs: the quote key
    /// produces a different character (not a dead key).</summary>
    private static char? DifferentPunctuation(uint vk, IntPtr hkl) =>
        vk == 0xDE ? ';' : UsInternational(vk, hkl);

    /// <summary>A Hebrew layout, read through its own table.</summary>
    private static char? HebrewStandard(uint vk, IntPtr hkl) =>
        KeyboardLayoutCatalog.HebrewStandard.TryGetCharacter(
            new KeyPosition(vk, Shift: false), out char c) ? c : null;

    /// <summary>Mimics the OS's dead-key behaviour on the calling
    /// thread: after a dead key, the next translation composes
    /// ('a' becomes 'á'; space yields the dead character itself
    /// and clears the state).</summary>
    private sealed class ComposePendingTranslator
    {
        private bool _acutePending;

        public char? Translate(uint vk, IntPtr hkl)
        {
            if (_acutePending)
            {
                _acutePending = false;
                if (vk == 0x41) return 'á';
                if (vk == 0x20) return '\'';
                return null;
            }

            if (vk == 0xDE)
            {
                _acutePending = true;
                return null;
            }

            return vk switch
            {
                0x41 => 'a', 0x46 => 'f', 0x49 => 'i', 0x51 => 'q', 0x57 => 'w',
                0xBC => ',', 0xBE => '.', 0xBF => '/',
                _ => null,
            };
        }
    }

    [Fact]
    public void UsInternationalStyleDeadKey_ResolvesToHebrew()
    {
        var pair = new LayoutBridge(UsInternational).Resolve(new IntPtr(UsQwertyHkl));

        Assert.NotNull(pair);
        Assert.Equal(CorrectionDirection.ToHebrew, pair!.Direction);
        Assert.Equal(KeyboardLayoutCatalog.UsQwerty.Id, pair.TypedLayout.Id);
        Assert.Equal(KeyboardLayoutCatalog.HebrewStandard.Id, pair.TargetLayout.Id);
    }

    [Fact]
    public void DifferentLetter_IsStillRefused()
    {
        // A character that is not what the verified dump says
        // means a layout we have not verified: stay idle.
        var pair = new LayoutBridge(DifferentLetter).Resolve(new IntPtr(UsQwertyHkl));

        Assert.Null(pair);
    }

    [Fact]
    public void DifferentPunctuation_IsStillRefused()
    {
        // Same rule for punctuation: a real character that
        // differs is a mismatch - only "nothing" (dead key)
        // is tolerated.
        var pair = new LayoutBridge(DifferentPunctuation).Resolve(new IntPtr(UsQwertyHkl));

        Assert.Null(pair);
    }

    [Fact]
    public void PendingComposeState_DoesNotPoisonResolution()
    {
        // The user typed the dead key shortly before this
        // run: the OS leaves compose state on the calling
        // thread, which would otherwise surface on the first
        // probe ('a' -> 'á') and - worse - cache the refusal
        // for the HKL.
        var translator = new ComposePendingTranslator();
        translator.Translate(0xDE, new IntPtr(UsQwertyHkl)); // simulate the trailing dead key

        var pair = new LayoutBridge(translator.Translate).Resolve(new IntPtr(UsQwertyHkl));

        Assert.NotNull(pair);
        Assert.Equal(CorrectionDirection.ToHebrew, pair!.Direction);
    }

    [Fact]
    public void HebrewLayout_StillResolvesToEnglish()
    {
        // The reverse direction must keep resolving exactly as
        // before: a fully matching Hebrew HKL is unaffected by
        // the dead-key tolerance.
        var pair = new LayoutBridge(HebrewStandard).Resolve(new IntPtr(HebrewHkl));

        Assert.NotNull(pair);
        Assert.Equal(CorrectionDirection.ToEnglish, pair!.Direction);
        Assert.Equal(KeyboardLayoutCatalog.HebrewStandard.Id, pair.TypedLayout.Id);
        Assert.Equal(KeyboardLayoutCatalog.UsQwerty.Id, pair.TargetLayout.Id);
    }
}
