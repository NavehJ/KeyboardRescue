using KeyboardRescue.App.Interop;
using KeyboardRescue.App.Services;
using KeyboardRescue.Core.Settings;
using Xunit;

namespace KeyboardRescue.App.Tests.Services;

/// <summary>
/// Buffer-integrity contract at the coordinator level. These guard the
/// divergence classes that made replacements backspace the wrong
/// characters: typing without accepting must leave the tracked text intact,
/// a layout switch (Alt+Shift/Ctrl+Shift arrive as Shortcut) must reset it,
/// and a focus change must drop the old window's text before the next
/// keystroke is recorded. No suggestion can fire in these tests because the
/// debounce timer never ticks on the test thread's dispatcher.
/// </summary>
public class AnalysisCoordinatorKeyTests
{
    /// <summary>Mutatable foreground window the coordinator sees.</summary>
    private sealed class FakeForeground
    {
        public IntPtr Current { get; set; }
        public IntPtr Invoke() => Current;
    }

    private static (AnalysisCoordinator Coordinator, FakeForeground Foreground)
        Create(IntPtr initialForeground)
    {
        var foreground = new FakeForeground { Current = initialForeground };
        var coordinator = new AnalysisCoordinator(
            AppSettings.Default, new LayoutBridge(), foreground.Invoke);
        return (coordinator, foreground);
    }

    private static void Type(AnalysisCoordinator coordinator, string text)
    {
        foreach (char c in text) coordinator.OnKey(KeyEvent.OfChar(c));
    }

    [Fact]
    public void TypingWithoutAccepting_KeepsTypedText_AndRaisesNoEvents()
    {
        var (coordinator, _) = Create(new IntPtr(1));
        int ready = 0, dismissed = 0;
        coordinator.SuggestionReady += _ => ready++;
        coordinator.SuggestionDismissed += () => dismissed++;

        Type(coordinator, "akuo nv anku");

        Assert.Equal("akuo nv anku", coordinator.SnapshotForTests.Text);
        Assert.Equal(0, ready);
        Assert.Equal(0, dismissed);
    }

    [Fact]
    public void LayoutSwitchShortcut_ResetsBuffer_AndTypingContinuesCleanly()
    {
        var (coordinator, _) = Create(new IntPtr(1));
        Type(coordinator, "akuo");

        // Alt+Shift / Ctrl+Shift (the layout switchers) arrive as Shortcut.
        coordinator.OnKey(KeyEvent.Of(KeyObservation.Shortcut));

        Assert.Equal(string.Empty, coordinator.SnapshotForTests.Text);

        // After the switch, new typing starts from a clean slate.
        Type(coordinator, "\u05d0\u05d1"); // two Hebrew letters
        Assert.Equal("\u05d0\u05d1", coordinator.SnapshotForTests.Text);
    }

    [Fact]
    public void FocusChange_DropsOldWindowText_BeforeNewKeystroke()
    {
        var (coordinator, foreground) = Create(new IntPtr(1));
        Type(coordinator, "akuo");

        // The user clicked into another window and typed there.
        foreground.Current = new IntPtr(2);
        Type(coordinator, "b");

        // The old window's text must not leak into the new window's segment,
        // or a later accept would backspace characters that are not there.
        Assert.Equal("b", coordinator.SnapshotForTests.Text);
    }

    [Fact]
    public void FocusUnchanged_KeepsTextAcrossKeystrokes()
    {
        var (coordinator, _) = Create(new IntPtr(1));
        Type(coordinator, "akuo");
        coordinator.OnKey(KeyEvent.Of(KeyObservation.Backspace));
        Type(coordinator, "o");

        Assert.Equal("akuo", coordinator.SnapshotForTests.Text);
    }

    [Fact]
    public void Escape_StopsDebounce_ButKeepsTrackedText()
    {
        var (coordinator, _) = Create(new IntPtr(1));
        Type(coordinator, "akuo");

        coordinator.OnKey(KeyEvent.Of(KeyObservation.Escape));

        Assert.Equal("akuo", coordinator.SnapshotForTests.Text);
    }
}
