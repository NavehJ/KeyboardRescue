using KeyboardRescue.App.Services;
using Xunit;

namespace KeyboardRescue.App.Tests.Services;

/// <summary>
/// Regression contract for <see cref="KeyboardMonitor.Classify"/>. The bug
/// this guards: the Win key (VK_LWIN 0x5B / VK_RWIN 0x5C) was not treated as
/// a modifier, so Win combos - like Win+Space, the default layout switch,
/// and Win+letter - which the shell consumes and the focused control never
/// receives, were recorded in the buffer as characters. The buffer then
/// tracked text the control did not have, the next accept's backspace count
/// was oversized, and real characters before the segment were deleted.
/// </summary>
public class KeyboardKeyClassificationTests
{
    [Theory]
    [InlineData(0x20u)] // Win+Space: default layout switch, shell consumes it
    [InlineData(0x45u)] // Win+E: opens Explorer
    [InlineData(0x0Du)] // Win+Enter must not even break segments
    public void WinCombos_ClassifyAsShortcut_NotAsText(uint vk) =>
        Assert.Equal(KeyObservation.Shortcut,
            KeyboardMonitor.Classify(vk, ctrl: false, alt: false, win: true)!.Value.Observation);

    [Theory]
    [InlineData(true, false)]  // Ctrl+C (and Ctrl+Shift layout switch)
    [InlineData(false, true)]   // Alt+X (and Alt+Shift layout switch)
    public void CtrlOrAltCombos_ClassifyAsShortcut(bool ctrl, bool alt) =>
        Assert.Equal(KeyObservation.Shortcut,
            KeyboardMonitor.Classify(0x43u, ctrl, alt, win: false)!.Value.Observation);

    [Fact]
    public void PlainLetter_ClassifiesAsMaybeText() =>
        Assert.Null(KeyboardMonitor.Classify(0x41u, ctrl: false, alt: false, win: false));

    [Fact]
    public void PlainSpace_ClassifiesAsMaybeText() =>
        Assert.Null(KeyboardMonitor.Classify(0x20u, ctrl: false, alt: false, win: false));

    [Theory]
    [InlineData(0x0Du, KeyObservation.Enter)]      // VK_RETURN
    [InlineData(0x09u, KeyObservation.Tab)]        // VK_TAB
    [InlineData(0x1Bu, KeyObservation.Escape)]     // VK_ESCAPE
    [InlineData(0x08u, KeyObservation.Backspace)]  // VK_BACK
    [InlineData(0x25u, KeyObservation.CaretMoved)] // left arrow
    [InlineData(0x23u, KeyObservation.CaretMoved)] // end
    public void NavigationKeys_ClassifyExactly(uint vk, KeyObservation expected) =>
        Assert.Equal(expected,
            KeyboardMonitor.Classify(vk, ctrl: false, alt: false, win: false)!.Value.Observation);
}
