using System.Runtime.InteropServices;
using System.Text;
using KeyboardRescue.App.Services;
using KeyboardRescue.Core.Context;
using Xunit;

namespace KeyboardRescue.App.Tests.Services;

/// <summary>
/// Empirical proof that the replacement mechanism actually types into a real
/// target control. This is the test that would have caught the root-cause bug:
/// with the old 32-byte INPUT struct, SendInput delivered 0 events and the
/// edit control's text never changed. With the corrected 40-byte struct the
/// mistyped segment is deleted and the candidate inserted.
///
/// A real Win32 Edit control is created, focused, and passed to the actual
/// <see cref="TextReplacementService"/>. The foreground-window guard is
/// exercised for real: if the control cannot be made foreground, Apply must
/// refuse (Stale) rather than type into an unintended window.
///
/// Hebrew strings are written as \u escapes so this file is immune to source
/// encoding drift.
/// </summary>
public class ReplacementEndToEndTests : IDisposable
{
    private const int WsOverlappedWindow = 0x00CF0000;
    private const uint WmSettext = 0x000C;
    private const uint WmGettext = 0x000D;
    private const uint WmGettextlength = 0x000E;
    private const uint EmSetsel = 0x00B1;

    // Representative candidate for injection tests (Hebrew written as \u
    // escapes to be immune to source encoding drift).
    private const string Candidate = "\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 \u05e0\u05e9\u05de\u05e2";

    private readonly IntPtr _edit;

    public ReplacementEndToEndTests()
    {
        IntPtr instance = GetModuleHandleW(IntPtr.Zero);
        _edit = CreateWindowExW(0, "Edit", string.Empty, WsOverlappedWindow,
            100, 100, 400, 60, IntPtr.Zero, IntPtr.Zero, instance, IntPtr.Zero);
        Assert.NotEqual(IntPtr.Zero, _edit);
    }

    public void Dispose()
    {
        if (_edit != IntPtr.Zero) DestroyWindow(_edit);
    }

    [Fact]
    public void Apply_IntoRealEditControl_ReplacesWholeSegment()
    {
        const string original = "akuo nv anku";

        // Seed the control with the mistyped text and make it foreground.
        SetText(_edit, original);
        bool foregroundAcquired = SetForegroundWindow(_edit) && Focus(_edit);

        var service = new TextReplacementService();
        var plan = new ReplacementPlan(Version: 1, BackspaceCount: original.Length,
            TextToInsert: Candidate, BufferStart: 0, ReplacedLength: original.Length);

        ReplacementOutcome outcome = service.Apply(plan, _edit);

        if (!foregroundAcquired)
        {
            // The guard must refuse rather than type into an unintended
            // window. This is the safe behaviour, so assert that.
            Assert.Equal(ReplacementOutcome.Stale, outcome);
            Assert.Equal(original, GetText(_edit)); // original preserved
            return;
        }

        // Foreground was ours: the whole segment must have been replaced.
        Assert.Equal(ReplacementOutcome.Applied, outcome);
        System.Threading.Thread.Sleep(100); // drain the input queue
        Assert.Equal(Candidate, GetText(_edit));
    }

    [Fact]
    public void Apply_MidTextRange_PreservesSurroundingText()
    {
        // The caret sits after "akuo" inside a longer line: exactly that
        // segment may be deleted; everything before and after must survive.
        const string prefix = "prefix ";
        const string suffix = " suffix";
        const string original = prefix + "akuo" + suffix;

        SetText(_edit, original);
        bool foregroundAcquired = SetForegroundWindow(_edit) && Focus(_edit);

        // Place the caret directly after "akuo" (index 11).
        const int caret = 11;
        SendMessageW(_edit, EmSetsel, new IntPtr(caret), new IntPtr(caret));

        var service = new TextReplacementService();
        var plan = new ReplacementPlan(Version: 1, BackspaceCount: 4,
            TextToInsert: Candidate, BufferStart: 7, ReplacedLength: 4);

        ReplacementOutcome outcome = service.Apply(plan, _edit);

        if (!foregroundAcquired)
        {
            // Safe refusal path: nothing was sent, nothing may change.
            Assert.Equal(ReplacementOutcome.Stale, outcome);
            Assert.Equal(original, GetText(_edit));
            return;
        }

        Assert.Equal(ReplacementOutcome.Applied, outcome);
        System.Threading.Thread.Sleep(100); // drain the input queue
        Assert.Equal(prefix + Candidate + suffix, GetText(_edit));
    }

    [Fact]
    public void Apply_WithMismatchedWindow_TypesNothing()
    {
        // A window handle that is not the foreground: the service must refuse
        // and the control's text must be completely untouched.
        const string original = "keep me intact";
        SetText(_edit, original);

        var service = new TextReplacementService();
        var plan = new ReplacementPlan(Version: 1, BackspaceCount: original.Length,
            TextToInsert: "SHOULD NOT APPEAR", BufferStart: 0, ReplacedLength: original.Length);

        // Deliberately wrong expected window (not _edit).
        ReplacementOutcome outcome = service.Apply(plan, new IntPtr(0x12345678));

        Assert.Equal(ReplacementOutcome.Stale, outcome);
        Assert.Equal(original, GetText(_edit));
    }

    private static void SetText(IntPtr hwnd, string text) =>
        SendMessageW(hwnd, WmSettext, IntPtr.Zero, text);

    private static bool Focus(IntPtr hwnd) => SetFocus(hwnd) != IntPtr.Zero;

    private static string GetText(IntPtr hwnd)
    {
        int length = (int)SendMessageW(hwnd, WmGettextlength, IntPtr.Zero, IntPtr.Zero);
        var sb = new StringBuilder(length + 1);
        SendMessageW(hwnd, WmGettext, (IntPtr)sb.Capacity, sb);
        return sb.ToString();
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr CreateWindowExW(int exStyle, string cls, string title,
        int style, int x, int y, int w, int h, IntPtr parent, IntPtr menu,
        IntPtr instance, IntPtr param);

    [DllImport("user32.dll")] private static extern bool DestroyWindow(IntPtr h);
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] private static extern IntPtr SetFocus(IntPtr h);
    [DllImport("kernel32.dll")] private static extern IntPtr GetModuleHandleW(IntPtr n);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, string l);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, StringBuilder l);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessageW(IntPtr h, uint msg, IntPtr w, IntPtr l);
}
