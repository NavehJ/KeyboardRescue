using KeyboardRescue.App.Services;
using KeyboardRescue.Core.Context;
using KeyboardRescue.Core.Detection;
using Xunit;

namespace KeyboardRescue.App.Tests.Services;

/// <summary>
/// Safety guards around <see cref="TextReplacementService.Apply"/>. These
/// verify the fail-safe contract: never send input when the target window
/// changed, and never send an out-of-range plan. The service refuses before
/// building any input when the guard fails, so the focused app's text is
/// always preserved.
/// </summary>
public class TextReplacementServiceTests
{
    private static ReplacementPlan Plan(int backspaces, string text, int version = 1) =>
        new(Version: version, BackspaceCount: backspaces, TextToInsert: text,
            BufferStart: 0, ReplacedLength: backspaces);

    [Fact]
    public void Apply_ForegroundWindowChanged_ReturnsStale_AndSendsNothing()
    {
        var service = new TextReplacementService();

        // Pass a handle that is deliberately NOT the current foreground
        // window. Real foreground is whatever is focused now (likely the
        // test runner), so this mismatch must short-circuit to Stale.
        IntPtr wrongWindow = new(0xDEADBEEF);

        ReplacementOutcome outcome = service.Apply(Plan(4, "שלום"), wrongWindow);

        Assert.Equal(ReplacementOutcome.Stale, outcome);
    }

    [Fact]
    public void Apply_InsaneBackspaceCount_IsRefused()
    {
        var service = new TextReplacementService();
        IntPtr wrongWindow = new(0xDEADBEEF);

        // A negative or absurd count can never be a real plan; refuse.
        Assert.Equal(ReplacementOutcome.Stale,
            service.Apply(Plan(-1, "x"), wrongWindow));
        Assert.Equal(ReplacementOutcome.Stale,
            service.Apply(Plan(int.MaxValue, "x"), wrongWindow));
    }
}

/// <summary>
/// Duplicate-acceptance protection lives in the plan lifecycle: once a plan
/// is committed the buffer version advances, so the same plan can never be
/// committed (and therefore sent) twice. Verified through the buffer, which
/// is the single source of truth for staleness.
/// </summary>
public class DuplicateAcceptanceTests
{
    [Fact]
    public void SamePlan_NeverAppliesTwice()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo nv anku");
        int version = buffer.Version;

        var suggestion = new Suggestion(
            OriginalText: "akuo nv anku",
            CandidateText: "שלום מה נשמע",
            Direction: CorrectionDirection.ToHebrew,
            Confidence: 0.97,
            Strength: SuggestionStrength.Strong,
            Scores: null!,
            ReplacementStartOffset: 0,
            ReplacementLength: "akuo nv anku".Length);

        Assert.True(buffer.TryPlanReplacement(suggestion, version, out ReplacementPlan? plan));

        // First accept succeeds; the buffer version moves, so any second
        // attempt with the same plan is refused.
        Assert.True(buffer.CommitReplacement(plan));
        Assert.False(buffer.TryPlanReplacement(suggestion, version, out _));
        Assert.False(buffer.CommitReplacement(plan));
    }
}
