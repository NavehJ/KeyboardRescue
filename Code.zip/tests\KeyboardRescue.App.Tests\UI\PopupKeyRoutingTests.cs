using KeyboardRescue.App.Services;
using KeyboardRescue.App.UI;
using Xunit;

namespace KeyboardRescue.App.Tests.UI;

/// <summary>
/// Regression contract for what a visible popup does with observed keys.
/// The bug this guards: the hook emits the same <see cref="KeyObservation.Shortcut"/>
/// observation for the accept hotkey AND for any other Ctrl/Alt keystroke,
/// and the app used to accept on *every* Shortcut while the popup was up.
/// So pressing a layout switcher (Alt+Shift / Ctrl+Shift), Ctrl+C, Ctrl+Z,
/// or Alt+Tab while a suggestion was visible silently fired a text
/// replacement. Only Enter and the dedicated accept hotkey may ever accept.
/// </summary>
public class PopupKeyRoutingTests
{
    [Theory]
    [InlineData(KeyObservation.Enter)]
    [InlineData(KeyObservation.AcceptShortcut)]
    public void AcceptingKeys_RouteToAccept(KeyObservation observation) =>
        Assert.Equal(PopupKeyAction.Accept, PopupKeyRouting.Route(observation));

    [Theory]
    [InlineData(KeyObservation.Shortcut)] // layout switch, Ctrl+C, Alt+Tab, ...
    [InlineData(KeyObservation.Character)]
    [InlineData(KeyObservation.Backspace)]
    [InlineData(KeyObservation.Tab)]
    [InlineData(KeyObservation.CaretMoved)]
    public void AnyOtherKey_NeverAccepts(KeyObservation observation) =>
        Assert.NotEqual(PopupKeyAction.Accept, PopupKeyRouting.Route(observation));

    [Fact]
    public void Escape_RoutesToDismiss() =>
        Assert.Equal(PopupKeyAction.Dismiss, PopupKeyRouting.Route(KeyObservation.Escape));
}
