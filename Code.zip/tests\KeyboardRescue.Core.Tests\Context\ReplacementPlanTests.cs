using KeyboardRescue.Core.Context;
using KeyboardRescue.Core.Detection;
using Xunit;

namespace KeyboardRescue.Core.Tests.Context;

/// <summary>
/// Acceptance/replacement semantics: a suggestion must map to a plan that
/// deletes the exact intended range, preserves everything outside it, and
/// refuses to run whenever the range cannot be counted safely. These tests
/// mirror the end-to-end examples (English-layout → Hebrew and
/// Hebrew-layout → English) at the buffer/plan layer, which is where the
/// deletion length is decided.
/// </summary>
public class ReplacementPlanTests
{
    private static Suggestion Suggest(string original, string candidate,
        CorrectionDirection direction, int startOffset = 0) => new(
        OriginalText: original,
        CandidateText: candidate,
        Direction: direction,
        Confidence: 0.97,
        Strength: SuggestionStrength.Strong,
        Scores: null!,
        ReplacementStartOffset: startOffset,
        ReplacementLength: original.Length);

    // ---- Full multiword replacement, both directions ----

    [Fact]
    public void EnglishLayout_Multiword_WholeSegmentBecomesHebrew()
    {
        // Representative suggestion data for buffer mechanics (deletion
        // length, insertion, surrounding text - not conversion accuracy:
        // the real positional pair for "anku" is "שמלו"; "bang" maps to
        // "נשמע", see DirectionalRegressionTests).
        const string typed = "akuo nv anku";
        const string hebrew = "שלום מה נשמע";

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest(typed, hebrew, CorrectionDirection.ToHebrew), version, out ReplacementPlan? plan));

        // The plan must delete the ENTIRE segment, not a word or suffix.
        Assert.Equal(typed.Length, plan.BackspaceCount);
        Assert.Equal(typed.Length, plan.ReplacedLength);
        Assert.Equal(0, plan.BufferStart);
        Assert.Equal(hebrew, plan.TextToInsert);
    }

    [Fact]
    public void HebrewLayout_Multiword_WholeSegmentBecomesEnglish()
    {
        // Hebrew-layout keys producing English, reversed.
        const string typed = "יקךךם יים' שרק טםו";
        const string english = "hello how are you";

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest(typed, english, CorrectionDirection.ToEnglish), version, out ReplacementPlan? plan));

        Assert.Equal(typed.Length, plan.BackspaceCount);
        Assert.Equal(english, plan.TextToInsert);
    }

    // ---- Preserving text outside the range ----

    [Fact]
    public void TextBeforeRange_IsPreserved()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("hello akuo nv anku");
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest("akuo nv anku", "שלום מה נשמע", CorrectionDirection.ToHebrew,
                startOffset: "hello ".Length),
            version, out ReplacementPlan? plan));

        // Plan targets only the tail; "hello " is untouched by the deletion.
        Assert.Equal("hello ".Length, plan.BufferStart);
        Assert.Equal("akuo nv anku".Length, plan.BackspaceCount);

        Assert.True(buffer.CommitReplacement(plan));
        Assert.Equal("hello שלום מה נשמע", buffer.Snapshot().Text);
    }

    [Fact]
    public void TextAfterRange_BlocksReplacement()
    {
        // Backspace-based edits only reach the caret. Text after the range
        // means we cannot touch it safely, so planning must fail (and the
        // caller leaves the original text alone).
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo nv anku tail");
        int version = buffer.Version;

        Assert.False(buffer.TryPlanReplacement(
            Suggest("akuo nv anku", "שלום מה נשמע", CorrectionDirection.ToHebrew),
            version, out _));
    }

    [Fact]
    public void Punctuation_IsPreservedInCandidate()
    {
        // Punctuation inside the replaced range travels with the text.
        const string typed = "akuo, nv!";
        const string hebrew = "שלום, מה!";

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest(typed, hebrew, CorrectionDirection.ToHebrew), version, out ReplacementPlan? plan));

        Assert.Equal(hebrew, plan.TextToInsert);
        Assert.Equal(typed.Length, plan.BackspaceCount);
    }

    [Fact]
    public void RepeatedSpaces_CountAsCodeUnits()
    {
        // Internal runs of spaces are part of the replaced text; the
        // backspace count is the full code-unit length including them.
        const string typed = "akuo  nv"; // two spaces between words
        const string hebrew = "שלום  מה";

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest(typed, hebrew, CorrectionDirection.ToHebrew), version, out ReplacementPlan? plan));

        Assert.Equal(typed.Length, plan.BackspaceCount); // 8 code units
        Assert.Equal(hebrew, plan.TextToInsert);
    }

    // ---- Unicode deletion semantics ----

    [Fact]
    public void SupplementaryCharacter_InOriginal_RefusesReplacement()
    {
        // A surrogate pair is ONE grapheme but TWO UTF-16 units; a
        // grapheme-aware app deletes it with ONE backspace, so a code-unit
        // count would over-delete. We refuse rather than corrupt. The emoji
        // must be INSIDE the replaced range for this to matter.
        const string typed = "hi \U0001F600 akuo"; // ends with the target word
        const string target = "\U0001F600 akuo";   // the range to replace

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.False(buffer.TryPlanReplacement(
            Suggest(target, "שלום", CorrectionDirection.ToHebrew,
                startOffset: typed.Length - target.Length),
            version, out _));
    }

    [Fact]
    public void SupplementaryCharacter_OutsideRange_StillReplaces()
    {
        // A supplementary character elsewhere in the buffer does not affect
        // a pure-BMP replacement range, so planning still succeeds.
        const string typed = "\U0001F600 akuo";

        var buffer = new TypingContextBuffer();
        buffer.AppendText(typed);
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest("akuo", "שלום", CorrectionDirection.ToHebrew,
                startOffset: typed.Length - 4),
            version, out ReplacementPlan? plan));
        Assert.Equal(4, plan.BackspaceCount);
    }

    [Fact]
    public void HebrewLetters_AreCountedAsSingleUnits()
    {
        // Hebrew is entirely in the BMP: one letter = one code unit = one
        // backspace. The count must equal the letter count exactly.
        const string hebrew = "שלום מה";
        var buffer = new TypingContextBuffer();
        buffer.AppendText(hebrew);
        int version = buffer.Version;

        // Reverse the direction: Hebrew-layout segment -> English candidate.
        Assert.True(buffer.TryPlanReplacement(
            Suggest(hebrew, "nv ako", CorrectionDirection.ToEnglish), version, out ReplacementPlan? plan));

        Assert.Equal(hebrew.Length, plan.BackspaceCount);
        Assert.Equal(hebrew.Length, plan.ReplacedLength);
    }

    // ---- Stale / duplicate protection ----

    [Fact]
    public void StaleVersion_PlanRefuses_OriginalTextUntouched()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo nv anku");
        int analyzedVersion = buffer.Version;

        buffer.AppendChar('!'); // user typed more before accepting

        Assert.False(buffer.TryPlanReplacement(
            Suggest("akuo nv anku", "שלום מה נשמע", CorrectionDirection.ToHebrew),
            analyzedVersion, out _));
        // The buffer still holds the user's real text.
        Assert.Equal("akuo nv anku!", buffer.Snapshot().Text);
    }

    [Fact]
    public void CommittingSamePlanTwice_SecondCommitFails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo");
        int version = buffer.Version;
        Assert.True(buffer.TryPlanReplacement(
            Suggest("akuo", "שלום", CorrectionDirection.ToHebrew), version, out ReplacementPlan? plan));

        Assert.True(buffer.CommitReplacement(plan));
        Assert.False(buffer.CommitReplacement(plan)); // version moved on
    }

    [Fact]
    public void BufferReflectsReplacement_AfterSuccessfulCommit()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo nv anku");
        int version = buffer.Version;

        Assert.True(buffer.TryPlanReplacement(
            Suggest("akuo nv anku", "שלום מה נשמע", CorrectionDirection.ToHebrew),
            version, out ReplacementPlan? plan));
        Assert.True(buffer.CommitReplacement(plan));

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal("שלום מה נשמע", snap.Text);
        Assert.Equal("שלום מה נשמע", snap.Segment);
        Assert.True(buffer.Version > version);
    }
}
