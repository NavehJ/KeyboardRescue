using KeyboardRescue.Core.Context;
using KeyboardRescue.Core.Detection;
using Xunit;

namespace KeyboardRescue.Core.Tests.Context;

/// <summary>
/// The continuous-translation contract at the buffer level. After an
/// accepted correction the coordinator breaks the segment, so the settled
/// text becomes context and the next mistyped words are analyzed (and
/// replaced) on their own. Without the break the accepted candidate stays
/// inside the open segment and the following analysis has to re-derive
/// corrections around it.
/// </summary>
public class StreamedContinuityTests
{
    private static Suggestion Suggest(string original, string candidate) =>
        new(original, candidate, CorrectionDirection.ToHebrew, 0.9, SuggestionStrength.Strong,
            new ScoreBreakdown(0.1, 0.9, 0.5, 0.9, 0.9, 0.8, 1, 0, 1, 0.9),
            0, original.Length);

    [Fact]
    public void AfterAcceptedCorrection_BufferBreaksSegment_AndContinuesFresh()
    {
        var buffer = new TypingContextBuffer();
        foreach (char c in "hello akuo") buffer.AppendChar(c);
        var snapshot = buffer.Snapshot();
        var suggestion = Suggest("hello akuo", "hello \u05e9\u05dc\u05d5\u05dd");

        Assert.True(buffer.TryPlanReplacement(suggestion, snapshot.Version, out var plan));
        Assert.Equal(10, plan.BackspaceCount); // the whole mistyped segment
        Assert.True(buffer.CommitReplacement(plan));

        // This is exactly what the coordinator does once the synthetic
        // input was accepted.
        buffer.BreakSegment();

        snapshot = buffer.Snapshot();
        Assert.Equal(string.Empty, snapshot.Segment);                   // nothing under analysis
        Assert.Contains("hello \u05e9\u05dc\u05d5\u05dd", snapshot.PrecedingText); // settled context

        // The user keeps typing the next wrong-layout words: they form a
        // fresh, short segment instead of being re-derived around the
        // accepted candidate.
        foreach (char c in "nv bang") buffer.AppendChar(c);
        snapshot = buffer.Snapshot();

        Assert.Equal("nv bang", snapshot.Segment);
        Assert.Contains("hello \u05e9\u05dc\u05d5\u05dd", snapshot.PrecedingText);

        // A follow-up suggestion therefore covers only the new words: the
        // edit range stays small and settled text is never touched.
        var next = Suggest("nv bang", "\u05de\u05d4 \u05e0\u05e9\u05de\u05e2");
        Assert.True(buffer.TryPlanReplacement(next, snapshot.Version, out var plan2));
        Assert.Equal(7, plan2.BackspaceCount);
        Assert.Equal(7, plan2.ReplacedLength);
    }

    [Fact]
    public void WithoutBreak_AcceptedCandidate_StaysInsideTheSegment()
    {
        // Documents why the break matters: the candidate would otherwise
        // keep dragging the segment (and its direction) forward.
        var buffer = new TypingContextBuffer();
        foreach (char c in "akuo") buffer.AppendChar(c);
        var snapshot = buffer.Snapshot();
        var suggestion = Suggest("akuo", "\u05e9\u05dc\u05d5\u05dd");

        Assert.True(buffer.TryPlanReplacement(suggestion, snapshot.Version, out var plan));
        Assert.True(buffer.CommitReplacement(plan));

        snapshot = buffer.Snapshot();
        Assert.Contains("\u05e9\u05dc\u05d5\u05dd", snapshot.Segment);
    }
}
