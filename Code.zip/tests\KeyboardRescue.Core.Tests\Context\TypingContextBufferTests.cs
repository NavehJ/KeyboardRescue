using KeyboardRescue.Core.Context;
using KeyboardRescue.Core.Detection;
using Xunit;

namespace KeyboardRescue.Core.Tests.Context;

public class TypingContextBufferTests
{
    private static Suggestion MakeSuggestion(string original, string candidate) => new(
        OriginalText: original,
        CandidateText: candidate,
        Direction: CorrectionDirection.ToHebrew,
        Confidence: 0.97,
        Strength: SuggestionStrength.Strong,
        Scores: null!,
        ReplacementStartOffset: 0,
        ReplacementLength: original.Length);

    [Fact]
    public void Append_BuildsSegmentAndSnapshot()
    {
        var buffer = new TypingContextBuffer();
        foreach (char c in "bang") buffer.AppendChar(c);

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal("bang", snap.Segment);
        Assert.Equal("bang", snap.Text);
        Assert.Equal(string.Empty, snap.PrecedingText);
    }

    [Fact]
    public void BreakSegment_MovesSegmentIntoContext()
    {
        var buffer = new TypingContextBuffer();
        foreach (char c in "hello\n") buffer.AppendChar(c);
        buffer.BreakSegment();
        foreach (char c in "akuo") buffer.AppendChar(c);

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal("akuo", snap.Segment);
        Assert.Equal("hello\n", snap.PrecedingText);
    }

    [Fact]
    public void PrecedingText_IsBoundedByWindow()
    {
        var buffer = new TypingContextBuffer(precedingWindow: 5);
        buffer.AppendText("abcdef");
        buffer.BreakSegment();
        buffer.AppendText("xyz");

        Assert.Equal("bcdef", buffer.Snapshot().PrecedingText);
    }

    [Fact]
    public void Backspace_ShrinksSegment()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("bangg");
        buffer.Backspace();

        Assert.Equal("bang", buffer.Snapshot().Segment);
    }

    [Fact]
    public void Backspace_BelowZero_ClampsAndKeepsSegmentValid()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("a");
        buffer.Backspace(10);

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal(string.Empty, snap.Text);
        Assert.Equal(string.Empty, snap.Segment);
    }

    [Fact]
    public void Backspace_AcrossBoundary_SlidesSegmentStart()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("hi\n");
        buffer.BreakSegment();
        buffer.AppendText("ak");
        buffer.Backspace(3); // deletes "ak" plus one char of context ("\n")

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal("hi", snap.Text);
        Assert.Equal(string.Empty, snap.Segment); // boundary slid with the deletion
        Assert.Equal("hi", snap.PrecedingText);  // deleted context is still context
    }

    [Fact]
    public void Capacity_TrimSlidesFrontAndKeepsSegmentConsistent()
    {
        var buffer = new TypingContextBuffer(capacity: 8);
        buffer.AppendText("0123");
        buffer.BreakSegment();
        buffer.AppendText("abcdefgh"); // 12 chars total, overflows by 4

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal(8, snap.Text.Length);
        Assert.Equal("abcdefgh", snap.Text);
        // The overflow ate the entire "0123" context, so the segment start
        // clamped to 0: the segment itself was never damaged.
        Assert.Equal("abcdefgh", snap.Segment);
    }

    [Fact]
    public void Reset_ClearsEverything()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("hello world");
        buffer.Reset();

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal(string.Empty, snap.Text);
        Assert.Equal(string.Empty, snap.Segment);
        Assert.Equal(string.Empty, snap.PrecedingText);
    }

    [Fact]
    public void Version_IncrementsOnEveryMutation()
    {
        var buffer = new TypingContextBuffer();
        int v0 = buffer.Version;
        buffer.AppendChar('a');
        buffer.Backspace();
        buffer.BreakSegment();
        buffer.Reset();

        Assert.Equal(v0 + 4, buffer.Version);
    }

    [Fact]
    public void TryPlanReplacement_HappyPath_PlanMatchesBufferTail()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("nv akuo");
        int version = buffer.Version; // snapshot the engine analyzed

        Suggestion suggestion = MakeSuggestion("akuo", "שלום") with
        {
            ReplacementStartOffset = 3,
        };
        Assert.True(buffer.TryPlanReplacement(suggestion, version, out ReplacementPlan? plan));
        Assert.Equal(4, plan.BackspaceCount);
        Assert.Equal("שלום", plan.TextToInsert);
        Assert.Equal(3, plan.BufferStart);
    }

    [Fact]
    public void TryPlanReplacement_StaleVersion_Fails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo");
        int staleVersion = buffer.Version;
        buffer.AppendChar('!'); // user kept typing after analysis

        Assert.False(buffer.TryPlanReplacement(MakeSuggestion("akuo", "שלום"), staleVersion, out _));
    }

    [Fact]
    public void TryPlanReplacement_TextChangedUnderneath_Fails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("abcd");
        buffer.Backspace();
        buffer.AppendChar('e'); // same version length, different text

        Assert.False(buffer.TryPlanReplacement(MakeSuggestion("abcd", "שלום"), buffer.Version, out _));
    }

    [Fact]
    public void TryPlanReplacement_RangeNotAtEnd_Fails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo tail");

        // Suggestion targets only the first word; text exists after it, so a
        // backspace-based replacement would corrupt "tail".
        Assert.False(buffer.TryPlanReplacement(MakeSuggestion("akuo", "שלום"), buffer.Version, out _));
    }

    [Fact]
    public void TryPlanReplacement_MismatchedLength_Fails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo");

        var bad = MakeSuggestion("akuo", "שלום") with { ReplacementLength = 2 };
        Assert.False(buffer.TryPlanReplacement(bad, buffer.Version, out _));
    }

    [Fact]
    public void CommitReplacement_UpdatesBufferAndKeepsSegment()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("nv ");
        buffer.BreakSegment();
        buffer.AppendText("akuo");
        int version = buffer.Version;

        var suggestion = MakeSuggestion("akuo", "שלום");
        Assert.True(buffer.TryPlanReplacement(suggestion, version, out ReplacementPlan? plan));
        Assert.True(buffer.CommitReplacement(plan));

        ContextSnapshot snap = buffer.Snapshot();
        Assert.Equal("nv שלום", snap.Text);
        Assert.Equal("שלום", snap.Segment); // segment start is unchanged
        Assert.True(buffer.Version > plan.Version);
    }

    [Fact]
    public void CommitReplacement_StalePlan_Fails()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("akuo");
        int version = buffer.Version;
        Assert.True(buffer.TryPlanReplacement(MakeSuggestion("akuo", "שלום"), version, out ReplacementPlan? plan));

        buffer.AppendChar('!'); // something else typed before the commit

        Assert.False(buffer.CommitReplacement(plan));
    }

    [Fact]
    public void TryPlanReplacement_RespectsStartOffsetWithinSegment()
    {
        var buffer = new TypingContextBuffer();
        buffer.AppendText("shlom akuo");
        int version = buffer.Version;

        // The engine reports offsets relative to the segment start; the
        // buffer must map them onto the absolute tail correctly.
        var tailSuggestion = MakeSuggestion("akuo", "שלום") with
        {
            ReplacementStartOffset = "shlom ".Length,
        };

        Assert.True(buffer.TryPlanReplacement(tailSuggestion, version, out ReplacementPlan? plan));
        Assert.Equal(4, plan.BackspaceCount);
        Assert.Equal(buffer.Snapshot().Text.Length - 4, plan.BufferStart);
    }
}
