using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;
using Xunit;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Letter-position punctuation: the keys that produce ',' '.' ';' ''' in
/// the wrong layout are *letters* in the intended one (tav, final tsadi,
/// final pe, and the Hebrew 'w' key's apostrophe). The wrong-layout form
/// of "how" is "ים'", of "תודה" is ",usv" - splitting that punctuation
/// off makes the remaining fragment look like a valid word of the wrong
/// script ("ים" alone) and the conversion never fires.
/// <para>
/// The safety property: own-language realism is judged on the WORD alone,
/// so correct text with real punctuation ("hello, world") is never
/// converted - a valid word can't be dragged down by attached
/// punctuation it shouldn't have.
/// </para>
/// </summary>
public class LetterPositionPunctuationTests
{
    private static readonly DetectionEngine Engine = new();

    private static Suggestion Require(string typed) =>
        Engine.Analyze(new AnalysisRequest(typed))!;

    private static string OnHebrewLayout(string english) =>
        new KeyboardLayoutMapper().ConvertEnglishLayoutToHebrew(english);

    private static string OnEnglishLayout(string hebrew) =>
        new KeyboardLayoutMapper().ConvertHebrewLayoutToEnglish(hebrew);

    [Fact]
    public void WrongLayoutWord_TrailingApostrophe_Converts()
    {
        // The Hebrew 'w' key produces the apostrophe, so the wrong-layout
        // form of a w-ending English word ends with it. ("how" alone is a
        // two-letter segment and stays refused by design; "what" shows
        // the same mechanism with enough letters to analyze.)
        var suggestion = Require(OnHebrewLayout("what"));

        Assert.Equal("what", suggestion.CandidateText);
        Assert.Equal(CorrectionDirection.ToEnglish, suggestion.Direction);
    }

    [Fact]
    public void WrongLayoutWorld_LeadingApostrophe_ConvertsToWorld()
    {
        var suggestion = Require(OnHebrewLayout("world"));

        Assert.Equal("world", suggestion.CandidateText);
    }

    [Fact]
    public void WrongLayoutWord_WithLetterPositionComma_ConvertsToToda()
    {
        // The Hebrew tav sits on the comma key: "תודה" typed on the
        // English layout is ",usv".
        var suggestion = Require(OnEnglishLayout("\u05ea\u05d5\u05d3\u05d4"));

        Assert.Equal("\u05ea\u05d5\u05d3\u05d4", suggestion.CandidateText);
    }

    [Fact]
    public void Sentence_WithLetterPositionPunctuation_Converts()
    {
        string typed = OnEnglishLayout("\u05e9\u05dc\u05d5\u05dd \u05ea\u05d5\u05d3\u05d4");
        var suggestion = Require(typed);

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd \u05ea\u05d5\u05d3\u05d4", suggestion.CandidateText);
    }

    [Fact]
    public void CorrectEnglishWithComma_IsNotConverted()
    {
        // The comma after "hello" is real punctuation: the word's own
        // realism (a dictionary hit) protects it from the unit join.
        Assert.Null(Engine.Analyze(new AnalysisRequest("hello, world")));
        Assert.Null(Engine.Analyze(new AnalysisRequest("thanks, friend")));
    }

    [Fact]
    public void CorrectHebrewWithComma_IsNotConverted()
    {
        Assert.Null(Engine.Analyze(
            new AnalysisRequest("\u05e9\u05dc\u05d5\u05dd, \u05de\u05d4 \u05e0\u05e9\u05de\u05e2")));
    }
}
