using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Tests.Detection;

public class ContentClassifierTests
{
    [Theory]
    [InlineData("https://example.com", ContentKind.Url)]
    [InlineData("https://github.com/foo/bar?x=1", ContentKind.Url)]
    [InlineData("www.example.co.il/path", ContentKind.Url)]
    [InlineData("example.com/very/long/path", ContentKind.Url)]
    [InlineData("user.name+tag@example.com", ContentKind.Email)]
    [InlineData("me@localhost.io", ContentKind.Email)]
    [InlineData("550e8400-e29b-41d4-a716-446655440000", ContentKind.HashLike)]
    [InlineData("deadbeefdeadbeefdeadbeefdeadbeef", ContentKind.HashLike)]
    [InlineData("SGVsbG9Xb3JsZEhlbGxvV29ybGRIZWxsb1dvcmxk", ContentKind.HashLike)]
    [InlineData("API_KEY_123", ContentKind.Identifier)]
    [InlineData("MY_CONSTANT_VALUE", ContentKind.Identifier)]
    [InlineData("abc123-def456", ContentKind.Identifier)]
    [InlineData("const x = { a: 1 };", ContentKind.CodeLike)]
    [InlineData("<div class=\"x\">", ContentKind.CodeLike)]
    [InlineData("SELECT * FROM users;", ContentKind.CodeLike)]
    [InlineData("npm run build && rm -rf ./dist", ContentKind.CodeLike)]
    [InlineData("score += points => next()", ContentKind.CodeLike)]
    [InlineData("/usr/local/bin/node", ContentKind.FilePath)]
    [InlineData("C:\\Users\\test\\file.txt", ContentKind.FilePath)]
    [InlineData("~/projects/app/main.rs", ContentKind.FilePath)]
    [InlineData("42", ContentKind.Numeric)]
    [InlineData("3.14159", ContentKind.Numeric)]
    [InlineData("file mp3 test", ContentKind.MixedTechnical)]
    public void DetectsTechnicalContent(string text, ContentKind expected) =>
        Assert.Equal(expected, ContentClassifier.Classify(text));

    [Theory]
    [InlineData("hello how are you")]
    [InlineData("שלום מה נשמע")]
    [InlineData("don't stop believing")]
    [InlineData("come from work")]
    [InlineData("(hello world)")]
    [InlineData("what; why! how")]
    [InlineData("a < b does not appear in prose")]
    [InlineData("it costs $5 today")]
    [InlineData("אני פותח את Google Chrome")]
    public void ProseIsNotTechnical(string text)
    {
        var kind = ContentClassifier.Classify(text);
        // The angle-bracket line is intentionally classified as code (never
        // corrected); everything else must be plain or mixed-technical.
        if (text.Contains('<'))
            Assert.Equal(ContentKind.CodeLike, kind);
        else
            Assert.True(kind is ContentKind.PlainText or ContentKind.MixedTechnical,
                $"'{text}' was classified as {kind}");
    }
}
