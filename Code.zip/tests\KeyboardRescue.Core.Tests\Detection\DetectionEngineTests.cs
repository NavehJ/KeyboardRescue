using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// End-to-end detection tests: real-world wrong-layout scenarios plus the
/// must-not-fire cases (false positives are worse than false negatives).
/// The scores are calibrated by these tests, not by special-casing input.
/// </summary>
public class DetectionEngineTests
{
    private static readonly DetectionEngine Engine = new();

    private static Suggestion? Analyze(string segment, string? preceding = null) =>
        Engine.Analyze(new AnalysisRequest(segment, preceding));

    // ---- must-fire: high-confidence mistakes --------------------------------

    [Fact]
    public void HebrewMistake_FullSentence_IsStrongSuggestion()
    {
        var suggestion = Analyze("akuo nv bang");

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion!.Direction);
        Assert.Equal("שלום מה נשמע", suggestion.CandidateText);
        Assert.Equal(SuggestionStrength.Strong, suggestion.Strength);
        Assert.True(suggestion.Confidence >= 0.95, $"confidence {suggestion.Confidence:F3} < 0.95");
    }

    [Fact]
    public void HebrewMistake_SingleWord_IsSuggested()
    {
        var suggestion = Analyze("akuo");

        Assert.NotNull(suggestion);
        Assert.Equal("שלום", suggestion!.CandidateText);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion.Direction);
        Assert.True(suggestion.Confidence >= 0.80, $"confidence {suggestion.Confidence:F3} < 0.80");
    }

    [Fact]
    public void EnglishMistake_FullSentence_IsStrongSuggestion()
    {
        string typedOnHebrew = string.Join(' ', "יקךךם", "ים'", "שרק", "טםו");
        var suggestion = Analyze(typedOnHebrew);

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToEnglish, suggestion!.Direction);
        Assert.Equal("hello how are you", suggestion.CandidateText);
        Assert.Equal(SuggestionStrength.Strong, suggestion.Strength);
        Assert.True(suggestion.Confidence >= 0.95, $"confidence {suggestion.Confidence:F3} < 0.95");
    }

    [Fact]
    public void HebrewMistake_WithTrailingSlash_RemapsSentenceDot()
    {
        // Hebrew muscle memory presses the '/'-position key for '.' while
        // the US layout is active, so the mistake appears as "akuo/".
        var suggestion = Analyze("akuo/");

        Assert.NotNull(suggestion);
        Assert.Equal("שלום.", suggestion!.CandidateText);
    }

    [Fact]
    public void HebrewMistake_UppercaseCapsLock_Converts()
    {
        var suggestion = Analyze("AKUO NV BANG");

        Assert.NotNull(suggestion);
        Assert.Equal("שלום מה נשמע", suggestion!.CandidateText);
    }

    // ---- must-not-fire: correct text ----------------------------------------

    [Fact]
    public void CorrectEnglish_IsNeverSuggested() =>
        Assert.Null(Analyze("hello how are you"));

    [Fact]
    public void CorrectHebrew_IsNeverSuggested() =>
        Assert.Null(Analyze("שלום מה נשמע"));

    [Fact]
    public void ShortFragments_AreIgnored()
    {
        Assert.Null(Analyze("ab"));
        Assert.Null(Analyze("nv"));
        Assert.Null(Analyze(""));
        Assert.Null(Analyze("   "));
        Assert.Null(Analyze("123"));
    }

    [Fact]
    public void SingleCommonEnglishWord_WithPlausibleOriginal_IsIgnored()
    {
        // "bang" alone is a perfectly normal English word; a real word on
        // its own is not enough evidence to touch it.
        Assert.Null(Analyze("bang"));
    }

    [Theory]
    [InlineData("אני פותח את Google Chrome")]
    [InlineData("אני משתמש ב ChatGPT")]
    [InlineData("שלח לי את ה GitHub link")]
    [InlineData("google chatgpt windows")]
    public void MixedAndBrandHeavyText_IsNeverSuggested(string text) =>
        Assert.Null(Analyze(text));

    [Fact]
    public void RealEnglishWithOneGarbageToken_IsNotSuggested()
    {
        // A single suspicious token inside plausible English stays untouched.
        Assert.Null(Analyze("hello bng, world"));
    }

    // ---- must-not-fire: technical content -----------------------------------

    [Theory]
    [InlineData("https://example.com")]
    [InlineData("https://github.com/foo/bar")]
    [InlineData("www.example.co.il/path")]
    [InlineData("hello@example.com")]
    [InlineData("API_KEY_123")]
    [InlineData("abc123-def456")]
    [InlineData("550e8400-e29b-41d4-a716-446655440000")]
    [InlineData("0123456789abcdef0123456789abcdef")]
    [InlineData("const x = { a: 1 };")]
    [InlineData("SELECT * FROM users;")]
    [InlineData("npm run build && rm -rf ./dist")]
    [InlineData("/usr/local/bin/node")]
    [InlineData("C:\\Users\\test\\file.txt")]
    [InlineData("{'a': 1}")]
    [InlineData("<div class=\"x\">")]
    public void TechnicalStrings_AreNeverSuggested(string text) =>
        Assert.Null(Analyze(text));

    [Fact]
    public void RandomGibberish_WithoutRealCandidate_IsIgnored() =>
        Assert.Null(Analyze("qwertyuiop asdfghjk"));

    // ---- context window ------------------------------------------------------

    [Fact]
    public void HebrewContext_ImprovesOrKeepsConfidence()
    {
        // The same Latin segment: with Hebrew context the engine must not be
        // less willing than without.
        var without = Analyze("bng tamid");   // plausibility guards may null it
        var withContext = Analyze("bng", preceding: "anax");

        // At minimum: providing context never throws and never flips a
        // correct-text segment into a suggestion.
        Assert.Null(Analyze("hello world", preceding: "shalom ani poteach"));
        _ = without;
        _ = withContext;
    }

    [Fact]
    public void PrecedingHebrewContext_DoesNotCreateSuggestionsForRealEnglish() =>
        Assert.Null(Analyze("how are you", preceding: "shalom ma nishma"));

    // ---- determinism & API ---------------------------------------------------

    [Fact]
    public void Analysis_IsDeterministic()
    {
        var first = Analyze("akuo nv bang");
        for (int i = 0; i < 3; i++)
        {
            var again = Analyze("akuo nv bang");
            Assert.NotNull(again);
            Assert.Equal(first!.CandidateText, again!.CandidateText);
            Assert.Equal(first.Confidence, again.Confidence);
        }
    }

    [Fact]
    public void ReplacementRange_CoversExactSegment()
    {
        var suggestion = Analyze("  ako  ");

        Assert.NotNull(suggestion);
        Assert.Equal("ako", suggestion!.OriginalText);
        Assert.Equal(2, suggestion.ReplacementStartOffset);
        Assert.Equal(3, suggestion.ReplacementLength);
        Assert.NotNull(suggestion.CandidateText);
    }

    [Fact]
    public void OversizedSegment_IsIgnored()
    {
        string huge = string.Concat(Enumerable.Repeat("akuo ", 200));
        Assert.Null(Analyze(huge));
    }

    [Fact]
    public void ScoreBreakdown_ExposesAllComponents()
    {
        var suggestion = Analyze("akuo nv bang");
        Assert.NotNull(suggestion);
        var s = suggestion!.Scores;
        Assert.InRange(s.OriginalTextScore, 0, 1);
        Assert.InRange(s.ConvertedTextScore, 0, 1);
        Assert.InRange(s.LanguageProbability, 0, 1);
        Assert.InRange(s.DictionaryScore, 0, 1);
        Assert.InRange(s.CharacterNgramScore, 0, 1);
        Assert.InRange(s.WordFrequencyScore, 0, 1);
        Assert.InRange(s.PatternScore, 0, 1);
        Assert.InRange(s.MixedLanguageScore, 0, 1);
        Assert.InRange(s.SpecialContentPenalty, 0, 1);
        Assert.InRange(s.Confidence, 0, 1);
        Assert.Equal(s.Confidence, suggestion.Confidence);
    }
}
