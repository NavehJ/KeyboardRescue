using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Directional regression tests locking both conversion directions through
/// the full engine. The English→Hebrew cases exist because the majority-flip
/// re-read rule in <see cref="CandidateGenerator"/> was ToEnglish-only: an
/// unscoreable word survived inside an otherwise fully converted segment and
/// the mixed candidate ("שלום מה anku") was still offered as strong.
/// </summary>
public class DirectionalRegressionTests
{
    private static readonly DetectionEngine Engine = new();

    private static Suggestion? Analyze(string segment) =>
        Engine.Analyze(new AnalysisRequest(segment));

    private static bool ContainsLatinLetters(string text)
    {
        foreach (char c in text)
            if (c is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z')) return true;
        return false;
    }

    // ---- English (QWERTY) layout typed -> Hebrew ----------------------------

    [Fact]
    public void EnglishToHebrew_UnscoreableWord_IsConvertedPositionally_NotLeftBehind()
    {
        // "anku" maps positionally to "שמלו" - not a dictionary word, so the
        // flip scorer cannot approve it - but inside a mostly-converted
        // segment it must be re-read through the layout anyway. Before the
        // fix the candidate came out as the mixed "שלום מה anku" with
        // confidence 1.000 (the leftover Latin token is invisible to the
        // Hebrew-script candidate scoring).
        var suggestion = Analyze("akuo nv anku");

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion!.Direction);
        Assert.Equal("שלום מה שמלו", suggestion.CandidateText);
        Assert.False(ContainsLatinLetters(suggestion.CandidateText),
            "candidate must not contain untranslated Latin text");
        Assert.Equal(SuggestionStrength.Strong, suggestion.Strength);
    }

    [Fact]
    public void EnglishToHebrew_CalibrationSentence_IsStrongSuggestion()
    {
        // The canonical positional pair: keys a k u o _ n v _ b a n g read
        // through the Hebrew layout are "שלום מה נשמע"; "anku" maps to
        // "שמלו" instead - see KeyboardLayoutMapperTests.
        var suggestion = Analyze("akuo nv bang");

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion!.Direction);
        Assert.Equal("שלום מה נשמע", suggestion.CandidateText);
        Assert.Equal(SuggestionStrength.Strong, suggestion!.Strength);
    }

    [Fact]
    public void EnglishToHebrew_PunctuationAndRepeatedSpaces_PreservedPositionally()
    {
        // '/' sits where the Hebrew sentence dot is, so it remaps to '.';
        // double spaces must survive byte-for-byte.
        var slash = Analyze("akuo nv bang/");
        Assert.NotNull(slash);
        Assert.Equal("שלום מה נשמע.", slash!.CandidateText);

        var spaced = Analyze("akuo  nv bang");
        Assert.NotNull(spaced);
        Assert.Equal("שלום  מה נשמע", spaced!.CandidateText);
    }

    [Fact]
    public void EnglishToHebrew_CorrectEnglish_IsNeverSuggested() =>
        Assert.Null(Analyze("hello how are you"));

    // ---- Hebrew layout typed -> English (must keep working) ----------------

    [Fact]
    public void HebrewToEnglish_HelloOnTheActualLayout_BecomesHello()
    {
        // The Hebrew text produced by pressing the physical keys of "hello"
        // on QWERTY - computed with the project's own layout mapping, and
        // pinned here so the pair itself is under test.
        var mapper = new KeyboardLayoutMapper();
        string typedOnHebrew = mapper.ConvertEnglishLayoutToHebrew("hello");
        Assert.Equal("יקךךם", typedOnHebrew);

        var suggestion = Analyze(typedOnHebrew);

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToEnglish, suggestion!.Direction);
        Assert.Equal("hello", suggestion!.CandidateText);
        Assert.False(ContainsLatinLetters(typedOnHebrew),
            "precondition: the typed segment is pure Hebrew");
    }

    [Fact]
    public void HebrewToEnglish_FullSentence_IsStrongSuggestion()
    {
        // The Hebrew-layout text for "hello how are you" - computed with the
        // project's own mapping rather than a hand-typed literal, so the test
        // exercises the actual layout tables.
        var mapper = new KeyboardLayoutMapper();
        string typedOnHebrew = mapper.ConvertEnglishLayoutToHebrew("hello how are you");

        var suggestion = Analyze(typedOnHebrew);

        Assert.NotNull(suggestion);
        Assert.Equal(CorrectionDirection.ToEnglish, suggestion!.Direction);
        Assert.Equal("hello how are you", suggestion!.CandidateText);
        Assert.Equal(SuggestionStrength.Strong, suggestion.Strength);
    }

    [Fact]
    public void HebrewToEnglish_CorrectHebrew_IsNeverSuggested() =>
        Assert.Null(Analyze("שלום מה נשמע"));
}
