using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;
using Xunit;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Vocabulary coverage: the word lists must recognize ordinary vocabulary
/// in both languages, and a dictionary miss must not block a layout
/// correction (the character n-gram models carry the rest - the flip
/// decision is relative, not membership-gated).
/// </summary>
public class LanguageDataCoverageTests
{
    private static readonly LanguageData Data = LanguageData.Default;

    [Theory]
    [InlineData("hello")]
    [InlineData("world")]
    [InlineData("thanks")]
    [InlineData("please")]
    [InlineData("sorry")]
    [InlineData("today")]
    [InlineData("tomorrow")]
    [InlineData("keyboard")]
    [InlineData("computer")]
    [InlineData("password")]
    [InlineData("message")]
    [InlineData("family")]
    [InlineData("friend")]
    [InlineData("house")]
    [InlineData("water")]
    [InlineData("coffee")]
    [InlineData("music")]
    public void CommonEnglishWords_AreRecognized(string word) =>
        Assert.True(Data.EnglishWords.Contains(word), $"missing English word: {word}");

    [Theory]
    [InlineData("\u05e9\u05dc\u05d5\u05dd")]     // שלום
    [InlineData("\u05de\u05d4")]                 // מה
    [InlineData("\u05e0\u05e9\u05de\u05e2")]     // נשמע
    [InlineData("\u05d0\u05e0\u05d9")]           // אני
    [InlineData("\u05d0\u05ea\u05d4")]           // אתה
    [InlineData("\u05dc\u05d0")]                 // לא
    [InlineData("\u05e2\u05dc")]                 // על
    [InlineData("\u05d1\u05e1\u05d3\u05e8")]     // בסדר
    [InlineData("\u05d1\u05d9\u05ea")]           // בית
    [InlineData("\u05d9\u05d5\u05dd")]           // יום
    [InlineData("\u05d8\u05d5\u05d1")]           // טוב
    [InlineData("\u05ea\u05d5\u05d3\u05d4")]     // תודה
    [InlineData("\u05d0\u05d7\u05e8\u05d9")]     // אחרי
    [InlineData("\u05dc\u05e4\u05e0\u05d9")]     // לפני
    [InlineData("\u05db\u05da")]                 // כך
    [InlineData("\u05db\u05dc")]                 // כל
    [InlineData("\u05d1\u05d9\u05df")]           // בין
    public void CommonHebrewWords_AreRecognized(string word) =>
        Assert.True(Data.HebrewWords.Contains(word), $"missing Hebrew word: U+{(int)word[0]:X4}...");

    [Fact]
    public void ModernVocabulary_IsPresent()
    {
        // Present only since the expanded lists.
        Assert.True(Data.EnglishWords.Contains("emoji"));
        Assert.True(Data.EnglishWords.Contains("password"));
        Assert.True(Data.EnglishWords.Contains("laptop"));
        Assert.True(Data.HebrewWords.Contains("\u05de\u05d9\u05d9\u05dc"));       // מייל
        Assert.True(Data.HebrewWords.Contains("\u05d0\u05e4\u05dc\u05d9\u05e7\u05e6\u05d9\u05d4")); // אפליקציה
        Assert.True(Data.HebrewWords.Contains("\u05de\u05d7\u05e9\u05d1"));       // מחשב
    }

    [Fact]
    public void UnlistedButWellFormedWord_StillConvertsPositionally()
    {
        // "שכנות" (neighbors) is well-formed Hebrew that the frequency
        // list does not contain: a dictionary miss alone must NOT block a
        // layout correction - the n-gram model judges the converted form.
        // Its wrong-layout form ends with the comma key, which is the tav
        // position - the letter-position punctuation case.
        const string target = "\u05e9\u05db\u05e0\u05d5\u05ea";
        Assert.False(Data.HebrewWords.Contains(target),
            "precondition: the word must be absent from the dictionary");

        // What the user's fingers produced on the English layout.
        string typed = new KeyboardLayoutMapper().ConvertHebrewLayoutToEnglish(target);

        var candidate = new CandidateGenerator().Generate(
            typed, Data, DetectionOptions.Default, KeyboardLayoutCatalog.HebrewStandard);

        Assert.Equal(target, candidate.Text);
        Assert.Equal(1, candidate.FlippedWords);
    }
}
