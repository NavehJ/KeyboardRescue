using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;
using Xunit;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Mixed-language and continuous-typing regressions. Before the per-word
/// direction rework the engine picked ONE direction per segment from the
/// majority script, which caused four distinct failures:
/// <list type="bullet">
/// <item>a wrong-layout word next to valid text was rejected when it was the
/// only converted word (the single-flip rule read the segment mean, which
/// valid words raised above the bar: "hello akuo" was dropped);</item>
/// <item>gibberish in the minority script was never converted at all
/// ("שלום עולם akuo");</item>
/// <item>the global re-read rule converted VALID words - "akuo nv hello"
/// turned "hello" into gibberish and the candidate collapsed;</item>
/// <item>after an accepted correction the settled candidate anchored the
/// segment's direction, so new mistyped words never fired.</item>
/// </list>
/// </summary>
public class MixedLanguageRegressionTests
{
    private static readonly DetectionEngine Engine = new();

    private static Suggestion? Analyze(string segment) =>
        Engine.Analyze(new AnalysisRequest(segment));

    private static Suggestion Require(string segment)
    {
        var suggestion = Analyze(segment);
        Assert.NotNull(suggestion);
        return suggestion!;
    }

    /// <summary>What pressing the physical keys of an English string on the
    /// Hebrew layout produces (the H->E worst case's input).</summary>
    private static string TypedOnHebrewLayout(string english) =>
        new KeyboardLayoutMapper().ConvertEnglishLayoutToHebrew(english);

    // ---- one wrong-layout word next to valid text --------------------------

    [Fact]
    public void OneWrongLayoutWord_NextToValidEnglish_ConvertsOnlyThatWord()
    {
        var suggestion = Require("hello akuo");

        Assert.Equal("hello \u05e9\u05dc\u05d5\u05dd", suggestion.CandidateText);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion.Direction);
    }

    [Fact]
    public void TwoWrongLayoutWords_NextToValidEnglish_Convert()
    {
        var suggestion = Require("hello akuo nv");

        Assert.Equal("hello \u05e9\u05dc\u05d5\u05dd \u05de\u05d4", suggestion.CandidateText);
    }

    [Fact]
    public void OneWrongLayoutWord_NextToValidHebrew_ConvertsOnlyThatWord()
    {
        string segment = "\u05e9\u05dc\u05d5\u05dd " + TypedOnHebrewLayout("hello");
        var suggestion = Require(segment);

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd hello", suggestion.CandidateText);
        Assert.Equal(CorrectionDirection.ToEnglish, suggestion.Direction);
    }

    [Fact]
    public void WrongLayoutPhrase_InsideValidHebrew_ConvertsWholePhrase()
    {
        // "hello world" typed while the Hebrew layout was active.
        string segment = "\u05e9\u05dc\u05d5\u05dd "
            + TypedOnHebrewLayout("hello") + " " + TypedOnHebrewLayout("world");
        var suggestion = Require(segment);

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd hello world", suggestion.CandidateText);
    }

    // ---- minority-direction (and both-direction) gibberish ------------------

    [Fact]
    public void WrongLayoutWord_InMinorityScript_IsStillConverted()
    {
        var suggestion = Require("\u05e9\u05dc\u05d5\u05dd \u05e2\u05d5\u05dc\u05dd akuo");

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd \u05e2\u05d5\u05dc\u05dd \u05e9\u05dc\u05d5\u05dd", suggestion.CandidateText);
    }

    [Fact]
    public void BothDirections_InOneSegment_ConvertTogether()
    {
        // "akuo" is wrong-layout Hebrew inside an otherwise-English segment,
        // "יקךךם" is wrong-layout English: both must convert in one offer.
        string segment = "akuo " + TypedOnHebrewLayout("hello");
        var suggestion = Require(segment);

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd hello", suggestion.CandidateText);
        Assert.Equal(CorrectionDirection.Mixed, suggestion.Direction);
    }

    // ---- valid words are never sacrificed -----------------------------------

    [Fact]
    public void ValidWordInsideMostlyWrongLayoutSegment_IsPreserved()
    {
        var suggestion = Require("akuo nv hello");

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 hello", suggestion.CandidateText);
    }

    [Fact]
    public void CorrectText_IsNeverSuggested()
    {
        Assert.Null(Analyze("hello how are you"));
        Assert.Null(Analyze("hello world"));
        Assert.Null(Analyze("\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 \u05e0\u05e9\u05de\u05e2"));
    }

    // ---- continuous (streamed) typing ----------------------------------------

    [Fact]
    public void NewWrongLayoutWords_AfterAcceptedCorrection_StillConvert()
    {
        // The settled Hebrew of an earlier accept is context now; the new
        // mistyped words convert on their own instead of being blocked by
        // the accepted candidate's script.
        string segment = "\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 \u05e0\u05e9\u05de\u05e2 nv";
        var suggestion = Require(segment);

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 \u05e0\u05e9\u05de\u05e2 \u05de\u05d4", suggestion.CandidateText);
    }

    // ---- punctuation -----------------------------------------------------------

    [Fact]
    public void SlashBetweenConvertedWords_BecomesHebrewSentenceDot()
    {
        var suggestion = Require("akuo nv bang/");

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd \u05de\u05d4 \u05e0\u05e9\u05de\u05e2.", suggestion.CandidateText);
    }

    [Fact]
    public void PunctuationBetweenConvertedAndValidWord_IsPreserved()
    {
        // The comma sits between a converted word and valid English: it is
        // intentional punctuation and must not be remapped.
        var suggestion = Require("akuo, hello");

        Assert.Equal("\u05e9\u05dc\u05d5\u05dd, hello", suggestion.CandidateText);
    }
}
