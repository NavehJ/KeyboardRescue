using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Real-world regression: typing the keys for "אם אתה רוצה אפשר לעשות
/// משהו מגניב" while the OS layout is English produces
/// "to t,v rumv tpar kgau, navu ndbhc". The app converted everything
/// except the head ("to t,ה ...") because "to" is a valid English word
/// (comparative margin never flips it alone) and the tokenizer splits
/// "t,v" into "t" / "," / "v" so neither single letter can win alone.
/// The fix evaluates segment-level evidence alongside token-level
/// verdicts; this test pins the complete sentence end to end.
/// </summary>
public class RealWorldSentenceTests
{
    private const string Input = "to t,v rumv tpar kgau, navu ndbhc";
    private const string Expected = "אם אתה רוצה אפשר לעשות משהו מגניב";

    private static readonly DetectionEngine Engine = new();
    private static readonly CandidateGenerator Generator = new();
    private static readonly KeyboardLayoutMapper Mapper = new();

    private static Suggestion? Analyze(string segment) =>
        Engine.Analyze(new AnalysisRequest(segment));

    [Fact]
    public void KeyboardMapping_IsPhysicallyAchievable()
    {
        // Requirement: verify the expected output character-by-character
        // through the real layout tables, not by assumption.
        Assert.Equal("אם", Mapper.Convert("to", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        Assert.Equal("אתה", Mapper.Convert("t,v", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        Assert.Equal("רוצה", Mapper.Convert("rumv", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        Assert.Equal("אפשר", Mapper.Convert("tpar", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        // The comma key is Tav: "kgau," is the whole of "לעשות", not a word
        // plus punctuation.
        Assert.Equal("לעשות", Mapper.Convert("kgau,", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        Assert.Equal("משהו", Mapper.Convert("navu", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
        Assert.Equal("מגניב", Mapper.Convert("ndbhc", KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));

        // Whole-segment positional conversion yields exactly the expected
        // sentence (punctuation included, whitespace preserved).
        Assert.Equal(
            Expected,
            Mapper.Convert(Input, KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.HebrewStandard));
    }

    [Fact]
    public void CompleteSentence_ConvertsFully_ToHebrew()
    {
        var candidate = Generator.Generate(
            Input, LanguageData.Default, DetectionOptions.Default,
            KeyboardLayoutCatalog.HebrewStandard);

        // Exact equality pins whitespace and punctuation preservation.
        Assert.Equal(Expected, candidate.Text);

        var suggestion = Analyze(Input);
        Assert.NotNull(suggestion);
        Assert.Equal(Expected, suggestion!.CandidateText);
        Assert.Equal(CorrectionDirection.ToHebrew, suggestion.Direction);
    }

    [Fact]
    public void ShortToken_DoesNotBlock_RestOfSentence()
    {
        // Even the pre-fix engine converted the tail; guard that a short
        // ambiguous head can never suppress the rest.
        var suggestion = Analyze(Input);
        Assert.NotNull(suggestion);
        Assert.Contains("רוצה", suggestion!.CandidateText);
        Assert.Contains("משהו", suggestion.CandidateText);
        Assert.Contains("מגניב", suggestion.CandidateText);
    }

    [Fact]
    public void CorrectHebrew_IsNeverSuggested()
    {
        // The working reverse direction: valid Hebrew stays untouched.
        Assert.Null(Analyze(Expected));
    }

    [Fact]
    public void ThinEvidence_ShortValidWord_IsPreserved()
    {
        // Safeguard: one converted long word is not enough evidence to flip
        // an adjacent valid short word. "to" stays; "akuo" still converts.
        var suggestion = Analyze("to akuo");
        Assert.NotNull(suggestion);
        Assert.Equal("to שלום", suggestion!.CandidateText);
    }
}
