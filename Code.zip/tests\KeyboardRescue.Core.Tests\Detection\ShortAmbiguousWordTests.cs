using KeyboardRescue.Core.Detection;
using Xunit;

namespace KeyboardRescue.Core.Tests.Detection;

/// <summary>
/// Short ambiguous words that are real words in both languages must not
/// cause false positives. "to" and "או" are each valid dictionary words
/// in their respective languages: neither should trigger a conversion
/// when typed correctly.
/// </summary>
public class ShortAmbiguousWordTests
{
    private static readonly DetectionEngine Engine = new();

    private static Suggestion? Analyze(string segment) =>
        Engine.Analyze(new AnalysisRequest(segment));

    [Fact]
    public void To_IsNotConvertedToHebrew()
    {
        // "to" is a valid English word - it should never be converted.
        Assert.Null(Analyze("to"));
        Assert.Null(Analyze("hello to"));
        Assert.Null(Analyze("going to the store"));
    }

    [Fact]
    public void AlephVav_IsNotConvertedToEnglish()
    {
        // "או" is a valid Hebrew word (meaning "or") - it should never be converted.
        Assert.Null(Analyze("\u05d0\u05d5"));
        Assert.Null(Analyze("\u05d0\u05d5 \u05de\u05d4"));
    }

    [Fact]
    public void ShortValidWordsAreNotConverted()
    {
        // Common 2-3 letter words in both languages should be preserved.
        Assert.Null(Analyze("hello"));
        Assert.Null(Analyze("שלום"));
        Assert.Null(Analyze("how"));
        Assert.Null(Analyze("מה"));
        Assert.Null(Analyze("to"));
        Assert.Null(Analyze("\u05d0\u05d5"));
    }
}
