using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Tests.Detection;

public class TextTokenizerTests
{
    [Fact]
    public void SplitsWordsNumbersAndPunctuationWithExactSpans()
    {
        var tokens = TextTokenizer.Tokenize("akuo, nv 123!");

        Assert.Equal(
            new[] { "akuo", ",", " ", "nv", " ", "123", "!" },
            tokens.Select(t => TextTokenizer.Slice("akuo, nv 123!", t)));
        Assert.Equal(TextTokenKind.Word, tokens[0].Kind);
        Assert.Equal(TextTokenKind.Punctuation, tokens[1].Kind);
        Assert.Equal(TextTokenKind.Whitespace, tokens[2].Kind);
        Assert.Equal(TextTokenKind.Number, tokens[5].Kind); // "123"
    }

    [Fact]
    public void SpansCoverTheWholeString()
    {
        const string text = "שלום, world! 77";
        int pos = 0;
        foreach (var token in TextTokenizer.Tokenize(text))
        {
            Assert.Equal(pos, token.Start);
            pos += token.Length;
        }
        Assert.Equal(text.Length, pos);
    }

    [Fact]
    public void InternalApostropheAndHyphenStayInWord()
    {
        var tokens = TextTokenizer.Tokenize("don't all-quiet");
        Assert.Contains(tokens, t => TextTokenizer.Slice("don't all-quiet", t) == "don't");
        Assert.Contains(tokens, t => TextTokenizer.Slice("don't all-quiet", t) == "all-quiet");
    }

    [Fact]
    public void TrailingApostropheIsPunctuation()
    {
        var text = "boys' toys";
        var tokens = TextTokenizer.Tokenize(text);
        Assert.Contains(tokens, t => t.Kind == TextTokenKind.Punctuation && TextTokenizer.Slice(text, t) == "'");
    }

    [Fact]
    public void EmojiAreSingleOtherTokens()
    {
        var tokens = TextTokenizer.Tokenize("hi 🙂");
        Assert.Equal(TextTokenKind.Other, tokens[^1].Kind);
        Assert.Equal(2, tokens[^1].Length); // surrogate pair
    }

    [Fact]
    public void HebrewWordsWithMaqafStayTogether()
    {
        var text = "כל-כך טוב";
        var tokens = TextTokenizer.Tokenize(text);
        Assert.Contains(tokens, t => TextTokenizer.Slice(text, t) == "כל-כך");
    }
}

public class SuggestionManagerTests
{
    private static Suggestion Make(string original, string candidate) =>
        new(original, candidate, CorrectionDirection.ToHebrew, 0.9, SuggestionStrength.Strong,
            new ScoreBreakdown(0.1, 0.9, 0.5, 0.9, 0.9, 0.8, 1, 0, 1, 0.9),
            0, original.Length);

    [Fact]
    public void Offer_SetsCurrent_Once()
    {
        var manager = new SuggestionManager();
        Assert.True(manager.Offer(Make("akuo", "שלום")));
        Assert.False(manager.Offer(Make("akuo", "שלום"))); // same segment while shown
        Assert.Equal("akuo", manager.Current!.OriginalText);
    }

    [Fact]
    public void Dismiss_RemembersSegment_AndSuppressesRepeats()
    {
        var manager = new SuggestionManager();
        manager.Offer(Make("akuo", "שלום"));
        manager.Dismiss();
        Assert.Null(manager.Current);
        Assert.False(manager.Offer(Make("akuo", "שלום")));
        Assert.True(manager.Offer(Make("bng", "נשמע"))); // different segment still offered
    }

    [Fact]
    public void Accept_ClearsCurrent_WithoutSuppressing()
    {
        var manager = new SuggestionManager();
        manager.Offer(Make("akuo", "שלום"));
        manager.Accept();
        Assert.Null(manager.Current);
        Assert.True(manager.Offer(Make("akuo", "שלום")));
    }

    [Fact]
    public void DismissalList_IsBounded()
    {
        var manager = new SuggestionManager();
        for (int i = 0; i < 60; i++)
        {
            manager.Offer(Make($"seg{i}", "x"));
            manager.Dismiss();
        }
        // Oldest entries fall out of the bounded set.
        Assert.True(manager.Offer(Make("seg0", "x")));
    }

    [Fact]
    public void Reset_ClearsEverything()
    {
        var manager = new SuggestionManager();
        manager.Offer(Make("akuo", "שלום"));
        manager.Dismiss();
        manager.Reset();
        Assert.True(manager.Offer(Make("akuo", "שלום")));
    }
}
