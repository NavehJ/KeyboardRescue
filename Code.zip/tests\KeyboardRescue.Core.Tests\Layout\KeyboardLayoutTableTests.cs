using KeyboardRescue.Core.Layout;

namespace KeyboardRescue.Core.Tests.Layout;

/// <summary>
/// Table-level invariants: the embedded dumps must load, be bijective
/// (one character per position and vice versa) and contain the verified
/// key positions documented in docs/layouts.md.
/// </summary>
public class KeyboardLayoutTableTests
{
    [Fact]
    public void Catalog_LoadsAllThreeLayouts()
    {
        Assert.NotNull(KeyboardLayoutCatalog.UsQwerty);
        Assert.NotNull(KeyboardLayoutCatalog.HebrewStandard);
        Assert.NotNull(KeyboardLayoutCatalog.Hebrew2018);
        Assert.Equal(3, KeyboardLayoutCatalog.All.Count);
        Assert.Same(KeyboardLayoutCatalog.UsQwerty, KeyboardLayoutCatalog.GetById("us-qwerty"));
        Assert.Null(KeyboardLayoutCatalog.GetById("does-not-exist"));
    }

    [Theory]
    [InlineData("us-qwerty")]
    [InlineData("he-standard")]
    [InlineData("he-2018")]
    public void Table_IsBijective_NoCharacterProducedTwice(string id)
    {
        var layout = KeyboardLayoutCatalog.GetById(id)!;
        var positions = new List<KeyPosition>();
        // Enumerate the full ASCII range every supported table can produce.
        foreach (char c in Enumerable.Range(0x20, 0x5F).Select(i => (char)i))
        {
            if (layout.TryGetPosition(c, out var pos)) positions.Add(pos);
        }

        // Every position reached must be unique, and every character it
        // produces must round-trip back to that same position.
        Assert.Equal(positions.Count, positions.Distinct().Count());
        foreach (var pos in positions)
        {
            Assert.True(layout.TryGetCharacter(pos, out char produced));
            Assert.True(layout.TryGetPosition(produced, out var back));
            Assert.Equal(pos, back);
        }
    }

    [Fact]
    public void UsTable_ContainsVerifiedPositions()
    {
        var us = KeyboardLayoutCatalog.UsQwerty;
        Assert.True(us.HasLetterCase);
        // Verified via ToUnicodeEx against KBDUS.DLL (docs/layouts.md).
        Assert.Equal('a', CharAt(us, 'a'));
        Assert.Equal(';', CharAt(us, ';'));
        Assert.Equal('\'', CharAt(us, '\''));
        Assert.Equal('"', CharAt(us, '"'));
        Assert.Equal('A', CharAt(us, 'A')); // Shift position of A
        Assert.Equal('(', CharAt(us, '(')); // Shift + 9
    }

    [Fact]
    public void HebrewStandardTable_ContainsVerifiedPositions()
    {
        var he = KeyboardLayoutCatalog.HebrewStandard;
        Assert.False(he.HasLetterCase);
        // Verified via ToUnicodeEx against kbdhebl3.dll (docs/layouts.md).
        // Position-based: "what this US position shows under the Hebrew layout".
        Assert.Equal('ש', ShowsAt(he, 0x41, shift: false));
        Assert.Equal('ל', ShowsAt(he, 0x4B, shift: false));
        Assert.Equal('ו', ShowsAt(he, 0x55, shift: false));
        Assert.Equal('ם', ShowsAt(he, 0x4F, shift: false));
        Assert.Equal('מ', ShowsAt(he, 0x4E, shift: false));
        Assert.Equal('ה', ShowsAt(he, 0x56, shift: false));
        Assert.Equal('נ', ShowsAt(he, 0x42, shift: false));
        Assert.Equal('ע', ShowsAt(he, 0x47, shift: false));
        Assert.Equal('/', ShowsAt(he, 0x51, shift: false)); // Q key carries '/'
        Assert.Equal('\'', ShowsAt(he, 0x57, shift: false)); // W key carries apostrophe
        Assert.Equal('ף', ShowsAt(he, 0xBA, shift: false));
        Assert.Equal('ת', ShowsAt(he, 0xBC, shift: false));
        Assert.Equal('ץ', ShowsAt(he, 0xBE, shift: false));
        Assert.Equal('.', ShowsAt(he, 0xBF, shift: false));
        Assert.Equal(';', ShowsAt(he, 0xC0, shift: false));
        // Shift level: Hebrew Standard swaps parens relative to US.
        Assert.Equal('(', ShowsAt(he, 0x30, shift: true)); // Shift + 0
        Assert.Equal(')', ShowsAt(he, 0x39, shift: true)); // Shift + 9
        Assert.Equal('A', ShowsAt(he, 0x41, shift: true)); // Shift letters produce Latin caps
    }

    [Fact]
    public void Hebrew2018Table_ContainsVerifiedPositions()
    {
        var he = KeyboardLayoutCatalog.Hebrew2018;
        // 2018 revision: seven base positions differ from Standard.
        Assert.Equal('ת', ShowsAt(he, 0x49, shift: false));
        Assert.Equal('ץ', ShowsAt(he, 0x51, shift: false));
        Assert.Equal('ן', ShowsAt(he, 0x57, shift: false));
        Assert.Equal(',', ShowsAt(he, 0xBC, shift: false));
        Assert.Equal('.', ShowsAt(he, 0xBE, shift: false));
        Assert.Equal('/', ShowsAt(he, 0xBF, shift: false));
        Assert.Equal('\'', ShowsAt(he, 0xDE, shift: false));
        // Unchanged letters still match Standard.
        Assert.Equal('ש', ShowsAt(he, 0x41, shift: false));
        Assert.Equal('ל', ShowsAt(he, 0x4B, shift: false));
    }

    private static char ShowsAt(IKeyboardLayout layout, uint virtualKey, bool shift)
    {
        Assert.True(layout.TryGetCharacter(new KeyPosition(virtualKey, shift), out char produced));
        return produced;
    }

    private static char CharAt(IKeyboardLayout layout, char typed)
    {
        Assert.True(layout.TryGetPosition(typed, out var pos));
        Assert.True(layout.TryGetCharacter(pos, out char produced));
        return produced;
    }
}
