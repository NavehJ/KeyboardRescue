using System.Reflection;
using KeyboardRescue.Core.Detection;

namespace KeyboardRescue.Core.Tests.Security;

/// <summary>
/// Privacy/architecture guarantees: the detection core must have no network
/// stack, no logging framework and no file or console I/O paths reachable
/// from analysis.
/// </summary>
public class PrivacyTests
{
    [Fact]
    public void CoreAssembly_DoesNotReferenceNetworking()
    {
        var references = typeof(DetectionEngine).Assembly.GetReferencedAssemblies();
        Assert.DoesNotContain(references, r => r.Name is string name &&
            (name.StartsWith("System.Net.Http", StringComparison.Ordinal) ||
             name.StartsWith("System.Net.Sockets", StringComparison.Ordinal) ||
             name == "System.Net.Requests"));
    }

    [Fact]
    public void CoreAssembly_DoesNotReferenceLoggingOrTelemetry()
    {
        var references = typeof(DetectionEngine).Assembly.GetReferencedAssemblies();
        Assert.DoesNotContain(references, r => r.Name is string name &&
            (name.StartsWith("Microsoft.Extensions.Logging", StringComparison.Ordinal) ||
             name.StartsWith("Microsoft.ApplicationInsights", StringComparison.Ordinal) ||
             name.StartsWith("Serilog", StringComparison.Ordinal) ||
             name.StartsWith("NLog", StringComparison.Ordinal)));
    }

    [Fact]
    public void CoreAssembly_DoesNotReferenceConsoleOrDiagnosticsOutput()
    {
        var references = typeof(DetectionEngine).Assembly.GetReferencedAssemblies();
        // Analysis must never print typed text anywhere.
        Assert.DoesNotContain(references, r => r.Name == "System.Console");
    }

    [Fact]
    public void Analysis_HasNoSideEffectOnRepeatedCalls()
    {
        // Deterministic pure function: same input, same output, no state
        // accumulated between runs.
        var engine = new DetectionEngine();
        var first = engine.Analyze(new AnalysisRequest("akuo nv bang"));
        var second = engine.Analyze(new AnalysisRequest("akuo nv bang"));
        Assert.NotNull(first);
        Assert.Equal(first!.Confidence, second!.Confidence);
        Assert.Equal(first.CandidateText, second.CandidateText);
    }
}
