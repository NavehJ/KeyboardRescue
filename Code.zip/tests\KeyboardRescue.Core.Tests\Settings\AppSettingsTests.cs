using KeyboardRescue.Core.Detection;
using KeyboardRescue.Core.Settings;
using Xunit;

namespace KeyboardRescue.Core.Tests.Settings;

public class AppSettingsTests
{
    [Fact]
    public void Defaults_AreConservative()
    {
        AppSettings s = AppSettings.Default;

        Assert.True(s.Enabled);
        Assert.False(s.AutoFix);                 // suggestions only, never auto-correct
        Assert.False(s.AllowUnknownSecureState); // fail safe on unknown secure input
        Assert.True(s.EnableHebrewSuggestions);
        Assert.True(s.EnableEnglishSuggestions);
        Assert.Equal(450, s.DebounceMilliseconds);
    }

    [Fact]
    public void Sanitized_ClampsOutOfRangeTimings()
    {
        var bad = new AppSettings
        {
            DebounceMilliseconds = 5,
            FastTriggerMilliseconds = 99_999,
            AutoHideMilliseconds = -1,
        };

        AppSettings clean = bad.Sanitized();

        Assert.Equal(300, clean.DebounceMilliseconds);   // min bound
        Assert.Equal(300, clean.FastTriggerMilliseconds); // max bound
        Assert.Equal(AppSettings.Default.AutoHideMilliseconds, clean.AutoHideMilliseconds);
    }

    [Fact]
    public void Sanitized_KeepsValidTimings()
    {
        var good = new AppSettings { DebounceMilliseconds = 450, AutoHideMilliseconds = 5000 };
        Assert.Equal(450, good.Sanitized().DebounceMilliseconds);
        Assert.Equal(5000, good.Sanitized().AutoHideMilliseconds);
    }

    [Fact]
    public void Sanitized_NormalizesBlankShortcut()
    {
        var blank = new AppSettings { GlobalShortcut = "   " };
        Assert.Equal(string.Empty, blank.Sanitized().GlobalShortcut);
    }

    [Fact]
    public void SensitivityMapping_ProducesOrderedThresholds()
    {
        double low = DetectionOptions.ForSensitivity(Sensitivity.Low).SuggestThreshold;
        double medium = DetectionOptions.ForSensitivity(Sensitivity.Medium).SuggestThreshold;
        double high = DetectionOptions.ForSensitivity(Sensitivity.High).SuggestThreshold;

        Assert.True(low > medium, "Low must be the strictest sensitivity");
        Assert.True(medium > high, "High must be the most eager sensitivity");
    }
}
